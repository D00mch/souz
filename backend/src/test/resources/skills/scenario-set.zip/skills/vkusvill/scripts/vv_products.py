"""Provider price and quantity metadata, without parsing display labels as numbers."""
from decimal import Decimal, InvalidOperation

from vv_common import Failure, obj, protocol, quantity


def optional_number(value, *, string=False):
    if value is None:
        return None
    if string and isinstance(value, str):
        try:
            value = float(Decimal(value))
        except (InvalidOperation, ValueError, OverflowError):
            raise protocol()
    return quantity(value)


def optional_text(value):
    if value is not None and not isinstance(value, str):
        raise protocol()
    return value or None


def metadata(item, *, cart=False):
    props = obj(item.get("properties") or {}) if cart else item
    prices = obj(item.get("prices" if cart else "price") or {})
    regular = optional_number(prices.get("price_retail" if cart else "price"))
    discounted = optional_number(prices.get("price_discount" if cart else "discount_price"))
    step = optional_number(props.get("weight_step"), string=not cart)
    return {
        "price": discounted if discounted is not None else regular,
        "price_retail": regular, "currency": "RUB",
        "unit": optional_text(props.get("unit")),
        "quantity_step": step if step else None,
        "weight_type": optional_text(props.get("type" if cart else "weight_type")),
        "weight_label": None if cart else optional_text(item.get("weight_str")),
        **({"line_total": optional_number(prices.get("sum_with_discount"))} if cart else {}),
    }


def addition_plan(items, known, now):
    plan = []
    for item in items:
        info = known[str(item["product_id"])]
        unit, step = info.get("unit"), info.get("quantity_step")
        fetched = info.get("quantity_fetched_at")
        if not unit or not step or fetched is None or not 0 <= now - fetched <= 900:
            raise Failure("QUANTITY_CONTEXT_REQUIRED", "Получите свежий поиск с единицей и шагом количества товара.")
        if item["unit"] != unit:
            raise Failure("UNSUPPORTED_QUANTITY", "Единица количества должна совпадать с unit товара.")
        requested, increment = Decimal(str(item["quantity"])), Decimal(str(step))
        steps = requested / increment
        if steps != steps.to_integral_value() or not 1 <= steps <= 1000:
            raise Failure("UNSUPPORTED_QUANTITY", "Количество должно составлять от 1 до 1000 целых шагов quantity_step.")
        plan.append({**item, "step": int(steps)})
    return plan


def same_quantity(left, right):
    # API floats may contain binary rounding noise, but never forgive a missing step.
    return abs(Decimal(str(left)) - Decimal(str(right))) <= abs(Decimal(str(right))) * Decimal("1e-9")
