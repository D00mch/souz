# Editorial design and composition

Start with what the reader should understand, then choose a figure that demonstrates it. The Gamma reference means polished typography, visual rhythm, controlled colour, space, and several composition types. It does not require the Gamma service or copying its interface.

Use SB Sans Display Semibold for headings and Display Regular for interface/body text by default. Choose SB Sans Text explicitly for long prose; it is a different, less distinctive text cut, not the same shape as Display. Do not assume a CSS family name alone proves a font loaded. Establish one accent, one muted text colour, and consistent status colours. Match the palette and shape language to the topic. Soft lighting, a restrained gradient, texture or a translucent floating control are available when they serve the chosen direction; none is a universal ban or a mandatory decoration. Change themes when the subject or user calls for it.

## Compositions available in the shell

| Shape | Classes / authoring approach | Suitable use |
| --- | --- | --- |
| Hero with a figure | .split, .stack, .diagram, .orbit, .hub, .node | One main idea, a system map, a large title balanced by an informative figure |
| Aligned comparison | .grid.cols-2, .tile, .accent-tile, .row | Shared criteria across two options; meaningful distinction is visible without reading a paragraph |
| Room or category map | .grid.cols-2 or .grid.cols-3, .room-head, inline SVG connectors | Group items by place or purpose; count real groups and do not leave a phantom fourth column |
| Bento | .bento, .tile, .wide | Unequal importance: one main figure plus supporting facts; do not make every tile identical |
| Metrics | .metric, .number, .label, an honest SVG chart | Large values with units, denominators and an evidence date where relevant |
| TV metric comparison | data-layout="metrics", .grid.cols-3, .tile, .number, .number-unit | Three headline values with compact notes and sources. Start from [the TV example](../assets/tv-metrics.html). |
| Chart page | data-layout="chart", .slide-header, .metric-strip, figure | A compact full-width title and metadata, optional short metrics, and a main figure occupying the remaining height |
| Process or timeline | .timeline, or custom labeled SVG | Actions and dependencies; chronological distances should not imply unsupported durations |
| Typographic close | .quote, .conclusion | One concrete takeaway and a next step, with minimal visual competition |

A full deck needs a varied rhythm between distinct information types, and one stable component language within the same type. The same room/device should not become a different row, status or card style on the next page. Do not attach a room inventory to every slide or put all detail in narrow cards. Introduce the map, then expand focused groups, then conclude. Use more than one layout only when it serves the content, rather than padding a short explanation into a deck.

## TV content budget

Top-align every slide at the same safe inset. Keep the kicker/title baseline stable across pages; changing the amount of body content must not move the header. Do not use vertical centring for the whole .slide-inner block.

An h1 is semantic, not an instruction to turn every first page into a cover. The default h1 uses a compact full-width scale. Use data-layout="hero" or .hero-title only for an intentional cover/split composition; that style has a larger size and a 19ch width limit. Do not apply the cover style above a full-width chart or table.

For one chart plus a few metrics, use this structure (replace the placeholders with grounded content):

```html
<section data-slide data-layout="chart">
  <div class="slide-inner">
    <header class="slide-header">
      <h1>Короткий заголовок графика</h1>
      <p class="lead">Период, единицы и необходимый контекст.</p>
      <div class="metric-strip">
        <div class="tile"><div class="stat-pair"><span class="label">Показатель</span><span class="number">42</span></div><p>Дата или единица</p></div>
        <!-- Add only the useful short metrics, up to four. -->
      </div>
    </header>
    <figure aria-label="Содержательное описание графика"><!-- Inline SVG --></figure>
  </div>
</section>
```

The chart stage uses auto/minmax grid rows: the header takes its natural height and the figure takes the rest. Design the SVG viewBox for that available shape; an overly tall viewBox leaves wide side gutters when fitted proportionally. Avoid distorting labels with preserveAspectRatio="none". Aim to give the primary figure at least half the content height. If a title and metrics exceed that budget, simplify the header or move secondary information to another section. Four full-size metric cards in a 2×2 grid do not belong above a primary chart. .cols-4 defines four explicit columns; .metric-strip additionally uses compact typography, stacked label/value pairs and two columns on phones.

Compose for 960×540 CSS pixels on a 16:9 TV. The stage uses one safe content inset, and the floating dock reserves no layout space. Budget a heading of 1–2 lines plus one primary figure or two detail groups. For inventory pages aim for up to four short rows per group, then use another section or a more suitable visual.

Use ordinary word wrapping for names and headings. Restrict overflow-wrap:anywhere to unavoidable hashes/URLs/code. Never let a right-aligned status consume most of a narrow name column. Prefer short explicit status labels with an icon and colour. Unknown state is distinct from off or offline.

Do not shrink a crowded deck to rescue it. Remove redundant prose, use the unused width, or split by a meaningful boundary. The viewer keeps excess content scrollable as a safety net; a normal TV page should not need that fallback. The main narrative, section count and navigation must agree.

## Documents and phones

Document mode displays all sections and converts the shell grids to one column on narrow screens. Preserve semantic reading order. A dense TV deck and a mobile document can share content while having separate files. For a phone deck choose a portrait ratio and deliberately recompose; changing ratio alone is insufficient.

Custom figures should use SVG text and explicit labels, not screenshots of text. Use honest chart scales, consistent units and known source dates. A chart or topology must add understanding; icons and rounded cards alone do not create an infographic.

## Alignment, wrapping and data

Keep label/value pairs in .stat-pair, so a count cannot become an orphan after a dash. Keep item names and statuses in separate cells. A status is a labelled badge with stable width and colour mapping, not text appended to a name. Card headings reserve the same two-line slot across equivalent cards. Long content wraps on word boundaries; if it needs more space, change pagination rather than breaking every word or reducing all fonts.

Use a sparse group as part of a meaningful overview or neighbouring section. Do not create a whole slide for three already-listed active devices. Do not pad it with personal compliments, time-of-day guesses or metaphors that assert unsupported states. Totals reconcile with source records; distinguish off, offline, unknown and not returned by a partial listing. “24 catalogue entries” is different from “24 unique physical devices”.

When a browser is available, check 960×540, 1280×720 and 1920×1080 CSS pixels. After fonts load, confirm `scrollHeight <= clientHeight` and `scrollWidth <= clientWidth` on each visible TV slide. Reflow dense content or split it across slides when it overflows.
