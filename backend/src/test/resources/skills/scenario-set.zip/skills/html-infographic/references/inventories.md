# Catalogues, cards and status rows

For a catalogue of devices/rooms with states, use scripts/inventory.py instead of hand-authoring text such as “Лампа — выкл”. This path produces the same card header, item row, badge and two-column detail layout on every slide. Visual variety belongs between different kinds of information; equivalent entities keep one component vocabulary.

Read actual source data first. Check paging and missing fields. Preserve each source record and group; do not invent names or silently omit inconvenient long names. Input expectedCount/expectedGroups only when the upstream source supplies these counts with the same meaning. A count of all registered rooms need not equal the number of nonempty rooms in a device listing: resolve this scope before assigning expectedGroups. The renderer counts provided catalogue entries, not unique physical devices across integrations.

## Input JSON

```json
{
  "title": "Дом в двух экосистемах",
  "source": "Данные пользователя",
  "asOf": null,
  "expectedCount": 2,
  "catalogues": [{
    "name": "Каталог",
    "expectedCount": 2,
    "expectedGroups": 1,
    "groups": [{
      "name": "Гостиная",
      "devices": [
        {"id": "source-a", "name": "Лампа", "state": "on", "icon": "bulb"},
        {"id": "source-b", "name": "Колонка", "state": "unknown", "icon": "speaker"}
      ]
    }]
  }]
}
```

Supply actual values, not this illustrative input. Use source IDs when available; do not fabricate globally shared physical identities. Duplicate IDs within one catalogue reject the input. Missing/null state becomes unknown. The four states are on, off, offline, unknown; the renderer localizes them consistently as Включено, Выключено, Офлайн, Нет данных. Offline does not imply off. “Not in the on list” does not prove off. Do not infer state from a device name, purpose or missing field.

source describes the evidence; asOf is its known snapshot time, or null if unknown. For a partial source, say so in source and count only the supplied entries. Never describe a saved snapshot as “right now”. The renderer does not refresh device data.

## Command

Use RunSkillCommand with runtime=PYTHON, scriptPath="scripts/inventory.py", args=[absolute_json_path, absolute_new_html_path, "--surface", "tv", "--theme", "nocturne"]. Choose chat/mobile for a responsive document. SB Sans Display Regular/Semibold is the default interface typography; --body-font text is available for an explicitly chosen long-text style.

The renderer validates counts, stable IDs and states, balances long/dense groups into cards, and places at most two cards per detail slide. An overview contains the source totals, all four state counts and a compact active-item summary. Do not add a separate final slide containing only the same three active items or personality filler. At most four short item rows fit in each card; long names consume additional text budget and trigger splitting. Long group names have the same two-line header slot; item name and status are separate elements.

The HTML embeds the input JSON. Static validation verifies that every source record appears exactly once in detail, that displayed names/states agree with it, and that all summary totals reconcile. Modifying visible counters or changing unknown into off causes a failed check. This proves consistency with the supplied snapshot, not that the snapshot itself is fresh or complete.

For other repeated entities use the same markup pattern: .entity-grid, .entity-card, .entity-card-head, .entity-card-title and .entity-row with separate data-entity-name and data-status children. Use .stat-pair for a label and number; never leave the number after a wrapping dash. For non-inventory material these classes can be authored in ordinary section fragments, with the corresponding source-grounding checks performed by the author.
