"""Static checks only: no rendering, page execution, filesystem writes or network."""
import json
import re
import shutil
import subprocess
import sys
from html.parser import HTMLParser
from pathlib import Path

VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}
RESOURCE = {"src", "href", "xlink:href", "poster", "background", "data"}


class Document(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.elements, self.stack, self.errors = [], [], []
        self.scripts, self.styles, self.doctypes = [], [], []
        self.active_script, self.active_style = None, None
        self.title = ""
        self.nodes, self.node_stack = [], []

    def handle_decl(self, declaration):
        self.doctypes.append(declaration.lower())

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        self.elements.append((tag, attrs))
        node = {'tag':tag,'attrs':attrs,'parts':[]}
        self.nodes.append(node)
        if self.node_stack:
            self.node_stack[-1]['parts'].append(node)
        if tag not in VOID:
            self.stack.append(tag)
            self.node_stack.append(node)
        if tag == "script":
            self.active_script = {"type": attrs.get("type", ""), "source": "", "inventory": "data-inventory" in attrs}
            self.scripts.append(self.active_script)
        if tag == "style":
            self.active_style = []
            self.styles.append(self.active_style)
        if "style" in attrs:
            self.styles.append([attrs["style"] or ""])

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in VOID:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        if tag in VOID:
            self.errors.append("Void element has a closing tag: " + tag)
        elif not self.stack or self.stack[-1] != tag:
            self.errors.append("Mismatched closing tag: " + tag)
        else:
            self.stack.pop()
            self.node_stack.pop()
        if tag == "script":
            self.active_script = None
        if tag == "style":
            self.active_style = None

    def handle_data(self, data):
        if self.node_stack:
            self.node_stack[-1]['parts'].append(data)
        if self.active_script is not None:
            self.active_script["source"] += data
        elif self.active_style is not None:
            self.active_style.append(data)
        elif self.stack and self.stack[-1] == "title":
            self.title += data
        elif data.strip() and not self.stack:
            self.errors.append("Visible text outside the HTML root")

    def descendants(self,node):
        for part in node['parts']:
            if isinstance(part,dict):
                yield part
                yield from self.descendants(part)

    def text_content(self,node):
        return ''.join(self.text_content(part) if isinstance(part,dict) else part for part in node['parts'])


def embedded(value):
    return value.startswith("#") or bool(re.match(r"data:(image|font|audio|video)/", value, re.I))


def check(path):
    source = Path(path)
    if source.is_symlink() or not source.is_file() or not 0 < source.stat().st_size <= 5_000_000:
        raise ValueError("Expected a regular HTML file of 1–5,000,000 bytes")
    with source.open("rb") as stream:
        raw = stream.read(5_000_001)
    if len(raw) > 5_000_000:
        raise ValueError("HTML exceeds 5,000,000 bytes")
    html = raw.decode("utf-8-sig", errors="strict")
    doc = Document()
    doc.feed(html)
    doc.close()
    errors, warnings = list(doc.errors), []
    if doc.stack:
        errors.append("Unclosed elements: " + ", ".join(doc.stack[:10]))
    roots = [attrs for tag, attrs in doc.elements if tag == "html"]
    if doc.doctypes != ["doctype html"] or len(roots) != 1 or not doc.elements or doc.elements[0][0] != "html":
        errors.append("A complete HTML5 document with one HTML root is required")
    if not doc.title.strip() or not roots or not roots[0].get("lang"):
        errors.append("Document title and language are required")
    for tag in ("head", "body", "title"):
        if sum(name == tag for name, _ in doc.elements) != 1:
            errors.append("Expected one " + tag + " element")
    metas = [attrs for tag, attrs in doc.elements if tag == "meta"]
    if not any((attrs.get("charset") or "").lower() == "utf-8" for attrs in metas):
        errors.append("UTF-8 charset declaration is required")
    if not any((attrs.get("name") or "").lower() == "viewport" and "width=device-width" in (attrs.get("content") or "").replace(" ", "") for attrs in metas):
        errors.append("Device-width viewport declaration is required")
    profile = roots[0] if roots else {}
    surface, form = profile.get("data-souz-surface"), profile.get("data-souz-format")
    if surface not in ("chat", "mobile", "tv"):
        errors.append("Invalid data-souz-surface")
    if form not in ("document", "single", "slides"):
        errors.append("Invalid data-souz-format")
    if form in ("single", "slides") and not re.fullmatch(r"[1-9]\d{0,2}:[1-9]\d{0,2}", profile.get("data-souz-ratio") or ""):
        errors.append("Use positive integer data-souz-ratio proportions, such as 16:9")
    slides = [attrs for _, attrs in doc.elements if "data-slide" in attrs]
    if not 1 <= len(slides) <= 24:
        errors.append("Use 1–24 data-slide sections")
    if form == "single" and len(slides) != 1:
        errors.append("Single-screen output needs exactly one section")
    if form == "document" and any("hidden" in attrs for attrs in slides):
        errors.append("Document sections must not be hidden")
    if form == "slides":
        for hook in ("data-prev", "data-next", "data-position"):
            if not any(hook in attrs for _, attrs in doc.elements):
                errors.append("Missing presentation control: " + hook)
    ids = [attrs["id"] for _, attrs in doc.elements if attrs.get("id")]
    if len(ids) != len(set(ids)):
        errors.append("Duplicate HTML IDs")
    for tag, attrs in doc.elements:
        if tag in ("base", "iframe", "object", "embed", "form", "link") or tag == "meta" and (attrs.get("http-equiv") or "").lower() == "refresh":
            errors.append("Unsupported embedded/navigation element: " + tag)
        if tag == "script" and "src" in attrs:
            errors.append("JavaScript must be inline")
        if any(name in attrs for name in ("srcset", "ping", "srcdoc")):
            errors.append("Unsupported resource attribute on " + tag)
        for name, value in attrs.items():
            if name not in RESOURCE:
                continue
            value = (value or "").strip()
            if tag == "a" and name == "href" and re.match(r"(https?:|mailto:|#)", value, re.I):
                continue
            if tag == "img" and name == "src" and re.match(r"https://[^/?#\s\\]+", value, re.I):
                continue
            if not embedded(value):
                errors.append("Non-embedded resource on " + tag + "." + name)
    css = "\n".join("".join(block) for block in doc.styles)
    if re.search(r"@import\b", css, re.I):
        errors.append("CSS imports are forbidden")
    for url in re.findall(r"url\(\s*['\"]?([^)\s'\"]+)", css, re.I):
        if not embedded(url):
            errors.append("CSS resources must be embedded")
    syntax_count = 0
    for script in doc.scripts:
        kind, code = script["type"].lower(), script["source"]
        if kind == "module":
            errors.append("Module scripts are not supported by the offline viewer contract")
            continue
        if kind not in ("", "text/javascript", "application/javascript"):
            continue
        if re.search(r"\b(fetch\s*\(|XMLHttpRequest\b|WebSocket\b|(?:local|session)Storage\b|window\.open\s*\(|import\s*\()", code):
            errors.append("Page script depends on unsupported network, storage or popup APIs")
        if not shutil.which("node"):
            warnings.append("Node is unavailable; JavaScript syntax was not checked")
            continue
        result = subprocess.run(["node", "--check"], input=code, text=True, capture_output=True, timeout=5)
        syntax_count += 1
        if result.returncode:
            errors.append("Inline JavaScript syntax check failed")
    if profile.get('data-kind') == 'inventory':
        import importlib.util
        sys.dont_write_bytecode = True
        spec = importlib.util.spec_from_file_location('inventory_validation',Path(__file__).with_name('inventory.py'))
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        errors.extend(module.validate_rendered(doc))
    return {
        "staticPassed": not errors,
        "surface": surface,
        "format": form,
        "sections": len(slides),
        "javascriptSyntaxChecks": syntax_count,
        "errors": list(dict.fromkeys(errors)),
        "warnings": list(dict.fromkeys(warnings)),
        "notChecked": ["visual layout", "contrast and legibility", "runtime interaction", "actual client display"],
    }


if __name__ == "__main__":
    try:
        if len(sys.argv) != 2:
            raise ValueError("Use RunSkillCommand runtime=PYTHON, scriptPath=scripts/check_html.py, args=[absolute_html_path]")
        report = check(sys.argv[1])
    except (OSError, ValueError, UnicodeError, subprocess.SubprocessError) as error:
        report = {"staticPassed": False, "errors": [type(error).__name__ + ": " + str(error)]}
    print(json.dumps(report, ensure_ascii=False))
    sys.exit(0 if report["staticPassed"] else 1)
