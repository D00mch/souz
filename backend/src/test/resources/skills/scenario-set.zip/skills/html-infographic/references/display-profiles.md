# Display profiles

Surface describes where the result is read; format describes how its content is traversed. Choose both from user intent, not width alone. Keep the chosen values in the HTML root so a later edit does not have to infer them.

| Surface | Composition | Input and checks |
| --- | --- | --- |
| `chat` | Adaptive document; aligned comparisons and 2–3 columns when space permits. Collapse into a meaningful reading order on narrow screens. | Keyboard/mouse and touch; design for 390×844 and 960×900 CSS pixels. These are design targets, not observed client dimensions. |
| `mobile` | Single-column reading, short labels, large touch targets. Restructure wide comparisons into aligned groups; diagram labels remain readable. | Touch and keyboard; same narrow/wide design targets as chat, including later desktop reopening. |
| `tv` | Horizontal composition, readable from a distance, larger labels, quiet animation. Use available width for related figures, not long prose. Use one safe content inset from the screen edges; avoid adding another outer frame. | Remote/D-pad and keyboard; design for 960×540, 1280×720, 1920×1080 and 1280×960. No mouse-only controls. |

| Format | Behavior |
| --- | --- |
| `document` | Show all `data-slide` sections in natural vertical order. No fixed aspect ratio or hidden content. Avoid page-level horizontal scrolling. |
| `single` | One complete composition fits a ratio-constrained stage; no hidden second section or required scrolling. Split excess material into a presentation instead. |
| `slides` | One section per slide; fixed chosen stage ratio, all sections reachable. Native buttons, position indicator, keyboard and remote focus; no automatic advance by default. |

For single/screens and slides, use 16:9 by default on TV. Explicit proportions override the default. Fit the stage within the viewport with letterboxing when necessary; do not stretch its coordinate system. The stage fits the viewport without an additional outer frame. Slide content aligns to the top with the same inset; headers must not move vertically when body content changes. The floating dock is an overlay and hides after three seconds of inactivity; its height is never subtracted from the content. The bottom safe inset is measured from the screen edge when the aspect ratios match, or the stage edge when letterboxed. Keyboard/remote, pointer movement and touch reveal navigation. A stationary pointer does not pin the panel open; Tab focus does. Showing or hiding it does not reflow the slide. Keep the entire slide inside the stage; hiding overflow does not make excess content fit. These are authoring constraints; automatic rendering is not required.

On a phone, a dense 16:9 TV deck often needs a separate document or a deliberately composed portrait deck, rather than a scaled-down TV view. If both destinations are requested, produce and statically check separate files with equivalent content. The composer supports arbitrary positive integer ratios; changing only the ratio does not guarantee the content fits.

If the display context is missing, record the assumed profile in the response when it affects the result. Do not invent resolution, exact browser dimensions or successful display. Client viewport reporting is not part of this Skill or the current public protocol.
