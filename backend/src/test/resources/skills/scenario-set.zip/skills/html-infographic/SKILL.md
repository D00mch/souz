---
name: html-infographic
description: Create polished HTML infographics and presentations for chat, mobile and TV using embedded SB Sans fonts, SVG icon sets, varied compositions and floating navigation; deliver the result through Souz attachments. Use for requested visual explanations and HTML materials, not ordinary short replies.
commands:
  publish:
    inputs: [slug, spec]
    steps:
      - id: build
        script: scripts/publish.py
        runtime: PYTHON
        args: ["${inputs.slug}", "${inputs.spec}"]
      - id: attached
        tool: AttachFileToReply
        arguments:
          path: "/souz/workspace/html-infographic/${inputs.slug}.html"
          presentation: document
    returns: "${attached}"
---

# HTML infographic

Create a finished visual explanation: a clear editorial idea, deliberate typography, meaningful figures and varied page composition. The result is one UTF-8 HTML attachment. All fonts, SVG, CSS and JavaScript are embedded; neither creation nor viewing needs an external design service. No Chromium or other renderer is installed or required in the user's sandbox.

Read references through RunSkillCommand with runtime=PYTHON and an inline pathlib.Path(...).read_text(); paths are relative to this Skill. Keep working files in /souz/workspace/html-infographic/, outside the bundle. Pass authored fragments directly to the publish composite when they are available inline.

## Design before assembly

Consult [design](references/design.md) and the relevant [display profile](references/display-profiles.md) when the request needs more layout guidance. Resolve the target channel and surface: an explicit request for TV wins over the mobile device making the request. Use known device type and user intent; do not invent precise viewport dimensions or an unavailable discovery tool. Select chat/mobile/tv separately from document/single/slides. Chat defaults to a responsive document; TV defaults to a 16:9 deck. Explicit user format and proportions win.

Make a compact content plan: the main conclusion, supporting facts, the figure and composition of each section, and the information that can be omitted without losing meaning. Separate known, offline and unknown states; never convert missing state into off. Do not invent numbers, unique-device counts, dates or facts to decorate the page.

For device/room catalogues with states, read [catalogue rendering](references/inventories.md) and use scripts/inventory.py with source JSON. Do not recreate catalogue rows as inline name–status sentences or change card structure between equivalent groups.

Choose an art direction and a sequence of compositions. Themes and icon sets are working resources, not mandatory visual identities. A user reference or brand takes priority. Consult [visual assets](references/visual-assets.md) for fonts, icon names, themes and local custom assets as needed. Keep equivalent entities in identical components across slides; vary the composition only when the information type changes. A whole catalogue is usually an overview plus focused detail sections, not one oversized table.

## Author and compose

1. Write section fragments following [assets/sections.html](assets/sections.html). Each direct child of main is a section with data-slide and a .slide-inner child. The example demonstrates hero, comparison and timeline; replace its content and choose layouts for the request. Useful classes and layout recipes are in the design reference. Add scoped inline CSS or SVG when the bundled patterns do not express the idea well. Do not include html/head/body wrappers in the fragment.
2. Use placeholders such as {{icon:home}} or {{icon:bulb}} for real SVGs from a consistent set. Do not substitute emoji or arbitrary text glyphs for icons. The available names are listed in the visual-assets reference. Only used SVGs enter the final HTML.
3. For authored HTML, call the `publish` composite to assemble, statically check, and attach in one call. Invoke `RunSkillCommand` with `skillId="html-infographic"` and `arguments={"composite":"publish","inputs":{"slug":"<new-ascii-slug>","spec":"<JSON object encoded as one string>"}}`. Use a new slug of lowercase ASCII letters, digits and hyphens for each revision. The decoded `spec` has `title` and `html` (the section fragments). It can also set `surface` (`chat`, `mobile`, `tv`), `format` (`document`, `single`, `slides`), `ratio` (defaults to `16:9`), `theme` (`sber`, `nocturne`, `editorial`), `icons` (`lucide`, `phosphor`), and `bodyFont` (`display`, `text`). Set `single` for an explicit one-slide request or `slides` for a TV deck. Check for the attachment metadata before confirming delivery.
4. For a custom font, prepare an owned input with PrepareAttachment if needed. Invoke this Skill's scripts/embed_font.py through RunSkillCommand runtime=PYTHON, args=[absolute_font_path, absolute_new_css_path, "--family", family, "--weight", "400", "--role", "body|heading"]. Supply one actual role. It accepts existing WOFF2/WOFF/OTF/TTF up to 500 KB, with no installation or network. Include the resulting CSS via compose.py --font-css absolute_css_path. Multiple font faces can be combined in one CSS file; preserve the font's permitted use and source notice. Prefer WOFF2 and never print or read the base64 asset chunks into model context.

For direct assembly from workspace fragments or with a custom font, invoke RunSkillCommand with runtime=PYTHON, scriptPath="scripts/compose.py", args=[absolute_sections_path, absolute_new_html_path, "--title", title, "--surface", "chat|mobile|tv", "--format", "document|single|slides", "--ratio", "16:9", "--theme", "sber|nocturne|editorial", "--icons", "lucide|phosphor"]. Supply actual values, not the alternatives joined with a pipe. The output path must not exist. The composer embeds SB Sans Display Regular/Semibold by default for a coherent interface; --body-font text explicitly chooses SB Sans Text Regular/Semibold with Display headings. It also embeds the selected theme, used SVGs, and the presentation viewer. It statically checks the assembled file before writing it.

The generated page keeps surface, format, ratio and theme as data attributes on html. Fonts are embedded as data: URLs; no font installation is required on the target. Use absolute HTTPS URLs in `<img src>` for external photos. Embed other rendering dependencies. The output must remain at most 5,000,000 bytes.

## Navigation and fit

The viewer supplies a floating dock, a position indicator and a slide overview with direct jumps. It supports buttons, Left/Right, PageUp/PageDown, Home/End, horizontal swipes, keyboard focus and reduced motion. Use native controls and preserve their data attributes if restyling. The dock floats above the content and hides after three seconds without input. Pointer movement, touch and keyboard/remote input reveal it. Tab focus keeps it available; Enter from the slide focuses a page button. It reserves no footer band and never changes slide dimensions when shown or hidden. In a matching TV aspect ratio, the stage reaches the screen edges; content uses one safe inset from those edges, including the bottom. Preserve letterboxing for explicitly chosen other ratios. Do not subtract the dock height from the slide or add permanent bottom space for it.

Align slide content to the top with the same safe inset on every page. Keep header titles at a stable vertical position; do not vertically centre the whole content block as its height changes.

Plan content to fit and to earn its page: merge a sparse recap into the overview, while splitting dense lists by meaningful groups. Keep equal card-header slots so one wrapped title does not move its body baseline relative to neighbouring cards. Use .stat-pair for label/value pairs, and separate name/status cells for entity lists.

Use compact, full-width headings for data pages, including the first page when it contains a chart. Large narrow headings are opt-in through data-layout="hero" or .hero-title, with a figure or a deliberately sparse cover. For chart pages use a .slide-header followed by a figure inside .slide-inner; .metric-strip keeps four short metrics in one row on TV. The chart takes the remaining height. Keep the title/subtitle compact enough to leave the primary figure most of the content area; shorten redundant wording or move secondary metrics when needed. See the chart recipe in the design reference.

Keep labels readable and use available width; split long lists by a meaningful group before shrinking fonts or forcing narrow columns. Never apply overflow-wrap:anywhere to all labels or centre an oversized block in a fixed-height container. Width alone must not decide document vs presentation mode.

For a TV page of headline values, start with [assets/tv-metrics.html](assets/tv-metrics.html). Use the stage unit `--u` with `clamp()` for custom type and spacing. Let `.slide-inner` provide the space between blocks. Compose 16:9 pages to fit 960×540 CSS pixels.

Embedded font faces use private Souz aliases, with no local() font substitution. The viewer explicitly loads the body/heading faces with Cyrillic text and compares their metrics to fallback. data-font-status reports loaded or fallback; a failed load is visible, not silently treated as success. --diagnostics exposes the report for investigation. Font loading is still not a full visual review.

The viewer remeasures after fonts load and on resize. If authored content still overflows, the slide remains scrollable and the dock indicates this; Up/Down scrolls it. This prevents inaccessible clipped content, but is a fallback rather than a good finished slide. Aim for no scrolling in a TV deck. Do not suppress overflow or globally scale down fonts to make a page appear to fit.

## Lightweight checks and delivery

The composer uses Python's standard library and, when already present, Node for JavaScript syntax only. Neither it nor scripts/check_html.py executes page scripts, starts a browser or makes network requests. Inventory validation additionally checks rendered rows and counters against the embedded input snapshot. Read the static result; it does not establish visual quality or working runtime interactions. For edits outside the composer, invoke RunSkillCommand runtime=PYTHON, scriptPath="scripts/check_html.py", args=[absolute_html_path]. Fix failures before delivery, bounded to three correction cycles. Default generation does not require screenshots or visual review. If the user requests visual review, use an available client or a separately authorized environment and report what was actually checked; do not install renderers silently.

The `publish` composite selects its own output. After direct assembly, select the latest checked file with AttachFileToReply(path=absolute_html_path, presentation="document"). A path in prose is not an attachment. Revisions use new filenames; detach an earlier selected revision. A child returning a file does not select the parent's reply: the parent explicitly attaches it.

For an explicitly requested other channel, resolve its owned destination through ListActiveChannels when needed and send the returned fileId via SendMessageToChannel(channelType, channelId, fileIds=[fileId]). If delivery was only intended for the other channel, detach from the source reply after successful sending. Do not replay uncertain deliveries or replace the file flow with a local HTTP server, Docker address, S3 URL or placeholder data URI.

Orion owns TV publication and opening. It selects the first HTML document attachment, so send one final HTML per TV delivery and do not open it a second time yourself. Dispatch acknowledgement does not prove physical rendering. Chat clients receive the same document attachment; inline display depends on the client. Use a short factual caption, without invented praise or chatty comments inside the design.

Orion's opaque-origin iframe supports inline scripts, embedded fonts and images, and HTTPS images. The CSP blocks remote scripts, stylesheets and fetch requests. The sandbox isolates storage and blocks parent access, popups and downloads. The original has normal file ownership/expiry; Orion's temporary browser copy is not a permanent sharing URL.
