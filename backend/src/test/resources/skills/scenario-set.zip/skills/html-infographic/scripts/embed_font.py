"""Embed an owner-provided font as CSS without installing it or accessing a service."""
import argparse
import base64
import hashlib
import json
import re
from pathlib import Path


def embed(source, family, weight=400, role='body'):
    if not family or re.search(r'[^\w -]',family) or not 100 <= weight <= 900 or role not in ('heading','body'):
        raise ValueError('Invalid font family, weight or role')
    if source.is_symlink() or not source.is_file() or not 0 < source.stat().st_size <= 500_000:
        raise ValueError('Supply a regular font file of at most 500 KB; prefer WOFF2')
    with source.open('rb') as stream:
        data = stream.read(500_001)
    formats = {b'wOF2':('woff2','font/woff2'),b'wOFF':('woff','font/woff'),b'OTTO':('opentype','font/otf'),b'\x00\x01\x00\x00':('truetype','font/ttf')}
    if data[:4] not in formats or len(data) > 500_000:
        raise ValueError('Unsupported or oversized font; use WOFF2, WOFF, OTF or TTF')
    kind,mime = formats[data[:4]]
    css = ("@font-face{font-family:'" + family + "';font-style:normal;font-weight:" + str(weight) + ";font-display:swap;src:url(data:" + mime + ";base64," + base64.b64encode(data).decode() + ") format('" + kind + "');}\n"
           ":root{--" + role + "-font:'" + family + "';}\n")
    return css,hashlib.sha256(data).hexdigest()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source',type=Path)
    parser.add_argument('output',type=Path)
    parser.add_argument('--family',required=True)
    parser.add_argument('--weight',type=int,default=400)
    parser.add_argument('--role',choices=['heading','body'],default='body')
    args = parser.parse_args()
    try:
        css,checksum = embed(args.source,args.family,args.weight,args.role)
        with args.output.open('x',encoding='utf-8') as output:
            output.write(css)
        print(json.dumps({'path':str(args.output),'family':args.family,'weight':args.weight,'sha256':checksum}))
    except (OSError,ValueError) as error:
        print(json.dumps({'error':str(error)}))
        raise SystemExit(1)
