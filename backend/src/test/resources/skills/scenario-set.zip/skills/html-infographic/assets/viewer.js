(() => {
  const root = document.documentElement;
  const slides = [...document.querySelectorAll('main > [data-slide]')];
  const dock = document.querySelector('[data-dock-controls]');
  const previous = document.querySelector('[data-prev]');
  const next = document.querySelector('[data-next]');
  const position = document.querySelector('[data-position]');
  const hint = document.querySelector('[data-scroll-hint]');
  const overview = document.querySelector('[data-overview]');
  const overviewItems = document.querySelector('[data-overview-items]');
  const main = document.querySelector('main');
  const format = root.dataset.souzFormat;
  async function checkFonts() {
    const sample = 'Яндекс Очиститель воздуха Сбер 0123456789';
    const roles = [
      {role:'body',element:main.querySelector('[data-entity-name],p') || main,weight:400},
      {role:'heading',element:main.querySelector('h1,h2,h3') || main,weight:600},
    ];
    const report = [];
    for (const item of roles) {
      const computed = getComputedStyle(item.element);
      const family = computed.fontFamily.split(',')[0].trim().replace(/^['"]|['"]$/g,'');
      try {
        const faces = await document.fonts.load(`${item.weight} 24px "${family}"`,sample);
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        context.font = `${item.weight} 24px "${family}",monospace`;
        const actualWidth = context.measureText(sample).width;
        context.font = `${item.weight} 24px monospace`;
        const fallbackWidth = context.measureText(sample).width;
        report.push({role:item.role,family,weight:item.weight,loaded:faces.length > 0 && faces.every(face => face.status === 'loaded'),differsFromFallback:Math.abs(actualWidth-fallbackWidth) > .1});
      } catch (_) {
        report.push({role:item.role,family,loaded:false,differsFromFallback:false});
      }
    }
    const passed = report.every(item => item.loaded && item.differsFromFallback);
    root.dataset.fontStatus = passed ? 'loaded' : 'fallback';
    root.dataset.bodyFont = report[0].family;
    document.querySelector('[data-font-warning]').hidden = passed;
    document.querySelector('[data-font-report]').textContent = JSON.stringify(report,null,2);
    document.querySelector('[data-font-details]').hidden = passed && root.dataset.fontDiagnostics !== 'true';
    if (format !== 'document') measure();
  }
  void checkFonts();
  if (format === 'document') return;
  const ratio = root.dataset.souzRatio.split(':').map(Number).reduce((a,b) => a / b);
  let current = 0;
  let lastFocus;
  let dockTimer;
  let tabNavigation = false;
  dock.hidden = format !== 'slides';

  function measure() {
    const width = Math.min(innerWidth,innerHeight * ratio);
    root.style.setProperty('--stage-width',`${width}px`);
    root.style.setProperty('--stage-height',`${width / ratio}px`);
    root.style.setProperty('--u',`${width / 1280}px`);
    const slide = slides[current];
    const overflow = slide.scrollHeight > slide.clientHeight + 2;
    slide.dataset.overflow = String(overflow);
    hint.hidden = !overflow;
  }
  function hideDock() {
    clearTimeout(dockTimer);
    if (tabNavigation && dock.contains(document.activeElement)) return;
    if (dock.contains(document.activeElement)) slides[current].focus({preventScroll:true});
    root.dataset.dockVisible = 'false';
    dock.inert = true;
    dock.setAttribute('aria-hidden','true');
  }
  function revealDock() {
    if (format !== 'slides' || !overview.hidden) return;
    clearTimeout(dockTimer);
    root.dataset.dockVisible = 'true';
    dock.inert = false;
    dock.removeAttribute('aria-hidden');
    dockTimer = setTimeout(hideDock,3000);
  }
  function show(index,focusContent=false) {
    current = Math.max(0,Math.min(index,slides.length-1));
    slides.forEach((slide,i) => {
      slide.hidden = i !== current;
      if (i === current) slide.setAttribute('aria-current','step');
      else slide.removeAttribute('aria-current');
    });
    previous.disabled = current === 0;
    next.disabled = current === slides.length-1;
    position.textContent = `${current+1} / ${slides.length}`;
    slides[current].scrollTop = 0;
    if (focusContent) slides[current].focus({preventScroll:true});
    else if (document.activeElement === next && next.disabled) previous.focus();
    else if (document.activeElement === previous && previous.disabled) next.focus();
    measure();
    revealDock();
  }
  slides.forEach((slide,i) => {
    slide.tabIndex = 0;
    const button = document.createElement('button');
    button.type = 'button';
    button.dataset.jump = String(i);
    const heading = slide.querySelector('h1,h2')?.cloneNode(true);
    heading?.querySelectorAll('br').forEach(br => br.replaceWith(' '));
    button.textContent = `${i+1}. ${(heading?.textContent || 'Слайд').replace(/\s+/g,' ').trim()}`;
    button.addEventListener('click',() => { closeOverview(); show(i,true); });
    overviewItems.append(button);
  });
  function openOverview() {
    lastFocus = document.activeElement;
    clearTimeout(dockTimer);
    overviewItems.querySelectorAll('[data-jump]').forEach((button,i) => {
      if (i === current) button.setAttribute('aria-current','step');
      else button.removeAttribute('aria-current');
    });
    overview.hidden = false;
    main.inert = true;
    root.dataset.dockVisible = 'false';
    dock.inert = true;
    dock.setAttribute('aria-hidden','true');
    overviewItems.children[current].focus();
  }
  function closeOverview() {
    overview.hidden = true;
    main.inert = false;
    revealDock();
    if (lastFocus?.isConnected) lastFocus.focus();
  }
  previous.addEventListener('click',() => show(current-1));
  next.addEventListener('click',() => show(current+1));
  document.querySelector('[data-open-overview]').addEventListener('click',openOverview);
  document.querySelector('[data-close-overview]').addEventListener('click',closeOverview);
  document.addEventListener('pointermove',revealDock,{passive:true});
  document.addEventListener('pointerdown',() => { tabNavigation = false; revealDock(); },{passive:true});
  document.addEventListener('touchstart',() => { tabNavigation = false; revealDock(); },{passive:true});
  dock.addEventListener('focusin',revealDock);
  dock.addEventListener('focusout',revealDock);
  document.addEventListener('keydown',event => {
    if (!(event.target instanceof Element) || event.target.closest('input,textarea,select,[contenteditable="true"]')) return;
    if (!overview.hidden) {
      if (event.key === 'Escape') { event.preventDefault(); closeOverview(); }
      if (event.key === 'Tab') {
        const buttons = [...overview.querySelectorAll('button')];
        const index = buttons.indexOf(document.activeElement);
        event.preventDefault();
        buttons[(index + (event.shiftKey ? -1 : 1) + buttons.length) % buttons.length].focus();
      }
      return;
    }
    if (format !== 'slides') return;
    tabNavigation = event.key === 'Tab';
    revealDock();
    const index = {ArrowLeft:current-1,PageUp:current-1,ArrowRight:current+1,PageDown:current+1,Home:0,End:slides.length-1}[event.key];
    if (index !== undefined) { event.preventDefault(); show(index,true); }
    if (['Enter',' '].includes(event.key) && !event.target.closest('button,a,summary')) {
      event.preventDefault();
      (next.disabled ? previous : next).focus();
    }
    if (event.key.toLowerCase() === 'o') { event.preventDefault(); openOverview(); }
    if (['ArrowUp','ArrowDown'].includes(event.key) && slides[current].dataset.overflow === 'true') {
      event.preventDefault();
      slides[current].scrollBy({top:event.key === 'ArrowDown' ? 140 : -140});
    }
  });
  let touch;
  document.querySelector('main').addEventListener('touchstart',event => {
    const point = event.changedTouches[0];
    touch = {x:point.clientX,y:point.clientY};
  },{passive:true});
  document.querySelector('main').addEventListener('touchend',event => {
    if (!touch || format !== 'slides') return;
    const point = event.changedTouches[0];
    const dx = point.clientX-touch.x,dy = point.clientY-touch.y;
    if (Math.abs(dx) > 70 && Math.abs(dx) > Math.abs(dy)*1.5) show(current+(dx < 0 ? 1 : -1));
    touch = null;
  },{passive:true});
  addEventListener('resize',measure);
  show(0);
  document.fonts.ready.then(measure);
})();
