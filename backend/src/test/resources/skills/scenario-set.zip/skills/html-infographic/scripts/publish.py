"""Publish an HTML document from authored sections."""
import json
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from compose import write_html

WORKSPACE = Path('/souz/workspace/html-infographic')


def text(value, field):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f'{field} must be a nonempty string')
    return value.strip()


def publish(slug, spec, directory=WORKSPACE):
    if not re.fullmatch(r'[a-z0-9][a-z0-9-]{0,63}', slug):
        raise ValueError('slug must contain 1–64 lowercase ASCII letters, digits or hyphens')
    payload = json.loads(spec)
    if not isinstance(payload, dict):
        raise ValueError('spec must be a JSON object')
    if payload.get('layout', 'custom') != 'custom':
        raise ValueError('layout must be custom')
    title = text(payload.get('title'), 'title')
    surface = payload.get('surface', 'chat')
    form = payload.get('format', 'single' if surface == 'tv' else 'document')
    content = text(payload.get('html'), 'html')
    return write_html(
        directory / f'{slug}.html', content, title, create_parent=True, surface=surface, form=form,
        ratio=text(payload.get('ratio', '16:9'), 'ratio'), theme=payload.get('theme', 'sber'),
        icons=payload.get('icons', 'lucide'), body_font=payload.get('bodyFont', 'display'),
    )


if __name__ == '__main__':
    try:
        if len(sys.argv) != 3:
            raise ValueError('Expected a slug and one JSON spec argument')
        print(json.dumps(publish(*sys.argv[1:]), ensure_ascii=False))
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(str(error), file=sys.stderr)
        raise SystemExit(1)
