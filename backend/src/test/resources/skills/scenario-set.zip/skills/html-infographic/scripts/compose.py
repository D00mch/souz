"""Compose a standalone document from authored sections and local design assets."""
import argparse
import base64
import hashlib
import html
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.dont_write_bytecode = True


def font_css(keys):
    folder = ROOT / 'assets/fonts'
    catalog = json.loads((folder / 'catalog.json').read_text())
    rules = []
    for key in keys:
        font = catalog[key]
        encoded = ''.join((folder / part).read_text() for part in font['chunks'])
        data = base64.b64decode(encoded, validate=True)
        if data[:4] != b'wOF2' or hashlib.sha256(data).hexdigest() != font['sha256']:
            raise ValueError('Font asset checksum mismatch: ' + key)
        rules.append("@font-face{font-family:'Souz " + font['family'] + "';font-style:normal;font-weight:" + str(font['weight']) + ";font-display:swap;src:url(data:font/woff2;base64," + encoded + ") format('woff2');}")
    return '\n'.join(rules)


def compose(content, title, surface='chat', form='document', ratio='16:9', theme='sber', icons='lucide', custom_font_css='', body_font='display', diagnostics=False):
    if surface not in ('chat','mobile','tv') or form not in ('document','single','slides') or theme not in ('sber','nocturne','editorial') or icons not in ('lucide','phosphor'):
        raise ValueError('Invalid design profile')
    if not re.fullmatch(r'[1-9]\d{0,2}:[1-9]\d{0,2}', ratio):
        raise ValueError('Use positive integer proportions')
    if re.search(r'<\s*(?:html|head|body)\b', content, re.I):
        raise ValueError('Author section fragments, not a complete document')
    catalog = json.loads((ROOT / ('assets/' + icons + '-icons.json')).read_text())
    def icon(name):
        if name not in catalog:
            raise ValueError('Unknown icon ' + name + '; available: ' + ', '.join(sorted(catalog)))
        svg = catalog[name]
        svg = re.sub(r'<svg\b[^>]*>',lambda match: re.sub(r'\s(?:width|height)="[^"]*"','',match[0]),svg,count=1)
        return '<span class="icon" aria-hidden="true">' + svg + '</span>'
    content = re.sub(r'\{\{icon:([a-z-]+)\}\}', lambda match: icon(match[1]), content)
    if '{{icon:' in content:
        raise ValueError('Unresolved icon placeholder')
    if body_font not in ('display','text'):
        raise ValueError('Choose display or text for body typography')
    keys = ['sb-display-regular','sb-display-semibold'] if body_font == 'display' else ['sb-text-regular','sb-text-semibold','sb-display-semibold']
    style = font_css(keys)
    style += '\n' + (ROOT / 'assets/theme.css').read_text()
    if body_font == 'text':
        style += "\n:root{--body-font:'Souz SB Sans Text';}"
    style += '\n' + custom_font_css
    if '</style' in style.lower():
        raise ValueError('Unexpected style end tag')
    viewer = (ROOT / 'assets/viewer.js').read_text()
    notices = (ROOT / 'assets/asset-notices.md').read_text().replace('--','—')
    return ('<!doctype html>\n<html lang="ru" data-souz-surface="' + surface + '" data-souz-format="' + form + '" data-souz-ratio="' + ratio + '" data-theme="' + theme + '" data-font-diagnostics="' + str(diagnostics).lower() + '">\n'
            '<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>' + html.escape(title) + '</title><style>' + style + '</style></head>\n<body><main>' + content + '</main>\n'
            '<nav class="dock" data-dock-controls aria-label="Навигация по презентации" hidden>'
            '<button type="button" data-open-overview aria-label="Все слайды">' + icon('grid') + '</button>'
            '<span data-scroll-hint hidden aria-label="Слайд можно прокрутить вниз">↓</span>'
            '<span data-font-warning hidden role="status">Шрифт недоступен</span>'
            '<button type="button" data-prev aria-label="Предыдущий слайд">' + icon('left') + '</button>'
            '<span data-position role="status" aria-live="polite"></span>'
            '<button type="button" data-next aria-label="Следующий слайд">' + icon('right') + '</button></nav>\n'
            '<aside class="overview" data-overview role="dialog" aria-modal="true" aria-label="Все слайды" hidden>'
            '<div class="overview-header"><h2>Все слайды</h2><button type="button" data-close-overview aria-label="Закрыть обзор">' + icon('close') + '</button></div><div data-overview-items></div></aside>\n'
            '<details class="font-details" data-font-details hidden><summary>Шрифты</summary><pre data-font-report role="status">Проверка загрузки…</pre></details>\n'
            '<script>' + viewer + '</script>\n<!-- ' + notices + ' -->\n</body></html>\n')


def write_html(output, content, title, *, create_parent=False, **options):
    if len(content.encode('utf-8')) > 1_000_000:
        raise ValueError('Section source exceeds 1 MB')
    result = compose(content, title, **options)
    if len(result.encode('utf-8')) > 5_000_000:
        raise ValueError('HTML exceeds 5 MB')
    from check_html import check
    # Check the assembled bytes before publishing the requested new output path.
    import tempfile
    with tempfile.TemporaryDirectory() as directory:
        candidate = Path(directory) / 'candidate.html'
        candidate.write_text(result,encoding='utf-8')
        report = check(candidate)
    if not report['staticPassed']:
        raise ValueError('; '.join(report['errors']))
    if create_parent:
        output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x', encoding='utf-8') as stream:
        stream.write(result)
    return {'path': str(output), 'bytes': len(result.encode('utf-8')), 'staticChecks': report}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('content', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--title', required=True)
    parser.add_argument('--surface', choices=['chat','mobile','tv'], default='chat')
    parser.add_argument('--format', choices=['document','single','slides'], default='document')
    parser.add_argument('--ratio', default='16:9')
    parser.add_argument('--theme', choices=['sber','nocturne','editorial'], default='sber')
    parser.add_argument('--icons', choices=['lucide','phosphor'], default='lucide')
    parser.add_argument('--font-css', type=Path, help='Optional local @font-face and font token overrides, embedded in the output')
    parser.add_argument('--body-font',choices=['display','text'],default='display')
    parser.add_argument('--diagnostics',action='store_true')
    args = parser.parse_args()
    try:
        content = args.content.read_text(encoding='utf-8')
        report = write_html(args.output, content, args.title, surface=args.surface, form=args.format,
                            ratio=args.ratio, theme=args.theme, icons=args.icons,
                            custom_font_css=args.font_css.read_text() if args.font_css else '',
                            body_font=args.body_font, diagnostics=args.diagnostics)
        print(json.dumps(report, ensure_ascii=False))
    except (OSError,ValueError,KeyError) as error:
        print(json.dumps({'error':str(error)},ensure_ascii=False))
        raise SystemExit(1)
