"""Deterministic catalogue layout and arithmetic for owner-supplied snapshots."""
import argparse
from collections import Counter
from html import escape
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True
STATES = {'on':'Включено','off':'Выключено','offline':'Офлайн','unknown':'Нет данных'}
ICONS = {'home','bulb','power','wifi','tv','speaker','shield','left','right','grid','expand','collapse','check','close','chart','calendar','clock','layers','plug','temperature','snow','info','room','route'}


def text(value,field,limit=160):
    if not isinstance(value,str) or not value.strip() or len(value)>limit:
        raise ValueError('Invalid ' + field)
    return value.strip()


def check_count(source,key,actual,message):
    value=source.get(key,actual)
    if type(value) is not int or value!=actual:raise ValueError(message)


def normalize(data):
    if not isinstance(data,dict) or not isinstance(data.get('catalogues'),list) or not data['catalogues']:
        raise ValueError('Supply a nonempty catalogues array')
    result={'title':text(data.get('title'),'title'),'source':text(data.get('source'),'source',500),'asOf':data.get('asOf'),'catalogues':[]}
    if result['asOf'] is not None:
        result['asOf']=text(result['asOf'],'asOf')
    records=[]
    for ci,catalogue in enumerate(data['catalogues']):
        name=text(catalogue.get('name'),'catalogue.name')
        groups=catalogue.get('groups')
        if not isinstance(groups,list) or not groups:
            raise ValueError('Catalogue groups must be nonempty')
        known_ids=set();normalized_groups=[];count=0
        for gi,group in enumerate(groups):
            group_name=text(group.get('name'),'group.name')
            devices=group.get('devices')
            if not isinstance(devices,list) or not devices:
                raise ValueError('Group devices must be nonempty')
            rows=[]
            for di,device in enumerate(devices):
                if not isinstance(device,dict):raise ValueError('Device must be an object')
                state=device.get('state')
                if state is None:state='unknown'
                if state not in STATES:raise ValueError('State must be on, off, offline or unknown')
                icon=device.get('icon','layers')
                if icon not in ICONS:raise ValueError('Choose an icon from the bundled catalogue')
                source_id=device.get('id')
                if source_id is not None:
                    source_id=text(source_id,'device.id')
                    if source_id in known_ids:raise ValueError('Duplicate device ID within a catalogue')
                    known_ids.add(source_id)
                row={'ref':f'{ci}/{gi}/{di}','id':source_id,'name':text(device.get('name'),'device.name',100),'state':state,'icon':icon,'catalogue':name,'group':group_name}
                rows.append(row);records.append(row)
            check_count(group,'expectedCount',len(rows),'Source group count does not match supplied records')
            normalized_groups.append({'name':group_name,'devices':rows});count+=len(rows)
        check_count(catalogue,'expectedCount',count,'Source catalogue count does not match supplied records')
        check_count(catalogue,'expectedGroups',len(groups),'Source group count does not match supplied groups')
        result['catalogues'].append({'name':name,'groups':normalized_groups,'count':count})
    if len(records)>200:raise ValueError('Split catalogues with more than 200 records')
    check_count(data,'expectedCount',len(records),'Source total does not match supplied records')
    result['records']=records
    result['counts']={key:Counter(row['state'] for row in records)[key] for key in STATES}
    return result


def plan(snapshot,max_rows=4):
    pages=[]
    for catalogue in snapshot['catalogues']:
        cards=[]
        for group in catalogue['groups']:
            rows=group['devices']
            weights=[max(1,math.ceil(len(row['name'])/24)) for row in rows]
            parts=max(1,math.ceil(sum(weights)/max_rows));budget=math.ceil(sum(weights)/parts)
            chunks=[];chunk=[];used=0
            for row,weight in zip(rows,weights):
                if chunk and used+weight>budget:
                    chunks.append(chunk);chunk=[];used=0
                chunk.append(row);used+=weight
            if chunk:chunks.append(chunk)
            for i,chunk in enumerate(chunks):
                cards.append({'title':group['name'],'part':f'{i+1}/{len(chunks)}' if len(chunks)>1 else None,'catalogue':catalogue['name'],'rows':chunk})
        for i in range(0,len(cards),2):
            pages.append({'catalogue':catalogue['name'],'cards':cards[i:i+2]})
    if len(pages)+1>24:raise ValueError('Split the catalogue into separate documents')
    return pages


def entity_row(row):
    return ('<div class="entity-row" data-entity-ref="'+row['ref']+'" data-state="'+row['state']+'">{{icon:'+row['icon']+'}}'
            '<span data-entity-name>'+escape(row['name'])+'</span><span data-status>'+STATES[row['state']]+'</span></div>')


def card(item):
    label=item['catalogue']+(' · '+item['part'] if item['part'] else '')
    return ('<article class="entity-card"><header class="entity-card-head"><div class="entity-card-title">'
            '<span class="label">'+escape(label)+'</span><h3>'+escape(item['title'])+'</h3></div>'
            '<span class="entity-count" aria-label="Записей в карточке">'+str(len(item['rows']))+'</span></header>'
            '<div class="entity-list">'+''.join(entity_row(row) for row in item['rows'])+'</div></article>')


def render(data):
    snapshot=normalize(data);pages=plan(snapshot)
    counts=snapshot['counts'];total=len(snapshot['records'])
    source=snapshot['source']+(' · '+snapshot['asOf'] if snapshot['asOf'] else ' · время снимка не указано')
    pairs=''.join('<div class="stat-pair"><span>'+escape(cat['name'])+'</span><strong>'+str(cat['count'])+'</strong></div>' for cat in snapshot['catalogues'])
    states=''.join('<div class="stat-pair"><span>'+label+'</span><strong data-count="'+state+'">'+str(counts[state])+'</strong></div>' for state,label in STATES.items())
    active=[row['name'] for row in snapshot['records'] if row['state']=='on']
    summary='Подтверждённо включены: '+', '.join(active[:4])+('. Ещё '+str(len(active)-4)+' — в списках ниже.' if len(active)>4 else '.') if active else 'Подтверждённых включённых устройств в снимке нет.'
    overview=('<section data-slide data-layout="inventory-overview"><div class="slide-inner"><div class="split">'
              '<div class="stack"><h1 class="hero-title">'+escape(snapshot['title'])+'</h1><div class="metric"><span class="number" data-count="total">'+str(total)+'</span><span class="label">записей в каталогах</span></div></div>'
              '<div class="stack"><div class="tile">'+pairs+'</div><div class="state-summary">'+states+'</div></div></div>'
              '<p class="active-summary">'+escape(summary)+'</p><p class="inventory-note">'+escape(source)+'</p></div></section>')
    sections=[overview]
    for page in pages:
        sections.append('<section data-slide data-layout="inventory"><div class="slide-inner"><h2 class="inventory-heading">'+escape(page['catalogue'])+' · устройства по локациям</h2><div class="entity-grid">'+''.join(card(item) for item in page['cards'])+'</div></div></section>')
    payload=json.dumps(data,ensure_ascii=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    return '\n'.join(sections)+'<script type="application/json" data-inventory>'+payload+'</script>'


def validate_rendered(doc):
    """Verify visible catalogue rows and counters against the embedded source snapshot."""
    payloads=[script['source'] for script in doc.scripts if script.get('inventory')]
    if len(payloads)!=1:return ['Inventory output must include one source snapshot']
    try:snapshot=normalize(json.loads(payloads[0]))
    except (ValueError,TypeError,AttributeError) as error:return ['Invalid inventory source: '+str(error)]
    expected={row['ref']:row for row in snapshot['records']};seen=set();errors=[]
    for node in doc.nodes:
        attrs=node['attrs']
        if 'entity-row' in (attrs.get('class') or '').split():
            ref=attrs.get('data-entity-ref')
            if ref not in expected or ref in seen:
                errors.append('Inventory row is duplicate or absent from the source');continue
            seen.add(ref);row=expected[ref]
            children=[child for child in doc.descendants(node) if 'data-entity-name' in child['attrs'] or 'data-status' in child['attrs']]
            names=[child for child in children if 'data-entity-name' in child['attrs']];statuses=[child for child in children if 'data-status' in child['attrs']]
            if len(names)!=1 or len(statuses)!=1:errors.append('Entity names and statuses need separate standard elements');continue
            if doc.text_content(names[0]).strip()!=row['name'] or attrs.get('data-state')!=row['state'] or doc.text_content(statuses[0]).strip()!=STATES[row['state']]:
                errors.append('Rendered entity name or state differs from the source')
        if 'entity-card' in (attrs.get('class') or '').split():
            rows=[child for child in doc.descendants(node) if 'entity-row' in (child['attrs'].get('class') or '').split()]
            titles=[child for child in doc.descendants(node) if child['tag']=='h3']
            groups={expected[child['attrs']['data-entity-ref']]['group'] for child in rows if child['attrs'].get('data-entity-ref') in expected}
            if len(titles)!=1 or groups!={doc.text_content(titles[0]).strip()}:
                errors.append('Inventory card title does not match its source group')
            if len(rows)>4:errors.append('Inventory card exceeds four rows; split it before delivery')
            if sum(max(1,math.ceil(len(expected.get(child['attrs'].get('data-entity-ref'),{}).get('name',''))/24)) for child in rows)>5:
                errors.append('Inventory card exceeds its text budget; split long names into another card')
    if seen!=set(expected):errors.append('Inventory output omits source records')
    wanted=dict(snapshot['counts'],total=len(expected));counters={}
    for node in doc.nodes:
        key=node['attrs'].get('data-count')
        if key is not None:
            if key in counters:errors.append('Duplicate inventory summary counter')
            counters[key]=doc.text_content(node).strip()
    if counters!={key:str(value) for key,value in wanted.items()}:errors.append('Inventory totals do not match the source snapshot')
    return errors


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source',type=Path);parser.add_argument('output',type=Path)
    parser.add_argument('--surface',choices=['chat','mobile','tv'],default='tv')
    parser.add_argument('--theme',choices=['sber','nocturne','editorial'],default='nocturne')
    parser.add_argument('--body-font',choices=['display','text'],default='display')
    args=parser.parse_args()
    try:
        if args.source.stat().st_size>1_000_000:raise ValueError('Inventory JSON exceeds 1 MB')
        data=json.loads(args.source.read_text());snapshot=normalize(data)
        from compose import compose
        page=compose(render(data),snapshot['title'],surface=args.surface,form='slides' if args.surface=='tv' else 'document',theme=args.theme,body_font=args.body_font)
        page=page.replace('data-theme="','data-kind="inventory" data-theme="',1)
        import tempfile
        from check_html import check
        with tempfile.TemporaryDirectory() as folder:
            candidate=Path(folder)/'inventory.html';candidate.write_text(page);report=check(candidate)
        if not report['staticPassed']:raise ValueError('; '.join(report['errors']))
        with args.output.open('x') as output:output.write(page)
        print(json.dumps({'path':str(args.output),'records':len(snapshot['records']),'counts':snapshot['counts'],'staticChecks':report},ensure_ascii=False))
    except (OSError,ValueError,KeyError,TypeError,AttributeError) as error:
        print(json.dumps({'error':str(error)},ensure_ascii=False));raise SystemExit(1)
