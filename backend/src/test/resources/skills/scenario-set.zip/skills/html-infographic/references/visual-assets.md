# Embedded visual assets

## Fonts

Display Regular is the default ordinary interface text so its character is consistent with Display headings. Text is a separate body cut and can look closer to a conventional sans-serif. Both are actual SB fonts.

The personal bundle includes SB Sans Text Regular (400) and Semibold (600), plus SB Sans Display Regular (400) and Semibold (600), version 0.2.0 from the official CDN referenced in https://plasma.sberdevices.ru/sdds-sbcom/components/typography/. The composer embeds Display 400/600 by default. --body-font text selects Text 400/600 with Display 600 headings; it does not contact the CDN. Family names, weights, source URLs and SHA-256 are in assets/fonts/catalog.json. Encoded chunks are machine assets: do not read their contents into the model conversation.

Custom owner-provided font files can be prepared with PrepareAttachment and embedded using scripts/embed_font.py, then supplied through compose.py --font-css. Bundled faces use private CSS aliases Souz SB Sans Display / Souz SB Sans Text to avoid collision with installed fonts. The viewer tests Cyrillic loading and fallback metrics; --diagnostics exposes its per-role report.

The custom CSS sets --heading-font or --body-font and contains a data: font face. For a separate regular and semibold font, create two CSS files and combine their text in the workspace before composing. Keep weights accurate. WOFF2 is preferred; no operating-system font installation or external font service is involved.

## Icon sets

Choose --icons lucide for a consistent outline family or --icons phosphor for the Phosphor regular family. The bundle contains real SVG sources from both official repositories, pinned to recorded commits. Licenses are in assets/asset-notices.md and are included as a comment in generated HTML. Never substitute emoji for these icons or mix the sets accidentally within one document.

Available names in both sets:

home, bulb, power, wifi, tv, speaker, shield, left, right, grid, expand, collapse, check, close, chart, calendar, clock, layers, plug, temperature, snow, info, room, route.

Write {{icon:home}} in an authored section. The composer expands only used icons as inline SVG with currentColor inside an aria-hidden span. Put the text label beside the icon; give meaningful figures an accessible name. If a needed icon is absent, draw an appropriate simple inline SVG or use an owner-supplied SVG instead of inventing a nonexistent catalogue name. Remote sprite sheets and icon-font/CDN dependencies are forbidden.

## Themes and navigation

- sber: pale mineral surface, deep green text/accent, bright panels and SB Sans; a useful default for the user's corporate material.
- nocturne: ink-blue canvas, mint accent, layered dark panels; suited to a high-contrast screen presentation.
- editorial: warm paper, oxblood accent and more restrained panels; suited to a narrative or analysis.

The shell is a small design vocabulary, not a compulsory page grid. Author scoped CSS and custom SVG as needed. Adjust colour tokens and heading/body font tokens while preserving contrast. Keep theme/typography consistent across the material.

The floating dock is a separate overlay, with previous/next, position and overview. Its footer band is excluded from the scrollable content height, preserving full stage width. An overview button shows titles and direct jumps, O opens it, Escape closes it. Reduced-motion settings are respected. The source content never depends on hover, storage, cookies, a backend callback or full-screen permission.

All embedded assets remain subject to their own source terms; no open-source licence is asserted for SB Sans. Keep owner-provided assets within the owner's permitted use. Do not publish font assets or the personal bundle automatically.
