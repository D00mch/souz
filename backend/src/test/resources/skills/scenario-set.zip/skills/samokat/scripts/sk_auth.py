"""Phone/SMS login with separate pending credentials and deduplicated requests."""
import copy
import re
import time
import uuid
from sk_client import Client, claims
from sk_store import Failure


def public_pending(value):
    return dict(ok=True, state=value['state'], auth_session_id=value['id'],
                code_length=value.get('code_length'), expires_at=value['expires'])


def operation(store, args, method, data):
    request_id = args.get('request_id')
    if not isinstance(request_id, str) or not 8 <= len(request_id) <= 128:
        raise Failure('INVALID_ARGUMENTS', 'Нужен уникальный request_id длиной 8–128 символов.')
    fingerprint = store.fingerprint(dict(method=method, data=data))
    old = store.operation(request_id)
    if old:
        if old.get('fingerprint') != fingerprint:
            raise Failure('REQUEST_ID_CONFLICT', 'Этот request_id принадлежит другому действию.')
        if old.get('status') == 'done':
            return request_id, fingerprint, dict(old['result'], cached=True)
        raise Failure('OPERATION_OUTCOME_UNKNOWN', 'Не повторяй запрос входа: его исход неизвестен.', request_id=request_id)
    return request_id, fingerprint, None


def start(store, args):
    phone = args.get('phone')
    if not isinstance(phone, str):
        raise Failure('INVALID_ARGUMENTS', 'Укажи российский мобильный номер.')
    digits = re.sub(r'[^0-9]', '', phone)
    if len(digits) == 11 and digits[0] == '8':
        digits = '7' + digits[1:]
    if len(digits) != 11 or not digits.startswith('7'):
        raise Failure('INVALID_ARGUMENTS', 'Укажи номер в формате +7XXXXXXXXXX.')
    phone = '+' + digits
    request_id, fingerprint, cached = operation(store, args, 'start_phone_auth', phone)
    if cached:
        return cached
    existing = store.get('phone_auth')
    if existing and existing['expires'] > time.time() and existing['state'] in ('sms_requested', 'sms_outcome_unknown', 'code_outcome_unknown'):
        raise Failure('AUTH_IN_PROGRESS', 'Подтверждение входа уже начато; используй действующий auth_session_id.',
                      auth_session_id=existing['id'])
    session = store.get('session')
    if not session:
        initialize(store, {})
        session = store.get('session')
    draft = copy.deepcopy(session)
    draft['headers']['x-user-type'] = 'anonymous'
    draft['headers'].pop('x-user-id', None)
    draft['refresh_unknown'] = False
    store.put('phone_session', draft)
    client = Client(store, 'phone_session')
    try:
        pending = dict(id=str(uuid.uuid4()), phone=phone, state='sms_outcome_unknown',
                       expires=time.time() + 600)
        store.put('phone_auth', pending)
        store.save_operation(request_id, dict(status='pending', fingerprint=fingerprint))
        try:
            response = client.raw('POST', '/confirmation/code', {'phoneNumber': phone}, authenticated=False)
        except Failure as error:
            if error.result.get('http_status') in (400, 401, 403, 404, 409, 422, 429):
                pending['state'] = 'rejected'
                store.put('phone_auth', pending)
                store.save_operation(request_id, dict(status='done', fingerprint=fingerprint, result=error.result))
            raise
        pending.update(state='sms_requested', code_length=response.get('codeLength'),
                       retry_at=time.time()+max(60, min(600, response.get('retryTimeout', 60))))
        store.put('phone_auth', pending)
        result = public_pending(pending)
        store.save_operation(request_id, dict(status='done', fingerprint=fingerprint, result=result))
        return result
    finally:
        client.close()


def submit(store, args):
    auth_id, code = args.get('auth_session_id'), args.get('code')
    if not isinstance(code, str) or not re.fullmatch('[0-9]{4,8}', code):
        raise Failure('INVALID_ARGUMENTS', 'SMS-код нужно передать строкой из 4–8 цифр.')
    request_id, fingerprint, cached = operation(store, args, 'submit_sms_code', [auth_id, code])
    if cached:
        return cached
    pending = store.get('phone_auth')
    if not pending or pending['id'] != auth_id or pending['expires'] <= time.time():
        if pending and pending['expires'] <= time.time():
            store.put('phone_auth', None)
            store.put('phone_session', None)
        raise Failure('AUTH_SESSION_EXPIRED', 'Подтверждение входа истекло или не найдено.')
    if pending['state'] not in ('sms_requested', 'sms_outcome_unknown'):
        raise Failure('AUTH_SESSION_UNAVAILABLE', 'Подтверждение входа пока недоступно; не повторяй неизвестный запрос.')
    expected = pending.get('code_length')
    if isinstance(expected, int) and len(code) != expected:
        raise Failure('INVALID_ARGUMENTS', 'Длина SMS-кода не совпадает с ответом Самоката.')
    client = Client(store, 'phone_session')
    try:
        store.save_operation(request_id, dict(status='pending', fingerprint=fingerprint))
        pending['state'] = 'code_outcome_unknown'
        store.put('phone_auth', pending)
        try:
            credentials = client.raw('POST', '/oauth/token/otp', {'phone': pending['phone'], 'code': code}, authenticated=False)
        except Failure as error:
            if error.result.get('http_status') in (400, 401, 403, 404, 409, 422, 429):
                pending['state'] = 'sms_requested'
                store.put('phone_auth', pending)
                store.save_operation(request_id, dict(status='done', fingerprint=fingerprint, result=error.result))
            raise
        client.state['credentials'] = credentials
        client.state['account'] = claims(credentials['access_token'])['sub']
        client.state['headers']['x-user-type'] = 'user'
        client.state['headers']['x-user-id'] = client.state['account']
        client.state['refresh_unknown'] = False
        client.persist()
        # Verify the new credentials before replacing the active account.
        client.raw('GET', '/users/profile')
        store.put('session', client.state)
        store.put('phone_auth', None)
        store.put('phone_session', None)
        store.put('seen', {})
        result = dict(ok=True, state='authenticated')
        store.save_operation(request_id, dict(status='done', fingerprint=fingerprint, result=result))
        return result
    finally:
        client.close()


def resend(store, args):
    pending = store.get('phone_auth')
    auth_id = args.get('auth_session_id')
    request_id, fingerprint, cached = operation(store, args, 'resend_sms_code', auth_id)
    if cached:
        return cached
    if not pending or pending['id'] != auth_id or pending['expires'] <= time.time():
        raise Failure('AUTH_SESSION_EXPIRED', 'Подтверждение входа истекло или не найдено.')
    if pending['state'] != 'sms_requested':
        raise Failure('AUTH_SESSION_UNAVAILABLE', 'Нельзя повторять запрос с неизвестным исходом.')
    if pending.get('retry_at', pending['expires']-540) > time.time():
        raise Failure('CODE_RETRY_TIMEOUT', 'Подожди перед повторной отправкой SMS.')
    client = Client(store, 'phone_session')
    try:
        store.save_operation(request_id, dict(status='pending', fingerprint=fingerprint))
        pending['state'] = 'sms_outcome_unknown'
        store.put('phone_auth', pending)
        try:
            response = client.raw('POST', '/confirmation/code', {'phoneNumber': pending['phone']}, authenticated=False)
        except Failure as error:
            if error.result.get('http_status') in (400, 401, 403, 404, 409, 422, 429):
                pending['state'] = 'sms_requested'
                store.put('phone_auth', pending)
                store.save_operation(request_id, dict(status='done', fingerprint=fingerprint, result=error.result))
            raise
        pending.update(state='sms_requested', code_length=response.get('codeLength'), expires=time.time()+600,
                       retry_at=time.time()+max(60, min(600, response.get('retryTimeout', 60))))
        store.put('phone_auth', pending)
        result = public_pending(pending)
        store.save_operation(request_id, dict(status='done', fingerprint=fingerprint, result=result))
        return result
    finally:
        client.close()


def initialize(store, args):
    session = store.get('session')
    if not session:
        from sk_bootstrap import create_transport
        session = create_transport(proxy=store.get('https_proxy'))
        store.put('session', session)
    return dict(ok=True, transport_ready=True)
