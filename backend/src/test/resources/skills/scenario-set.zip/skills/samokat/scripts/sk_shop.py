"""Selected-address search and versioned, journaled cart changes of ordinary products."""
import time
import uuid
from sk_store import Failure


def fail(code, text, **details):
    raise Failure(code, text, **details)


def product_id(value):
    try:
        if str(uuid.UUID(value)) != value:
            raise ValueError()
        return value
    except (ValueError, TypeError, AttributeError):
        fail('INVALID_ARGUMENTS', 'Нужен product_id из результатов Самоката.')


def counts(cart):
    result = {}
    for item in cart.get('products', []):
        key = item.get('productId')
        if key in result or item.get('type') != 'PRODUCT' or type(item.get('quantity')) is not int:
            fail('UNSUPPORTED_CART', 'В корзине есть составные или неподдерживаемые позиции; измени их в приложении.')
        result[key] = item['quantity']
    return result


def summarize(cart):
    return dict(products=[dict(product_id=x['productId'],
                               name=(x.get('product') or {}).get('name'),
                               quantity=x['quantity'], price_rub=x.get('price', 0) / 100,
                               total_rub=x.get('totalPrice', 0) / 100)
                          for x in cart.get('products', [])],
                total_rub=cart.get('totalPrice', 0) / 100,
                services=[dict(name=x.get('name'), type=x.get('type'),
                               price_rub=x.get('totalPrice', 0) / 100)
                          for x in cart.get('services', [])])


class Shop:
    def __init__(self, store, client):
        self.store, self.client = store, client

    def context(self):
        p = self.client.call('GET', '/users/profile')
        view = p.get('profileView') or {}
        selected = view.get('selectedAddressId')
        address = next((x for x in p.get('addresses', []) if x.get('id') == selected), None)
        if address is None:
            fail('ADDRESS_REQUIRED', 'Выбери адрес доставки в приложении Самоката.')
        if view.get('lastDeliveryOption') != 'DELIVERY':
            fail('DELIVERY_REQUIRED', 'Этот пакет работает с доставкой. Выбери доставку в приложении.')
        rows = self.client.call('GET', '/showcases/list', query={'lat': address['lat'], 'lon': address['lon']})
        candidates = [x for x in rows if x.get('type') == 'MINIMARKET']
        if len(candidates) != 1:
            fail('SHOWCASE_UNAVAILABLE', 'Не удалось однозначно определить магазин для выбранного адреса.')
        return dict(address_id=selected, showcase_id=candidates[0]['showcaseId'],
                    delivery_option='DELIVERY')

    @staticmethod
    def body(context):
        return dict(showcaseId=context['showcase_id'], deliveryOption=context['delivery_option'],
                    embedProductsToResponse=True, buyout=False, offerCode='BASIC_OFFER')

    def cart(self, context):
        response = self.client.call('POST', '/v2/carts/get', self.body(context))
        if response.get('status') != 'ACTUAL' or not isinstance(response.get('cart'), dict):
            fail('CART_UNAVAILABLE', 'Корзину Самоката пока нельзя изменить.')
        cart = response['cart']
        if not cart.get('cartId') or type(cart.get('version')) is not int:
            fail('INVALID_RESPONSE', 'В корзине отсутствует версия.')
        return cart

    def get_cart(self, args):
        context = self.context()
        return dict(ok=True, cart=summarize(self.cart(context)), address_source='selected_in_app')

    def search_products(self, args):
        query = args.get('query')
        if not isinstance(query, str) or not query.strip() or len(query) > 150:
            fail('INVALID_ARGUMENTS', 'Передай непустой поисковый запрос до 150 символов.')
        limit = args.get('limit', 20)
        if type(limit) is not int or not 1 <= limit <= 50:
            fail('INVALID_ARGUMENTS', 'limit должен быть от 1 до 50.')
        context = self.context()
        raw = self.client.call('POST', '/search/products',
                               {'query': query.strip(), 'showcaseIds': [context['showcase_id']]})
        found, seen = [], self.store.get('seen', {})
        now = time.time()
        seen = {k: v for k, v in seen.items() if v['at'] > now - 1800}
        for group in raw.get('result', []):
            if group.get('showcaseId') != context['showcase_id']:
                continue
            for item in group.get('items', []):
                if item.get('type') != 'PRODUCT' or type(item.get('quantity')) is not int:
                    continue
                key = product_id(item.get('id'))
                prices = item.get('prices') or {}
                found.append(dict(product_id=key, name=item.get('name'),
                                  available_quantity=item['quantity'],
                                  price_rub=prices.get('current', 0) / 100,
                                  old_price_rub=prices['old'] / 100 if prices.get('old') is not None else None))
                seen[key] = dict(account=self.client.state['account'], context=context, at=now)
        self.store.put('seen', seen)
        return dict(ok=True, products=found[:limit], has_more=len(found) > limit,
                    address_source='selected_in_app')

    def status(self, args):
        self.client.ensure_auth()
        # Verify the provider rather than treating an unexpired local JWT as a valid login.
        self.client.call('GET', '/users/profile')
        return dict(ok=True, state='authenticated', connection='samokat_api',
                    fresh_phone_login_supported=True)

    def reconcile(self, request_id, operation):
        if operation['status'] == 'done':
            return dict(operation['result'], cached=True)
        if operation['status'] == 'rejected':
            return dict(operation['result'], cached=True)
        context = self.context()
        if context != operation['context']:
            fail('OPERATION_OUTCOME_UNKNOWN', 'После попытки изменился выбранный адрес; не повторяй изменение.',
                 request_id=request_id)
        cart = self.cart(context)
        if cart['cartId'] == operation['cart_id'] and counts(cart) == operation['target_counts']:
            result = dict(ok=True, state='verified', verification='observed_target',
                          request_id=request_id, cart=summarize(cart), changes=operation.get('changes', []))
            operation.update(status='done', result=result)
            self.store.save_operation(request_id, operation)
            return result
        fail('OPERATION_OUTCOME_UNKNOWN', 'Исход изменения корзины неизвестен. Корзина прочитана; не повторяй действие с новым ID.',
             request_id=request_id, cart=summarize(cart))

    def get_operation(self, args):
        request_id = self.request_id(args)
        operation = self.store.operation(request_id)
        if not operation:
            fail('OPERATION_NOT_FOUND', 'Операция с этим request_id не найдена.')
        if operation.get('account') != self.client.state['account']:
            fail('OPERATION_ACCOUNT_CHANGED', 'Операция принадлежит другой сессии аккаунта.')
        return self.reconcile(request_id, operation)

    @staticmethod
    def request_id(args):
        value = args.get('request_id')
        if not isinstance(value, str) or not 8 <= len(value) <= 128 or not all(
                c.isalnum() or c in '-_.' for c in value):
            fail('INVALID_ARGUMENTS', 'Нужен новый request_id длиной 8–128 символов.')
        return value

    def add_products(self, args):
        request_id = self.request_id(args)
        items = args.get('items')
        if not isinstance(items, list) or not 1 <= len(items) <= 30:
            fail('INVALID_ARGUMENTS', 'items должен содержать от 1 до 30 товаров.')
        quantities = {}
        for item in items:
            if not isinstance(item, dict) or set(item) != {'product_id', 'quantity'}:
                fail('INVALID_ARGUMENTS', 'У товара нужны только product_id и quantity.')
            key = product_id(item['product_id'])
            quantity = item['quantity']
            if key in quantities or type(quantity) is not int or not 1 <= quantity <= 100:
                fail('INVALID_ARGUMENTS', 'ID не должны повторяться; quantity — целое число от 1 до 100.')
            quantities[key] = quantity
        fingerprint = self.store.fingerprint(dict(method='add_products', items=quantities))
        previous = self.previous(request_id, fingerprint)
        if previous is not None:
            return previous
        context = self.context()
        cart = self.cart(context)
        before = counts(cart)
        self.writable(cart)
        seen = self.store.get('seen', {})
        additions = []
        for key, amount in quantities.items():
            evidence = seen.get(key) or {}
            if (evidence.get('account') != self.client.state['account'] or evidence.get('context') != context
                    or evidence.get('at', 0) < time.time() - 1800):
                fail('SEARCH_REQUIRED', 'Сначала найди товар для текущего адреса.', product_id=key)
            detail = self.client.call('GET', '/v2/showcases/' + context['showcase_id'] + '/products/' + key)
            quantity = before.get(key, 0) + amount
            stock = detail.get('quantity')
            prices = detail.get('prices') or {}
            price = prices.get('current')
            if type(stock) is not int or stock < quantity:
                fail('INSUFFICIENT_STOCK', 'Недостаточно товара в наличии.', product_id=key,
                     available_quantity=stock, requested_cart_quantity=quantity)
            if type(price) is not int or price < 0:
                fail('INVALID_RESPONSE', 'Не получена цена товара.')
            row = dict(productId=key, quantity=quantity, type='PRODUCT', promotions=[],
                       price=price, totalPrice=price * quantity)
            old_price = prices.get('old')
            if old_price is not None:
                row.update(oldPrice=old_price, totalOldPrice=old_price * quantity)
            additions.append(row)
        products = [{k: v for k, v in x.items() if k != 'product'}
                    for x in cart.get('products', []) if x['productId'] not in quantities]
        products.extend(additions)
        return self.commit_cart('add_products', request_id, fingerprint, context, cart, products, list(quantities))

    def previous(self, request_id, fingerprint):
        old = self.store.operation(request_id)
        if old is None:
            return None
        if old.get('fingerprint') != fingerprint or old.get('account') != self.client.state['account']:
            fail('REQUEST_ID_CONFLICT', 'Этот request_id уже использован для другого действия или аккаунта.')
        return self.reconcile(request_id, old)

    @staticmethod
    def writable(cart):
        # Membership and accrual are not redemption. Only known zero-spend entries are safe.
        loyalty = cart.get('loyalty') or []
        unknown_or_spent = not isinstance(loyalty, list) or any(
            not isinstance(row, dict) or type(row.get('spendBonus')) is not int or row['spendBonus'] != 0
            for row in loyalty)
        if (unknown_or_spent or cart.get('appliedLoyalty') or cart.get('promocode')
                or cart.get('promotionId')):
            fail('UNSUPPORTED_CART', 'В корзине применены специальные условия; измени её в приложении.')

    def commit_cart(self, method, request_id, fingerprint, context, cart, products, changed):
        target = counts(dict(products=products))
        before = counts(cart)
        effects = [dict(product_id=key, before_quantity=before.get(key, 0), after_quantity=target.get(key, 0))
                   for key in sorted(set(before) | set(target)) if before.get(key, 0) != target.get(key, 0)]
        operation = dict(status='pending', fingerprint=fingerprint, account=self.client.state['account'],
                         context=context, cart_id=cart['cartId'], target_counts=target,
                         method=method, changes=effects, created=time.time())
        if counts(cart) == target:
            result = dict(ok=True, state='verified', verification='already_target',
                          request_id=request_id, cart=summarize(cart), changes=effects)
            operation.update(status='done', result=result)
            self.store.save_operation(request_id, operation)
            return result
        payload = dict(self.body(context), products=products,
                       changes=[dict(productId=key) for key in changed],
                       version=cart['version'], hideChangesBanner=False)
        self.client.ensure_auth()
        self.store.save_operation(request_id, operation)
        try:
            response = self.client.raw('PUT', '/v2/carts/' + cart['cartId'], payload)
        except Failure as error:
            if error.result.get('http_status') in (400, 401, 403, 404, 409, 422, 429):
                operation.update(status='rejected', result=dict(error.result, request_id=request_id))
                self.store.save_operation(request_id, operation)
                return operation['result']
            return self.reconcile(request_id, operation)
        if response.get('status') == 'VERSION_MISMATCH':
            result = dict(ok=False, error='CART_VERSION_CHANGED',
                          message='Корзина изменилась параллельно. Прочитай её перед новым решением.',
                          request_id=request_id)
            operation.update(status='rejected', result=result)
            self.store.save_operation(request_id, operation)
            return result
        if response.get('status') != 'ACTUAL':
            fail('OPERATION_OUTCOME_UNKNOWN', 'Самокат сообщил изменение корзины; проверь прежнюю операцию.',
                 request_id=request_id)
        return self.reconcile(request_id, operation)

    def remove_products(self, args):
        request_id = self.request_id(args)
        items = args.get('items')
        if not isinstance(items, list) or not 1 <= len(items) <= 30:
            fail('INVALID_ARGUMENTS', 'items должен содержать от 1 до 30 товаров.')
        wanted = {}
        for item in items:
            if (not isinstance(item, dict) or 'product_id' not in item
                    or set(item) - {'product_id', 'quantity'}):
                fail('INVALID_ARGUMENTS', 'Нужны product_id и необязательное quantity.')
            key = product_id(item['product_id'])
            amount = item.get('quantity')
            if key in wanted or ('quantity' in item and (type(amount) is not int or not 1 <= amount <= 100)):
                fail('INVALID_ARGUMENTS', 'ID не должны повторяться; quantity — целое число от 1 до 100.')
            wanted[key] = amount
        fingerprint = self.store.fingerprint(dict(method='remove_products', items=wanted))
        previous = self.previous(request_id, fingerprint)
        if previous is not None:
            return previous
        context = self.context()
        cart = self.cart(context)
        before = counts(cart)
        self.writable(cart)
        products, changed = [], []
        for original in cart.get('products', []):
            row = {k: v for k, v in original.items() if k != 'product'}
            key = row['productId']
            if key not in wanted:
                products.append(row)
                continue
            amount = wanted[key]
            quantity = 0 if amount is None else max(0, before[key] - amount)
            changed.append(key)
            if quantity == 0:
                continue
            row['quantity'] = quantity
            for unit, total in (('price', 'totalPrice'), ('oldPrice', 'totalOldPrice'),
                                ('discountAmount', 'totalDiscountAmount')):
                if type(row.get(unit)) is int:
                    row[total] = row[unit] * quantity
            products.append(row)
        return self.commit_cart('remove_products', request_id, fingerprint, context, cart, products, changed)

    def clear_cart(self, args):
        request_id = self.request_id(args)
        fingerprint = self.store.fingerprint(dict(method='clear_cart'))
        previous = self.previous(request_id, fingerprint)
        if previous is not None:
            return previous
        context = self.context()
        cart = self.cart(context)
        before = counts(cart)
        self.writable(cart)
        return self.commit_cart('clear_cart', request_id, fingerprint, context, cart, [], list(before))
