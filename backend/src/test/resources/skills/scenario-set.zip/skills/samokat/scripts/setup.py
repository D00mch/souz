"""Operator dependency setup, isolated from the container's global Python."""
import json
import sys
from pathlib import Path
import subprocess
import venv
sys.dont_write_bytecode = True
from sk_store import directory

try:
    target = directory() / 'venv'
    venv.EnvBuilder(with_pip=True).create(target)
    result = subprocess.run([str(target / 'bin/python'), '-m', 'pip', 'install',
                             '--disable-pip-version-check', '--no-input', 'curl_cffi==0.17.0'],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=180)
    print(json.dumps(dict(ok=result.returncode == 0, dependency='curl_cffi==0.17.0')))
except Exception:
    print(json.dumps(dict(ok=False, error='DEPENDENCY_SETUP_FAILED')))
