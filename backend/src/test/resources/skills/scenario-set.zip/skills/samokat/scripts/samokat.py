"""JSON stdin/stdout interface for the owner's Samokat cart."""
import json
import os
from pathlib import Path
import sys
sys.dont_write_bytecode = True
from sk_store import Store, Failure, directory


def run(method, args, store):
    if not isinstance(args, dict):
        raise Failure('INVALID_ARGUMENTS', 'stdin должен содержать JSON-объект.')
    methods = {
        'get_auth_status': 'status', 'search_products': 'search_products',
        'get_cart': 'get_cart', 'add_products': 'add_products',
        'remove_products': 'remove_products', 'clear_cart': 'clear_cart',
        'get_operation': 'get_operation', 'start_phone_auth': 'start',
        'submit_sms_code': 'submit', 'resend_sms_code': 'resend',
        'initialize_connection': 'initialize', 'get_order_history': 'get_order_history',
        'get_order_details': 'get_order_details', 'get_frequent_products': 'get_frequent_products',
    }
    if method not in methods:
        raise Failure('UNKNOWN_METHOD', 'Неизвестный метод Самоката.')
    allowed = {
        'get_auth_status': set(), 'get_cart': set(), 'initialize_connection': set(),
        'search_products': {'query', 'limit'}, 'add_products': {'request_id', 'items'},
        'remove_products': {'request_id', 'items'}, 'clear_cart': {'request_id'},
        'get_operation': {'request_id'}, 'start_phone_auth': {'phone', 'request_id'},
        'submit_sms_code': {'auth_session_id', 'code', 'request_id'},
        'resend_sms_code': {'auth_session_id', 'request_id'},
        'get_order_history': {'limit', 'offset'}, 'get_order_details': {'order_id'},
        'get_frequent_products': {'max_orders', 'limit', 'min_order_count'},
    }[method]
    if set(args) - allowed:
        raise Failure('INVALID_ARGUMENTS', 'Переданы неизвестные аргументы.')
    if method in ('start_phone_auth','submit_sms_code','resend_sms_code','initialize_connection'):
        import sk_auth
        return getattr(sk_auth, methods[method])(store,args)
    if method == 'get_auth_status':
        pending=store.get('phone_auth')
        if pending:
            import time
            if pending['expires']>time.time():
                from sk_auth import public_pending
                return public_pending(pending)
            store.put('phone_auth',None)
            store.put('phone_session',None)
    if method == 'get_auth_status' and not store.get('session'):
        return dict(ok=True, state='unauthenticated', transport_ready=False, fresh_phone_login_supported=True)
    if method == 'get_auth_status':
        credentials = (store.get('session') or {}).get('credentials') or {}
        if not credentials.get('access_token') or not credentials.get('refresh_token'):
            return dict(ok=True, state='unauthenticated', fresh_phone_login_supported=True)
    from sk_client import Client
    from sk_shop import Shop
    client = Client(store)
    try:
        if method in ('get_order_history','get_order_details','get_frequent_products'):
            from sk_orders import Orders
            return getattr(Orders(store,client),methods[method])(args)
        return getattr(Shop(store, client), methods[method])(args)
    finally:
        client.close()


def main():
    try:
        state = directory()
        try:
            import curl_cffi  # noqa: F401
        except ImportError:
            interpreter = state / 'venv/bin/python'
            if (len(sys.argv) == 2 and sys.argv[1] in ('start_phone_auth', 'initialize_connection')
                    and not interpreter.exists()):
                import subprocess
                with Store(state).locked():
                    if not interpreter.exists():
                        completed = subprocess.run([sys.executable, '-B', str(Path(__file__).with_name('setup.py'))],
                                                   stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=180)
                        if completed.returncode != 0 or not json.loads(completed.stdout).get('ok'):
                            raise Failure('DEPENDENCY_REQUIRED', 'Не удалось подготовить HTTP-клиент Самоката.')
            if interpreter.exists() and Path(sys.executable).absolute() != interpreter.absolute():
                os.execv(str(interpreter), [str(interpreter), '-B', str(Path(__file__).resolve()), *sys.argv[1:]])
        raw = sys.stdin.read(65537)
        if len(raw) > 65536:
            raise Failure('INVALID_ARGUMENTS', 'Слишком большой ввод.')
        args = json.loads(raw or '{}')
        with Store(state).locked() as store:
            result = run(sys.argv[1] if len(sys.argv) == 2 else '', args, store)
    except Failure as error:
        result = error.result
    except (ValueError, TypeError, KeyError):
        result = dict(ok=False, error='INVALID_INPUT_OR_RESPONSE', message='Некорректный JSON-ввод или ответ Самоката.')
    except Exception:
        result = dict(ok=False, error='INTERNAL_ERROR', message='Операция не завершена. Проверь её прежний request_id.')
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))


if __name__ == '__main__':
    main()
