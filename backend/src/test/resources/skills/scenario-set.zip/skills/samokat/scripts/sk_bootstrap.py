"""Cold Servicepipe initialization with Lightpanda JS and the existing HTTP client."""
import base64
import json
import shutil
import socket
import subprocess
import tempfile
import time
from urllib.parse import urlsplit
import uuid
import warnings
from sk_store import Failure


def headers_for_device(device_id=None):
    return {'deviceid': device_id or str(uuid.uuid4()), 'systemversion': '13',
            'x-user-type': 'anonymous', 'x-application-platform': 'android',
            'x-application-version': '4.22.0', 'x-application-store': 'Undetermined',
            'user-agent': 'smartspacestoreapp/4.22.0 (build: 99757; device: SM-G998B; OS: Android 13)'}


def allowed_url(value):
    parsed = urlsplit(value)
    host = parsed.hostname or ''
    return parsed.scheme == 'https' and any(host == x or host.endswith('.' + x)
                                           for x in ('samokat.ru', 'servicepipe.tech'))


def service_cookies(value):
    result = {}
    for part in value.split(';'):
        name, sep, content = part.strip().partition('=')
        if sep and name.startswith('sp') and name.isalnum() and len(name) <= 16 and content:
            result[name] = content
    return result


class Challenge:
    """One ephemeral browser, no shared CDP session and no persistent browser profile."""
    def __init__(self, proxy):
        self.proxy = proxy
        self.sequence = 0
        self.ws = None
        self.http = None
        self.process = None
        self.log = None
        self.requests = 0
        self.deadline = time.monotonic() + 65
        self.stage = 'browser_start'

    def close(self):
        if self.ws is not None:
            try:
                self.ws.close()
            except Exception:
                pass
        if self.http is not None:
            self.http.close()
        if self.process is not None:
            self.process.terminate()
            try:
                self.process.wait(3)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
        if self.log is not None:
            self.log.close()

    def send(self, method, params=None, session=None):
        self.sequence += 1
        message = dict(id=self.sequence, method=method, params=params or {})
        if session:
            message['sessionId'] = session
        self.ws.send_json(message)
        return self.sequence

    def event(self, message):
        if message.get('method') != 'Fetch.requestPaused':
            return
        params = message['params']
        request = params['request']
        session = message.get('sessionId')
        if (not allowed_url(request['url']) or request['method'] not in ('GET', 'HEAD', 'POST', 'OPTIONS')
                or self.requests >= 24 or time.monotonic() > self.deadline):
            self.send('Fetch.failRequest', dict(requestId=params['requestId'], errorReason='BlockedByClient'), session)
            return
        self.requests += 1
        incoming = {k.lower(): v for k, v in request.get('headers', {}).items()}
        forwarded = {k: v for k, v in incoming.items()
                     if k in ('content-type', 'accept', 'origin', 'referer', 'cookie')}
        try:
            response = self.http.request(request['method'], request['url'], headers=forwarded,
                                         data=request.get('postData'), proxy=self.proxy,
                                         timeout=12, allow_redirects=False, discard_cookies=True)
            if len(response.content) > 4 * 1024 * 1024:
                raise ValueError('response_too_large')
            headers = [dict(name=k, value=v) for k, v in response.headers.multi_items()
                       if k.lower() not in ('content-encoding', 'content-length', 'transfer-encoding')]
            self.send('Fetch.fulfillRequest', dict(requestId=params['requestId'],
                                                  responseCode=response.status_code,
                                                  responseHeaders=headers,
                                                  body=base64.b64encode(response.content).decode()), session)
        except Exception:
            self.send('Fetch.failRequest', dict(requestId=params['requestId'], errorReason='Failed'), session)

    def call(self, method, params=None, session=None, timeout=25):
        wanted = self.send(method, params, session)
        end = min(self.deadline, time.monotonic() + timeout)
        while time.monotonic() < end:
            response = self.ws.recv_json(timeout=max(.1, end - time.monotonic()))
            if response.get('id') == wanted:
                if 'error' in response:
                    raise Failure('BOOTSTRAP_UNAVAILABLE', 'Lightpanda не поддерживает нужную операцию CDP.',
                                  stage=self.stage)
                return response.get('result', {})
            self.event(response)
        raise TimeoutError('bootstrap_deadline')

    def run(self):
        from curl_cffi import requests
        from curl_cffi.requests import WebSocket
        binary = shutil.which('lightpanda')
        if binary is None:
            raise Failure('BOOTSTRAP_UNAVAILABLE', 'Для первичного входа нужен Lightpanda в песочнице.')
        sock = socket.socket()
        sock.bind(('127.0.0.1', 0))
        port = sock.getsockname()[1]
        sock.close()
        self.log = tempfile.TemporaryFile()
        self.process = subprocess.Popen([binary, 'serve', '--host', '127.0.0.1', '--port', str(port),
                                         '--load-resources', 'worker', '--load-resources', 'iframe',
                                         '--load-resources', 'stylesheet'], stdout=self.log, stderr=self.log)
        ready = False
        for _ in range(80):
            with socket.socket() as probe:
                probe.settimeout(.1)
                if probe.connect_ex(('127.0.0.1', port)) == 0:
                    ready = True
                    break
            if self.process.poll() is not None:
                break
            time.sleep(.05)
        if not ready:
            raise Failure('BOOTSTRAP_UNAVAILABLE', 'Не удалось запустить временный процесс Lightpanda.')
        self.ws = WebSocket()
        self.ws.connect('ws://127.0.0.1:' + str(port) + '/', timeout=5, proxy='')
        self.http = requests.Session(trust_env=False, impersonate='chrome131_android')
        target = self.call('Target.createTarget', {'url': 'about:blank'})['targetId']
        session = self.call('Target.attachToTarget', dict(targetId=target, flatten=True))['sessionId']
        for method in ('Page.enable', 'Runtime.enable', 'Network.enable'):
            self.call(method, session=session)
        self.call('Fetch.enable', {'patterns': [{'urlPattern': '*', 'requestStage': 'Request'}]}, session)
        self.stage = 'servicepipe_page'
        self.call('Page.navigate', {'url': 'https://samokat.ru/'}, session)
        self.stage = 'servicepipe_javascript'
        expression = ("JSON.stringify({cookie:document.cookie,"
                      "captcha:typeof get_options==='function'&&get_options().is_captcha===true,"
                      "frames:document.querySelectorAll('#id_captcha_frame_div iframe').length})")
        while time.monotonic() < self.deadline:
            result = self.call('Runtime.evaluate', dict(expression=expression, returnByValue=True), session)
            raw = result.get('result', {}).get('value')
            if raw:
                page = json.loads(raw)
                if page.get('captcha') or page.get('frames'):
                    raise Failure('INTERACTIVE_VERIFICATION_REQUIRED',
                                  'Самокат запросил интерактивную проверку; автоматический SMS-вход пока недоступен.')
                cookies = service_cookies(page.get('cookie', ''))
                if cookies.get('spid') and cookies.get('spsc'):
                    return cookies
            try:
                self.event(self.ws.recv_json(timeout=.3))
            except Exception:
                pass
        raise Failure('BOOTSTRAP_FAILED', 'Не получены свежие cookies Самоката.', stage=self.stage)


def create_transport(proxy=None, device_id=None):
    from curl_cffi import requests
    from sk_client import JA3, AKAMAI, normalize_session
    challenge = Challenge(proxy)
    try:
        cookies = challenge.run()
    except Failure:
        raise
    except Exception:
        raise Failure('BOOTSTRAP_FAILED', 'Первичное подключение Самоката не завершено.', stage=challenge.stage)
    finally:
        challenge.close()
    headers = headers_for_device(device_id)
    cookies.update(spav='android-ru.sbcs.store-4.22.0', spsv='1.1.1')
    try:
        with requests.Session(trust_env=False, ja3=JA3, akamai=AKAMAI, default_headers=False) as client:
            for name, value in cookies.items():
                client.cookies.set(name, value, domain='.samokat.ru', path='/')
            with warnings.catch_warnings():
                warnings.filterwarnings('ignore', message='Padding')
                response = client.post('https://api.samokat.ru/showcase/oauth/token/anonymous',
                                       headers=dict(headers, accept='application/json'), proxy=proxy,
                                       timeout=20, allow_redirects=False)
            if response.status_code != 200:
                raise Failure('BOOTSTRAP_REJECTED', 'Самокат отклонил новый контекст подключения.',
                              http_status=response.status_code)
            data = response.json()
            if not isinstance(data, dict) or not data.get('access_token'):
                raise Failure('BOOTSTRAP_FAILED', 'Не подтверждена новая анонимная сессия Самоката.')
            # Guest OAuth data is only a transport check. Account login starts with phone/SMS.
            return normalize_session(dict(headers=headers, credentials={}, https_proxy=proxy,
                                          cookies=[dict(name=c.name, value=c.value, domain=c.domain,
                                                        path=c.path, secure=c.secure, expires=c.expires)
                                                   for c in client.cookies.jar]))
    except Failure:
        raise
    except Exception:
        raise Failure('BOOTSTRAP_FAILED', 'Не удалось проверить новый контекст Самоката.')
