"""Owner-scoped order history and bounded frequencies from delivered orders."""
from datetime import datetime
import math
import time
import uuid
from sk_store import Failure


def bounded(args, key, default, low, high):
    value = args.get(key, default)
    if type(value) is not int or not low <= value <= high:
        raise Failure('INVALID_ARGUMENTS', f'{key} должен быть целым числом от {low} до {high}.')
    return value


def identifier(value):
    try:
        return str(uuid.UUID(value))
    except (ValueError, TypeError, AttributeError):
        return None


def timestamp(value):
    if not isinstance(value, str):
        return None
    try:
        parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
        return parsed.timestamp() if parsed.tzinfo is not None else None
    except (ValueError, OverflowError):
        return None


def money(value):
    return value / 100 if type(value) is int else None


def valid_quantity(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


class Orders:
    def __init__(self, store, client):
        self.store, self.client = store, client

    def get_order_history(self, args):
        limit = bounded(args, 'limit', 20, 1, 50)
        offset = bounded(args, 'offset', 0, 0, 100000)
        raw = self.client.call('GET', '/orders', query=dict(limit=limit, offset=offset))
        rows = raw.get('orders') if isinstance(raw, dict) else None
        if not isinstance(rows, list):
            raise Failure('INVALID_RESPONSE', 'Не получена история заказов Самоката.')
        account = self.client.state['account']
        cache = {key: value for key, value in self.store.get('history_orders', {}).items()
                 if value.get('account') == account}
        orders = []
        for row in rows:
            if not isinstance(row, dict) or not identifier(row.get('orderId')):
                raise Failure('INVALID_RESPONSE', 'Неизвестный формат записи истории заказов.')
            key = identifier(row['orderId'])
            date = row.get('date') if isinstance(row.get('date'), str) else None
            status = row.get('status') if isinstance(row.get('status'), str) else None
            orders.append(dict(order_id=key, status=status, completed=status == 'DELIVERED',
                               date=date, total_rub=money(row.get('amount')),
                               delivery_option=row.get('deliveryOption')))
            cache[key] = dict(account=account, date=date, status=status, at=time.time())
        if len(cache) > 1000:
            cache = dict(sorted(cache.items(), key=lambda item: item[1]['at'], reverse=True)[:1000])
        self.store.put('history_orders', cache)
        has_more = len(rows) == limit
        return dict(ok=True, orders=orders, offset=offset, has_more=has_more,
                    next_offset=offset + len(rows) if has_more else None)

    def get_order_details(self, args):
        key = identifier(args.get('order_id'))
        if key is None:
            raise Failure('INVALID_ARGUMENTS', 'Нужен order_id из истории заказов.')
        known = self.store.get('history_orders', {}).get(key)
        if not known or known.get('account') != self.client.state['account']:
            raise Failure('HISTORY_REQUIRED', 'Сначала получи страницу истории с этим заказом.')
        raw = self.client.call('GET', '/orders/' + key)
        if not isinstance(raw, dict) or identifier(raw.get('orderId')) != key:
            raise Failure('INVALID_RESPONSE', 'Не подтверждён запрошенный заказ.')
        lines = raw.get('orderLines')
        if not isinstance(lines, list):
            raise Failure('INVALID_RESPONSE', 'Не получены позиции прошлого заказа.')
        products = []
        for line in lines:
            if not isinstance(line, dict) or not valid_quantity(line.get('quantity')):
                raise Failure('INVALID_RESPONSE', 'Неизвестное количество в позиции прошлого заказа.')
            products.append(dict(product_id=identifier(line.get('productId')),
                                 name=line.get('title') if isinstance(line.get('title'), str) else None,
                                 quantity=line['quantity'], type=line.get('type')))
        label = raw.get('statusLabel')
        if not isinstance(label, dict):
            label = {}
        date = known.get('date') or (label.get('date') if isinstance(label.get('date'), str) else None)
        delivered = label.get('deliveredDate') if isinstance(label.get('deliveredDate'), str) else None
        status = raw.get('status')
        return dict(ok=True, order=dict(order_id=key, status=status,
                                       completed=status == 'DELIVERED', date=date,
                                       delivered_at=delivered, total_rub=money(raw.get('totalPrice')),
                                       has_refunds=bool(raw.get('refunds')), products=products))

    def get_frequent_products(self, args):
        maximum = bounded(args, 'max_orders', 20, 1, 30)
        limit = bounded(args, 'limit', 20, 1, 50)
        minimum = bounded(args, 'min_order_count', min(2, maximum), 1, maximum)
        scan_limit = min(250, maximum * 5)
        detail_limit = min(50, maximum * 2)
        deadline = time.monotonic() + 90
        scanned = sampled = details = excluded_refunds = excluded_lines = 0
        offset = 0
        products, seen, dates = {}, set(), []
        reason, read_error = 'scan_limit', None
        stopped = False
        while scanned < scan_limit and sampled < maximum:
            if time.monotonic() >= deadline:
                reason = 'time_limit'
                break
            try:
                page = self.get_order_history(dict(limit=min(50, scan_limit-scanned), offset=offset))
                for summary in page['orders']:
                    if time.monotonic() >= deadline:
                        reason, stopped = 'time_limit', True
                        break
                    scanned += 1
                    key = summary['order_id']
                    if key in seen:
                        continue
                    seen.add(key)
                    if not summary['completed']:
                        continue
                    if details >= detail_limit:
                        reason, stopped = 'detail_limit', True
                        break
                    details += 1
                    order = self.get_order_details(dict(order_id=key))['order']
                    if not order['completed']:
                        continue
                    if order['has_refunds']:
                        excluded_refunds += 1
                        continue
                    sampled += 1
                    date = order['date']
                    when = timestamp(date)
                    if when is not None:
                        dates.append((when, date))
                    # Top-level orderLines already carry total fulfilled quantity; nested items split units/prices.
                    per_order = {}
                    for line in order['products']:
                        product = line['product_id']
                        if line['type'] != 'PRODUCT' or not product:
                            excluded_lines += 1
                            continue
                        if line['quantity'] == 0:
                            continue
                        if product not in per_order:
                            per_order[product] = dict(quantity=0, name=line['name'])
                        per_order[product]['quantity'] += line['quantity']
                    for product, item in per_order.items():
                        record = products.setdefault(product, dict(product_id=product, name=item['name'],
                                                                   order_count=0, total_quantity=0,
                                                                   last_ordered_at=None, last_quantity=None,
                                                                   _last_timestamp=None))
                        record['order_count'] += 1
                        record['total_quantity'] += item['quantity']
                        if when is not None and (record['_last_timestamp'] is None or when > record['_last_timestamp']):
                            record.update(_last_timestamp=when, last_ordered_at=date,
                                          last_quantity=item['quantity'], name=item['name'])
                    if sampled >= maximum:
                        reason, stopped = 'max_orders', True
                        break
            except Failure as error:
                if not sampled or error.result['error'] in ('AUTH_REQUIRED', 'RECONNECT_REQUIRED'):
                    raise
                reason, read_error = 'read_error', error.result['error']
                break
            if stopped:
                break
            if not page['has_more']:
                reason = 'history_exhausted'
                break
            offset = page['next_offset']
        ranked = [x for x in products.values() if x['order_count'] >= minimum]
        ranked.sort(key=lambda x: (-x['order_count'], -(x['_last_timestamp'] or 0), x['product_id']))
        for record in ranked:
            record.pop('_last_timestamp')
            record['share_of_sample'] = record['order_count'] / sampled
            record['average_quantity_when_ordered'] = record['total_quantity'] / record['order_count']
        return dict(ok=True, products=ranked[:limit], has_more_products=len(ranked) > limit,
                    sampled_delivered_orders=sampled, scanned_history_records=scanned,
                    excluded_refunded_orders=excluded_refunds, excluded_unsupported_lines=excluded_lines,
                    unknown_date_orders=sampled-len(dates), coverage_limit=reason,
                    partial=reason in ('read_error', 'time_limit', 'detail_limit', 'scan_limit'),
                    read_error=read_error, period_start=min(dates)[1] if dates else None,
                    period_end=max(dates)[1] if dates else None,
                    current_availability_checked=False)
