"""Operator-only import of an owner-authorized mobile session through stdin."""
import json
import sys
sys.dont_write_bytecode = True
from sk_store import Store, directory, Failure
from sk_client import normalize_session

try:
    value = normalize_session(json.loads(sys.stdin.read(131073)))
    with Store(directory()).locked() as store:
        if store.get('session'):
            raise Failure('ALREADY_CONNECTED', 'Подключение уже существует; не заменяй сессию автоматически.')
        store.put('session', value)
    print(json.dumps(dict(ok=True, state='imported', verification_required=True)))
except Failure as error:
    print(json.dumps(error.result, ensure_ascii=False))
except Exception:
    print(json.dumps(dict(ok=False, error='CONNECTION_IMPORT_FAILED')))
