"""Samokat Android request context; no emulator dependency after connection."""
import base64
import json
import time
import warnings
from sk_store import Failure

BASE = 'https://api.samokat.ru/showcase'
JA3 = ('771,4865-4866-4867-49195-49196-52393-49199-49200-52392-49171-49172-156-157-47-53,'
       '0-23-65281-10-11-35-16-5-13-51-45-43-21,29-23-24,0')
AKAMAI = '4:16777216|16711681|0|m,p,a,s'
ALLOWED_HEADERS = {'deviceid', 'systemversion', 'x-application-platform',
                   'x-application-version', 'x-application-store', 'x-creeper',
                   'x-user-id', 'x-user-type', 'x-trace-flags', 'user-agent'}


def claims(token):
    try:
        data = token.split('.')[1]
        return json.loads(base64.urlsafe_b64decode(data + '=' * (-len(data) % 4)))
    except (ValueError, IndexError, TypeError):
        raise Failure('RECONNECT_REQUIRED', 'Нужно заново подключить сессию приложения Самоката.')


def normalize_session(value):
    if not isinstance(value, dict) or not isinstance(value.get('headers'), dict):
        raise Failure('INVALID_SESSION', 'Неверный формат подключения.')
    credentials = value.get('credentials') or {}
    if not isinstance(credentials, dict):
        raise Failure('INVALID_SESSION', 'Неверный формат сессии аккаунта.')
    identity = None
    if credentials:
        if not credentials.get('access_token') or not credentials.get('refresh_token'):
            raise Failure('INVALID_SESSION', 'Сессия аккаунта неполна.')
        identity = claims(credentials['access_token']).get('sub')
        if not identity:
            raise Failure('INVALID_SESSION', 'Не определён аккаунт подключения.')
    headers = {k.lower(): v for k, v in value['headers'].items()}
    if not all(isinstance(headers.get(k), str) and headers[k]
               for k in ('deviceid', 'user-agent', 'x-application-version')):
        raise Failure('INVALID_SESSION', 'Не сохранён контекст приложения.')
    cookies = value.get('cookies')
    if cookies is None:
        cookies = []
        attributes = {'path', 'domain', 'expires', 'samesite', 'max-age', 'secure', 'httponly'}
        for part in headers.get('cookie', '').split(';'):
            name, sep, val = part.strip().partition('=')
            if sep and name and name.lower() not in attributes:
                cookies.append(dict(name=name, value=val, domain='api.samokat.ru', path='/'))
    if not cookies:
        raise Failure('INVALID_SESSION', 'Отсутствуют cookies подключения приложения.')
    for cookie in cookies:
        if cookie.get('domain', '').lstrip('.') not in ('api.samokat.ru', 'samokat.ru'):
            raise Failure('INVALID_SESSION', 'Неверный домен cookies подключения.')
    proxy = value.get('https_proxy')
    if proxy is not None:
        from urllib.parse import urlsplit
        parsed = urlsplit(proxy)
        if parsed.scheme not in ('http', 'https', 'socks5', 'socks5h') or not parsed.hostname:
            raise Failure('INVALID_SESSION', 'Неверный формат прокси.')
    return dict(headers={k: v for k, v in headers.items() if k in ALLOWED_HEADERS},
                cookies=cookies, credentials=credentials, account=identity,
                https_proxy=proxy, refresh_unknown=bool(value.get('refresh_unknown', False)))


class Client:
    def __init__(self, store, state_key="session"):
        self.store = store
        self.state_key = state_key
        self.state = store.get(state_key)
        if not self.state:
            raise Failure('AUTH_REQUIRED', 'Войди в Самокат по телефону и SMS.')
        try:
            from curl_cffi import requests
        except ImportError:
            raise Failure('DEPENDENCY_REQUIRED', 'Оператору нужно выполнить scripts/setup.py для этого пакета.')
        self.http = requests.Session(trust_env=False, ja3=JA3, akamai=AKAMAI,
                                     default_headers=False)
        for cookie in self.state['cookies']:
            if cookie.get('expires') is not None and cookie['expires'] <= time.time():
                continue
            self.http.cookies.set(cookie['name'], cookie['value'],
                                  domain=cookie['domain'], path=cookie.get('path', '/'))

    def close(self):
        self.http.close()

    def persist(self):
        self.state['cookies'] = [dict(name=v.name, value=v.value, domain=v.domain,
                                      path=v.path, secure=v.secure, expires=v.expires)
                                 for v in self.http.cookies.jar
                                 if v.domain.lstrip('.') in ('api.samokat.ru', 'samokat.ru')]
        self.store.put(self.state_key, self.state)

    def raw(self, method, path, body=None, query=None, authenticated=True):
        headers = dict(self.state['headers'], accept='application/json')
        headers['accept-encoding'] = 'gzip'
        if path == '/confirmation/code':
            headers.pop('deviceid', None)
        if authenticated:
            headers['authorization'] = 'Bearer ' + self.state['credentials']['access_token']
        data = None
        if body is not None:
            headers['content-type'] = ('application/json' if path in ('/confirmation/code', '/oauth/token/otp')
                                       else 'application/json; charset=utf-8')
            data = json.dumps(body, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()
        try:
            with warnings.catch_warnings():
                warnings.filterwarnings('ignore', message='Padding\\(21\\) extension found')
                response = self.http.request(method, BASE + path, headers=headers,
                                             data=data, params=query, timeout=25,
                                             proxy=self.state.get('https_proxy'),
                                             accept_encoding='gzip', allow_redirects=False)
        except Exception:
            raise Failure('TRANSPORT_ERROR', 'Запрос Самоката не завершён; исход изменения нужно проверить.')
        finally:
            self.persist()
        if response.status_code == 401:
            raise Failure('AUTH_REQUIRED', 'Сессия Самоката отклонена. Нужно переподключение.', http_status=401)
        if response.status_code != 200:
            try:
                code = response.json().get('code')
            except (ValueError, AttributeError):
                code = None
            if code in ('WRONG_CODE', 'CODE_RETRY_TIMEOUT', 'USER_BANNED', 'CAPTCHA_REQUIRED'):
                raise Failure(code, 'Самокат отклонил подтверждение входа.', http_status=response.status_code)
            raise Failure('HTTP_REJECTED', 'Самокат отклонил запрос.', http_status=response.status_code)
        try:
            result = response.json()
        except (ValueError, TypeError):
            raise Failure('INVALID_RESPONSE', 'Самокат вернул ответ неизвестного формата.')
        if not isinstance(result, (dict, list)):
            raise Failure('INVALID_RESPONSE', 'Самокат вернул ответ неизвестного формата.')
        return result

    def ensure_auth(self, force=False):
        credentials = self.state.get('credentials') or {}
        if not credentials.get('access_token') or not credentials.get('refresh_token'):
            raise Failure('AUTH_REQUIRED', 'Войди в Самокат по телефону и SMS.')
        if self.state.get('refresh_unknown'):
            raise Failure('RECONNECT_REQUIRED', 'Исход обновления сессии неизвестен; нужно переподключение.')
        expires = claims(self.state['credentials']['access_token']).get('exp', 0)
        if not force and expires > time.time() + 45:
            return
        old_account = self.state['account']
        # Commit before POST so a killed process cannot replay a possibly rotated refresh.
        self.state['refresh_unknown'] = True
        self.persist()
        try:
            value = self.raw('POST', '/oauth/token/refresh',
                             {'refresh_token': self.state['credentials']['refresh_token']},
                             authenticated=False)
        except Failure as error:
            if error.result['error'] in ('HTTP_REJECTED', 'AUTH_REQUIRED'):
                self.state['refresh_unknown'] = False
                self.persist()
            raise
        if not isinstance(value, dict) or claims(value.get('access_token', '')).get('sub') != old_account:
            raise Failure('RECONNECT_REQUIRED', 'Не удалось подтвердить аккаунт после обновления сессии.')
        self.state['credentials'].update(value)
        self.state['refresh_unknown'] = False
        self.persist()

    def call(self, method, path, body=None, query=None):
        self.ensure_auth()
        try:
            return self.raw(method, path, body, query)
        except Failure as error:
            # A definite 401 cannot have applied a cart write. Only reads may retry after refresh.
            if error.result.get('http_status') == 401 and method != 'PUT':
                self.ensure_auth(force=True)
                return self.raw(method, path, body, query)
            raise
