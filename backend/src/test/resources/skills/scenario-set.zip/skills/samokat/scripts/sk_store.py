"""Private per-user session and durable cart operation journal."""
import contextlib
import fcntl
import hashlib
import hmac
import json
import os
from pathlib import Path
import secrets
import sqlite3
import time


class Failure(Exception):
    def __init__(self, code, message, **details):
        self.result = dict(ok=False, error=code, message=message, **details)


def directory():
    root = Path(__file__).resolve().parent.parent
    if root.parent.name == 'bundles':
        root = root.parent.parent
    if root.name != 'samokat':
        raise Failure('STORAGE_UNAVAILABLE', 'Пакет должен иметь ID samokat.')
    return root.parent / '.samokat-state'


class Store:
    def __init__(self, path):
        self.path = Path(path)
        self.db = None

    @contextlib.contextmanager
    def locked(self):
        os.umask(0o077)
        self.path.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.path.chmod(0o700)
        with (self.path / 'lock').open('a') as lock:
            deadline = time.monotonic() + 5
            while True:
                try:
                    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    if time.monotonic() >= deadline:
                        raise Failure('BUSY', 'Другой чат работает с Самокатом.')
                    time.sleep(.05)
            try:
                self.db = sqlite3.connect(self.path / 'state.sqlite3', timeout=5)
                self.db.executescript('PRAGMA secure_delete=ON; PRAGMA synchronous=FULL; '
                                     'CREATE TABLE IF NOT EXISTS state (key TEXT PRIMARY KEY, value TEXT NOT NULL); '
                                     'CREATE TABLE IF NOT EXISTS operations (id TEXT PRIMARY KEY, value TEXT NOT NULL);')
                if self.get('hmac_key') is None:
                    self.put('hmac_key', secrets.token_hex(32))
                yield self
            finally:
                if self.db is not None:
                    self.db.close()
                    self.db = None
                fcntl.flock(lock, fcntl.LOCK_UN)

    def get(self, key, default=None):
        row = self.db.execute('SELECT value FROM state WHERE key=?', (key,)).fetchone()
        return json.loads(row[0]) if row else default

    def put(self, key, value):
        with self.db:
            self.db.execute('INSERT OR REPLACE INTO state VALUES (?,?)',
                            (key, json.dumps(value, ensure_ascii=False, allow_nan=False)))

    def fingerprint(self, value):
        raw = json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()
        return hmac.new(bytes.fromhex(self.get('hmac_key')), raw, hashlib.sha256).hexdigest()

    def operation(self, request_id):
        row = self.db.execute('SELECT value FROM operations WHERE id=?', (request_id,)).fetchone()
        return json.loads(row[0]) if row else None

    def save_operation(self, request_id, value):
        with self.db:
            self.db.execute('INSERT OR REPLACE INTO operations VALUES (?,?)',
                            (request_id, json.dumps(value, ensure_ascii=False, allow_nan=False)))
