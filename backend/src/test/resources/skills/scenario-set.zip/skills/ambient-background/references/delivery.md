# Channel delivery

Select one final HTML with `AttachFileToReply(path=absolute_html_path,
presentation="document")`; a prose path is not an attachment. Revisions use fresh
filenames and detach a previously selected revision. Parents explicitly select a
child's file.

For another requested channel, discover its owned destination with
`ListActiveChannels` as needed and send its attachment `fileId` through
`SendMessageToChannel`. Answer an invoking TV channel directly. Orion selects the
first HTML document, publishes and opens it: send one HTML per TV message and do
not add a second media-open command. Receipt/ACTION_VIEW acknowledgement does not
prove physical rendering. Do not automatically retry uncertain sends.

The target TV opens the standalone file directly in its Firefox fork. No iframe
or separate Souz viewer is required. Keep scripts, styles, fonts and images
embedded; fill the viewport and run continuously without playback controls.
Fullscreen behavior depends on the TV browser/app. A desktop preview does not
verify the TV’s rendering performance.
Deliver the file rather than a hosted URL or a local server.
