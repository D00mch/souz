"""Assemble a dependency-free ambient animation; no rendering or network access."""
import time

STARTED = time.perf_counter()

import argparse
import importlib.util
import html
import json
import math
import re
import sys
from contextlib import contextmanager, nullcontext
from functools import partial
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CATALOG = json.loads((ROOT / "assets/catalog.json").read_text(encoding="utf-8"))
PRESETS = tuple(CATALOG["presets"])
DEFAULT_PRESET = CATALOG.get("defaultPreset", "flow")
CHOICES = {
    "preset": PRESETS,
    "landscape": ("mountains", "icebergs", "jungle", "city", "forest", "dunes", "space", "abstract"),
    "foreground": ("reeds", "ice", "tropical", "pines", "cacti", "none"),
    "atmosphere": ("fireflies", "snow", "mist", "stars", "rain", "dust", "meteors", "none"),
    "celestial": ("sun", "moon", "planet", "ringed-planet", "none"),
    "quality": ("eco", "balanced"),
}
PALETTE_ARRAYS = {"sky": 4, "water": 2, "mountain": 3}
PALETTE_COLORS = ("disc", "light", "ground", "foliage", "accent", "window")
KEYS = set(CHOICES) | {"title", "seed", "motion", "brightness", "horizon", "water", "aurora", "palette", "variant", "background", "backgroundGradient", "layers", "ticker", "largeShapeRequired", "effects"}


def number(value, key, lo, hi):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not lo <= value <= hi:
        raise ValueError(f"{key} must be a finite number between {lo} and {hi}")


def validate(config):
    if not isinstance(config, dict):
        raise ValueError("Scene configuration must be a JSON object")
    unknown = set(config) - KEYS
    if unknown:
        raise ValueError("Unknown scene keys: " + ", ".join(sorted(unknown)))
    for key, choices in CHOICES.items():
        if key in config and config[key] not in choices:
            raise ValueError(f"{key} must be one of: {', '.join(choices)}")
    if "variant" in config and not (config["variant"] == "custom" and "layers" in config) and config["variant"] not in [v["id"] for v in CATALOG["variants"][config.get("preset", DEFAULT_PRESET)]]:
        raise ValueError("Unknown variant for the selected preset")
    for key, lo, hi in (("motion", 0, 1), ("brightness", .25, 1), ("horizon", .4, .7)):
        if key in config:
            number(config[key], key, lo, hi)
    if "seed" in config:
        number(config["seed"], "seed", 1, 2147483646)
        if not isinstance(config["seed"], int):
            raise ValueError("seed must be an integer")
    for key in ("water", "aurora", "largeShapeRequired"):
        if key in config and not isinstance(config[key], bool):
            raise ValueError(key + " must be boolean")
    if "title" in config and (not isinstance(config["title"], str) or not 1 <= len(config["title"].strip()) <= 160):
        raise ValueError("title must contain 1–160 characters")
    if "background" in config and (not isinstance(config["background"], str) or re.fullmatch(r"#[0-9a-fA-F]{6}", config["background"]) is None):
        raise ValueError("background must be #RRGGBB")
    if "backgroundGradient" in config:
        gradient = config["backgroundGradient"]
        if not isinstance(gradient, dict) or set(gradient) - {"colors", "angle"}:
            raise ValueError("backgroundGradient supports colors and angle")
        colors = gradient.get("colors")
        if not isinstance(colors, list) or not 2 <= len(colors) <= 6 or any(not isinstance(c, str) or re.fullmatch(r"#[0-9a-fA-F]{6}", c) is None for c in colors):
            raise ValueError("backgroundGradient needs 2-6 #RRGGBB colors")
        if "angle" in gradient:
            number(gradient["angle"], "backgroundGradient.angle", -180, 180)
        if "layers" not in config:
            raise ValueError("backgroundGradient requires abstract layers")
    if "layers" in config:
        if CATALOG["presets"][config.get("preset", DEFAULT_PRESET)].get("category") != "abstract":
            raise ValueError("Layer compositions require an abstract preset, or omit preset")
        validate_layers(config["layers"])
    if "ticker" in config:
        ticker = config["ticker"]
        if not isinstance(ticker, dict) or set(ticker) - {"text", "size", "y", "speed", "opacity", "color", "gap", "occlude", "fontWeight"}:
            raise ValueError("ticker supports text, size, y, speed, opacity, color, gap, occlude and fontWeight")
        if "fontWeight" in ticker and (isinstance(ticker["fontWeight"], bool) or ticker["fontWeight"] not in (400, 600)):
            raise ValueError("ticker.fontWeight must be 400 or 600 (SB Sans Display Semibold)")
        text = ticker.get("text")
        if not isinstance(text, str) or not 1 <= len(text.strip()) <= 4000 or any(ord(c) < 32 and c not in "\n\r\t" for c in text):
            raise ValueError("ticker.text must contain 1–4000 printable characters")
        for key, lo, hi in (("size", .05, .4), ("y", .05, .95), ("speed", -.15, .15), ("opacity", .05, .8), ("gap", .1, 2)):
            if key in ticker:
                number(ticker[key], "ticker." + key, lo, hi)
        if "color" in ticker and (not isinstance(ticker["color"], str) or re.fullmatch(r"#[0-9a-fA-F]{6}", ticker["color"]) is None):
            raise ValueError("ticker.color must be #RRGGBB")
        if "occlude" in ticker and not isinstance(ticker["occlude"], bool):
            raise ValueError("ticker.occlude must be boolean")
        if "layers" not in config:
            raise ValueError("ticker requires explicit abstract layers")
    if "effects" in config:
        validate_effects(config)
    if "palette" in config:
        palette = config["palette"]
        if not isinstance(palette, dict) or set(palette) - (set(PALETTE_ARRAYS) | set(PALETTE_COLORS)):
            raise ValueError("palette contains unsupported colors")
        for key, value in palette.items():
            colors = value if key in PALETTE_ARRAYS else [value]
            if key in PALETTE_ARRAYS and (not isinstance(value, list) or len(value) != PALETTE_ARRAYS[key]):
                raise ValueError(f"palette.{key} needs {PALETTE_ARRAYS[key]} colors")
            if any(not isinstance(c, str) or re.fullmatch(r"#[0-9a-fA-F]{6}", c) is None for c in colors):
                raise ValueError(f"palette.{key} colors must be #RRGGBB")
    return config


LAYER_STYLES = {"flow": ("soft",), "particles": ("dust", "bokeh", "constellation"), "ribbons": ("silk", "wave", "aurora"), "geometry": ("orbits", "rings", "lattice", "pulse-lattice"), "pulses": ("rings", "bloom", "rays"), "streams": ("trails", "comets", "rain"), "shapes": ("confetti", "petals", "shards"), "planes": ("wave", "split", "disc", "band", "segment"), "orbs": ("sun", "moon", "planet", "ringed-planet")}
LAYER_DEFAULTS = {"flow": 3, "particles": 24, "ribbons": 18, "geometry": 10, "pulses": 4, "streams": 28, "shapes": 24, "planes": 1, "orbs": 1}
LAYER_MAX = {"flow": 5, "particles": 48, "ribbons": 28, "geometry": 18, "pulses": 8, "streams": 48, "shapes": 48, "planes": 3, "orbs": 2}
LAYER_BUDGET = {"flow": 6, "particles": 64, "ribbons": 40, "geometry": 24, "pulses": 10, "streams": 64, "shapes": 64, "planes": 3, "orbs": 2}


def validate_layers(layers):
    if not isinstance(layers, list) or not 1 <= len(layers) <= 6:
        raise ValueError("Use 1-6 layers, at most four moving layers")
    if sum(not isinstance(item, dict) or item.get("type") != "orbs" for item in layers) > 4:
        raise ValueError("Use at most four moving layers; extra layers must be static orbs")
    totals = dict.fromkeys(LAYER_STYLES, 0)
    for item in layers:
        if not isinstance(item, dict) or set(item) - {"type", "style", "colors", "count", "opacity", "speed", "scale", "blend", "rotation", "offset", "weight", "period", "spread", "synchrony", "spin", "span", "drift", "amplitude", "wavelength", "waveSpeed", "fill", "gradientAngle", "edgePattern"}:
            raise ValueError("Invalid layer properties")
        kind = item.get("type")
        if not isinstance(kind, str) or kind not in LAYER_STYLES:
            raise ValueError("Layer type must be one of: " + ", ".join(LAYER_STYLES))
        if "style" in item and item["style"] not in LAYER_STYLES[kind]:
            raise ValueError("Unsupported style for " + kind)
        colors = item.get("colors", ["#ffffff"])
        if not isinstance(colors, list) or not 1 <= len(colors) <= 6 or any(not isinstance(c, str) or re.fullmatch(r"#[0-9a-fA-F]{6}", c) is None for c in colors):
            raise ValueError("Layer colors must contain 1–6 #RRGGBB colors")
        count = item.get("count", LAYER_DEFAULTS[kind])
        if isinstance(count, bool) or not isinstance(count, int) or not 1 <= count <= LAYER_MAX[kind]:
            raise ValueError("Invalid element count for " + kind)
        totals[kind] += count
        for key, lo, hi in (("opacity", 0, 1), ("speed", .05, 3), ("scale", .25, 3), ("rotation", -180, 180)):
            if key in item:
                number(item[key], "layer." + key, lo, hi)
        specialized = {"weight": ("ribbons", "geometry", "pulses", "streams"), "period": ("pulses",), "spread": ("pulses",), "synchrony": ("pulses",), "spin": ("shapes", "planes"), "span": ("planes",), "drift": ("planes",), "amplitude": ("planes",), "wavelength": ("planes",), "waveSpeed": ("planes",), "fill": ("planes",), "gradientAngle": ("planes",)}
        for key, allowed in specialized.items():
            if key in item and kind not in allowed:
                raise ValueError("layer." + key + " is unsupported for " + kind)
        for key, lo, hi in (("weight", .25, 4), ("period", 4, 30), ("spread", 0, 1), ("synchrony", 0, 1), ("spin", -3, 3), ("span", 30, 330), ("drift", 0, 2), ("amplitude", 0, .4), ("wavelength", .5, 4), ("waveSpeed", -.5, .5), ("gradientAngle", -180, 180)):
            if key in item:
                number(item[key], "layer." + key, lo, hi)
        if "span" in item and item.get("style", "wave") != "segment":
            raise ValueError("layer.span applies only to planes/segment")
        if "edgePattern" in item and (kind != "planes" or item.get("style") != "split" or item["edgePattern"] != "stitches"):
            raise ValueError("layer.edgePattern supports stitches on planes/split")
        if any(key in item for key in ("amplitude", "wavelength", "waveSpeed")) and item.get("style", "wave") != "wave":
            raise ValueError("Wave parameters apply only to planes/wave")
        if "fill" in item and item["fill"] not in ("solid", "gradient"):
            raise ValueError("Plane fill must be solid or gradient")
        if "gradientAngle" in item and item.get("fill") != "gradient":
            raise ValueError("gradientAngle requires fill=gradient")
        if item.get("fill") == "gradient" and len(colors) < 2:
            raise ValueError("Gradient planes need at least two colors")
        if item.get("blend", "screen") not in ("screen", "source-over"):
            raise ValueError("Unsupported layer blend")
        if "offset" in item:
            if not isinstance(item["offset"], list) or len(item["offset"]) != 2:
                raise ValueError("Layer offset must be [x,y]")
            for value in item["offset"]:
                number(value, "layer.offset", -1, 1)
    if any(totals[k] > LAYER_BUDGET[k] for k in totals):
        raise ValueError("Composition exceeds its element budget: " + str(LAYER_BUDGET))


def validate_effects(config):
    effects=config["effects"]
    if "layers" not in config:
        raise ValueError("effects requires explicit abstract layers")
    if "ticker" in config:
        raise ValueError("Use effects (with type:text) or legacy ticker, not both")
    if not isinstance(effects,list) or not 1<=len(effects)<=3:
        raise ValueError("effects must contain 1–3 foreground effect objects")
    seen=set()
    for item in effects:
        if not isinstance(item,dict) or not isinstance(item.get("type"),str) or item["type"] not in ("text","symbols","lightning","flash"):
            raise ValueError("effect.type must be text, symbols, lightning or flash")
        kind=item["type"]
        if kind in seen:raise ValueError("Use each foreground effect type at most once")
        seen.add(kind)
        if kind=="text":
            validate({"layers":[{"type":"flow"}],"ticker":{k:v for k,v in item.items() if k!="type"}})
            continue
        allowed={"type","count","colors","opacity","speed","scale","offset","occlude"}
        if kind!="symbols":allowed.add("period")
        if kind=="lightning":allowed.update({"rotation","angleRange"})
        if set(item)-allowed:raise ValueError("Unsupported foreground effect properties for "+kind)
        if "angleRange" in item:
            angles=item["angleRange"]
            if "rotation" in item or not isinstance(angles,list) or len(angles)!=2:raise ValueError("lightning.angleRange must be [min,max], without rotation")
            for angle in angles:number(angle,"effect.angleRange",-180,180)
            if angles[0]>angles[1]:raise ValueError("lightning.angleRange must be ordered [min,max]")
        count=item.get("count",8 if kind=="symbols" else 1 if kind=="lightning" else 2)
        if isinstance(count,bool) or not isinstance(count,int) or not 1<=count<=(14 if kind=="symbols" else 3):raise ValueError("Invalid count for "+kind)
        colors=item.get("colors",["#ffffff"])
        if not isinstance(colors,list) or not 1<=len(colors)<=3 or any(not isinstance(c,str) or re.fullmatch(r"#[0-9a-fA-F]{6}",c) is None for c in colors):raise ValueError("effect.colors needs 1–3 #RRGGBB colors")
        for key,lo,hi in (("opacity",.05,1),("speed",.05,2),("scale",.4,2),("period",4,30),("rotation",-180,180)):
            if key in item:number(item[key],"effect."+key,lo,hi)
        if "occlude" in item and not isinstance(item["occlude"],bool):raise ValueError("effect.occlude must be boolean")
        if "offset" in item:
            if not isinstance(item["offset"],list) or len(item["offset"])!=2:raise ValueError("effect.offset must be [x,y]")
            for value in item["offset"]:number(value,"effect.offset",-.5,.5)


def check_structure(config, preview=False):
    """Recipe-level presence/placement heuristic, not a rendered aesthetic test."""
    if preview:
        return {"status":"not-applicable","scope":"authoring preview"}
    if "layers" not in config:
        selected=config.get("preset",DEFAULT_PRESET)
        if CATALOG["presets"][selected].get("category")!="abstract":
            return {"status":"not-applicable","scope":"landscape renderer"}
        options=CATALOG["variants"][selected]
        chosen=next((v for v in options if v["id"]==config.get("variant")),options[0])
        config={**CATALOG["presets"][selected],**chosen["recipe"],**config}
    if config.get("largeShapeRequired", True) is False:
        return {"status": "waived", "scope": "explicit no-figure or reference request"}
    palette = dict(CATALOG["presets"][config.get("preset", DEFAULT_PRESET)]["palette"])
    palette.update(config.get("palette", {}))
    background = config.get("backgroundGradient", {}).get("colors") or [config.get("background", palette["sky"][0])]
    defaults = [palette["accent"], palette["light"], palette["sky"][2]]
    def contrast(layer):
        colors = layer.get("colors", defaults)
        return max(max(abs(int(c[k:k+2],16)-int(b[k:k+2],16)) for k in (1,3,5))/255
                   for c in colors for b in background) * layer.get("opacity", .45 if layer["type"]=="planes" else .6)
    def area(cx, cy, radius):
        rx = radius * 9/16
        return max(0,min(1,cx+rx)-max(0,cx-rx)) * max(0,min(1,cy+radius)-max(0,cy-radius))
    anchors = []
    for index, layer in enumerate(config["layers"]):
        kind=layer["type"]; style=layer.get("style", LAYER_STYLES[kind][0])
        scale=layer.get("scale",1); opacity=layer.get("opacity",.45 if kind=="planes" else .6)
        x,y=layer.get("offset",[0,0]); count=layer.get("count",LAYER_DEFAULTS[kind])
        if contrast(layer)<.035:
            continue
        if kind=="planes" and opacity>=.2 and layer.get("fill")=="gradient":
            if style in ("wave","split","band"):
                visible=abs(x)<=.35 and abs(y)<=.35 and (style!="band" or scale>=.65)
            else:
                visible=max(area(.5+x+(i-(count-1)/2)*.24,.5+y,.62*scale) for i in range(count))>=.12
                if style=="segment":visible=visible and layer.get("span",180)>=150
            if visible:anchors.append({"index":index,"type":kind,"style":style})
        if kind=="orbs" and opacity>=.4 and scale>=1.4:
            visible=max(area(.5+x+(i-(count-1)/2)*.28,.5+y,.1*scale) for i in range(count))>=.04
            if visible:anchors.append({"index":index,"type":kind,"style":style})
    if not anchors:
        raise ValueError("large_background_shape_required: add a visible large gradient planes layer "
                         "(wave/disc/split/band/segment), or a large in-frame orb (scale >= 1.4). "
                         "Thin grids, rain, stars, flow and text do not replace this form. "
                         "Keep the form in frame, with distinct tones and visible opacity. "
                         "Use largeShapeRequired=false only for an explicit no-figure/minimal brief or exact reference replay.")
    return {"status":"passed","anchors":anchors,"scope":"recipe heuristic; visual quality not measured"}


def script_json(value):
    payload = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    for a, b in (("&", "\\u0026"), ("<", "\\u003c"), (">", "\\u003e"), ("\u2028", "\\u2028"), ("\u2029", "\\u2029")):
        payload = payload.replace(a, b)
    return payload


@contextmanager
def measure(timings, name):
    started = time.perf_counter()
    try:
        yield
    finally:
        elapsed = (time.perf_counter() - started) * 1000
        timings[name] = timings.get(name, 0) + elapsed


def assemble(config, preview=False, phase=nullcontext):
    with phase("recipe_validation"):
        validate(config)
    with phase("html_assembly"):
        return assemble_html(config, preview, phase)


def assemble_html(config, preview, phase):
    selected = config.get("preset", DEFAULT_PRESET)
    if preview:
        catalog = CATALOG
    else:
        options = CATALOG["variants"][selected]
        chosen = next((v for v in options if v["id"] == config.get("variant")), options[0])
        catalog = {"defaultPreset": selected, "presets": {selected: CATALOG["presets"][selected]},
                   "variants": {selected: [] if "layers" in config else [chosen]}}
    for preset, settings in catalog["presets"].items():
        validate({k: v for k, v in settings.items() if k not in ("label", "category")})
        options = catalog["variants"].get(preset, [])
        if (not options and (preview or "layers" not in config)) or len({v["id"] for v in options}) != len(options):
            raise ValueError("A scene needs variants with unique IDs")
        for variant in options:
            if not re.fullmatch(r"[a-z][a-z0-9-]{0,39}", variant["id"]):
                raise ValueError("Invalid variant ID")
            validate(dict(variant["recipe"], preset=preset))
    replacements = {
        "__TITLE__": html.escape(config.get("title", "Живой фон")),
        "__MODE__": "preview" if preview else "scene",
        "__BACKGROUND__": config.get("background", (config.get("backgroundGradient", {}).get("colors") or CATALOG["presets"][selected]["palette"]["sky"])[0]),
        "__CONFIG__": script_json(config),
        "__CATALOG__": script_json(catalog),
        "__PRESET_OPTIONS__": "".join('<option value="'+html.escape(k, quote=True)+'">'+html.escape(v["label"])+'</option>' for k, v in catalog["presets"].items()),
        "__STYLE__": (ROOT / "assets/style.css").read_text(encoding="utf-8"),
        "__RUNTIME__": "\n".join((ROOT / ("assets/"+name)).read_text(encoding="utf-8") for name in ("patterns.js","foreground.js","runtime.js")),
    }
    text_effect=config.get("ticker") or next((e for e in config.get("effects",[]) if e["type"]=="text"),None)
    if text_effect is not None:
        with phase("font_embedding"):
            import base64
            import hashlib
            font_dir = ROOT / "assets/fonts"
            font_meta = json.loads((font_dir / ("semibold.json" if text_effect.get("fontWeight", 600) == 600 else "catalog.json")).read_text(encoding="utf-8"))
            encoded = "".join((font_dir / chunk).read_text(encoding="utf-8").strip() for chunk in font_meta["chunks"])
            raw = base64.b64decode(encoded, validate=True)
            if len(raw) != font_meta["bytes"] or hashlib.sha256(raw).hexdigest() != font_meta["sha256"]:
                raise ValueError("Embedded SB Sans Display font checksum failed")
            replacements["__STYLE__"] += "\n@font-face{font-family:SouzAmbientDisplay;src:url(data:font/woff2;base64," + encoded + ") format('woff2');font-weight:" + str(font_meta["weight"]) + ";font-style:normal;font-display:block}"
    template = (ROOT / "assets/page.html").read_text(encoding="utf-8")
    # One substitution pass: user strings cannot become template instructions.
    output = re.sub(r"__(?:TITLE|MODE|BACKGROUND|CONFIG|STYLE|RUNTIME|CATALOG|PRESET_OPTIONS)__", lambda match: replacements[match[0]], template)
    if len(output.encode("utf-8")) > 5_000_000:
        raise ValueError("HTML exceeds the TV viewer's 5 MB limit")
    return output


def write_checked(config, output, preview=False, phase=nullcontext):
    """One-call build, validation and exclusive HTML/recipe/check delivery."""
    started = time.perf_counter()
    result = assemble(config, preview=preview, phase=phase)
    with phase("structure_check"):
        structure = check_structure(config, preview=preview)
    with phase("checker_load"):
        spec = importlib.util.spec_from_file_location("ambient_offline_check", ROOT / "scripts/check.py")
        checker = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(checker)
    with phase("offline_checks"):
        checks = checker.check_source(result, output, phase=phase)
    checks["largeBackgroundShape"] = structure
    recipe_path = output.with_suffix(".recipe.json")
    checks_path = output.with_suffix(".checks.json")
    with phase("write_files"):
        files = [(recipe_path, json.dumps(config, ensure_ascii=False, indent=2)),
                 (checks_path, json.dumps(checks, ensure_ascii=False, indent=2)),
                 (output, result)]
        if any(path.exists() for path, _ in files):
            raise ValueError("Output or companion file already exists; choose a fresh filename")
        output.parent.mkdir(parents=True, exist_ok=True)
        created = []
        try:
            for path, text in files:
                with path.open("x", encoding="utf-8") as stream:
                    created.append(path)
                    stream.write(text)
        except OSError:
            for path in created:
                path.unlink(missing_ok=True)
            raise
    return {"path": str(output), "bytes": output.stat().st_size,
            "recipePath": str(recipe_path), "checksPath": str(checks_path),
            "mode": "preview" if preview else "scene", "quality": config.get("quality", "eco"),
            "checks": checks, "buildAndCheckMs": round((time.perf_counter()-started)*1000, 2)}


def main(phase=nullcontext):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", help="UTF-8 JSON file; otherwise read one JSON object from stdin")
    parser.add_argument("--preview", action="store_true", help="Include catalogue and authoring controls; default is one scene, with text only when requested")
    parser.add_argument("--list", action="store_true", help="List scene and variant IDs as JSON")
    parser.add_argument("--output", help="New absolute .html output path outside the skill bundle")
    args = parser.parse_args()
    if args.list:
        print(json.dumps({key: {"label": value["label"], "category": value.get("category", "landscape"), "variants": [{"id": v["id"], "label": v["label"]} for v in CATALOG["variants"][key]]} for key, value in CATALOG["presets"].items()}, ensure_ascii=False))
        return
    if not args.output:
        raise ValueError("--output is required unless --list is used")
    output = Path(args.output)
    if not output.is_absolute() or output.suffix.lower() != ".html":
        raise ValueError("--output must be an absolute .html path")
    resolved = output.resolve()
    if ROOT == resolved or ROOT in resolved.parents:
        raise ValueError("Generated files must stay outside the skill bundle")
    with phase("read_recipe"):
        raw = Path(args.config).read_text(encoding="utf-8") if args.config else sys.stdin.read(32769)
        if len(raw.encode("utf-8")) > 32768:
            raise ValueError("Configuration exceeds 32 KiB")
        config = json.loads(raw, parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Invalid number: " + value)))
    print(json.dumps(write_checked(config, output, preview=args.preview, phase=phase), ensure_ascii=False))


if __name__ == "__main__":
    # Loading check.py must not write into the installed skill bundle.
    sys.dont_write_bytecode = True
    timings = {"startup": (time.perf_counter() - STARTED) * 1000}
    status = "error"
    try:
        main(partial(measure, timings))
        status = "ok"
    except (ValueError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(2)
    finally:
        if "read_recipe" in timings:
            print(json.dumps({
                "event": "ambient.build",
                "status": status,
                "totalMs": round((time.perf_counter() - STARTED) * 1000, 2),
                "phasesMs": {name: round(ms, 2) for name, ms in timings.items()},
            }, separators=(",", ":")), file=sys.stderr)
