/* Independent Canvas 2D layers. Sprites are baked once, never inside draw(). */
const AmbientPatterns = (() => {
  const defaults = {flow:3, particles:24, ribbons:18, geometry:10, pulses:4, streams:28, shapes:24, planes:1, orbs:1};
  const maxima = {flow:5, particles:48, ribbons:28, geometry:18, pulses:8, streams:48, shapes:48, planes:3, orbs:2};
  const styles = {flow:'soft', particles:'dust', ribbons:'silk', geometry:'orbits', pulses:'rings', streams:'trails', shapes:'confetti', planes:'wave', orbs:'moon'};
  const tau = Math.PI * 2;
  const wrap = (value, length) => ((value % length) + length) % length;
  function rgba(hex, alpha) {
    return `rgba(${parseInt(hex.slice(1,3),16)},${parseInt(hex.slice(3,5),16)},${parseInt(hex.slice(5,7),16)},${alpha})`;
  }
  function sprite(width, height, paint) {
    const canvas = document.createElement('canvas');
    canvas.width = width; canvas.height = height;
    paint(canvas.getContext('2d'), width, height);
    return canvas;
  }
  function create({width:W, height:H, context:drawContext, palette, seed, layers, density=1}) {
    let state = seed;
    const random = () => {state=state*16807%2147483647; return (state-1)/2147483646;};
    const compiled = layers.map(spec => {
      const colors = spec.colors || [palette.accent,palette.light,palette.sky[2]];
      const type = spec.type, style = spec.style || styles[type];
      const count = Math.max(1,Math.min(maxima[type],Math.round((spec.count||defaults[type])*(type==='orbs'?1:Math.min(1,density)))));
      const opacity = spec.opacity === undefined ? (type==='planes'?.45:.6) : spec.opacity;
      const speed = spec.speed === undefined ? .7 : spec.speed;
      const scale = spec.scale || 1, weight = spec.weight || 1;
      const offset = spec.offset || [0,0];
      const rotation = (spec.rotation === undefined ? (type==='streams'&&style==='rain'?78:0) : spec.rotation)*Math.PI/180;
      const nodes = Array.from({length:count}, (_,i) => ({x:random(), y:random(), r:random(), phase:random()*tau, color:colors[i%colors.length]}));
      const strokes = colors.map(color => rgba(color,1));
      let planeGradient=null;
      if(type==='planes'&&spec.fill==='gradient'){
        const angle=(spec.gradientAngle===undefined?-35:spec.gradientAngle)*Math.PI/180;
        const length=Math.abs(W*Math.cos(angle))+Math.abs(H*Math.sin(angle));
        planeGradient=drawContext.createLinearGradient(W/2-Math.cos(angle)*length/2,H/2-Math.sin(angle)*length/2,W/2+Math.cos(angle)*length/2,H/2+Math.sin(angle)*length/2);
        colors.forEach((color,i)=>planeGradient.addColorStop(i/(colors.length-1),color));
      }
      let sprites = [];
      if (type==='flow'||type==='particles'||(type==='pulses'&&style==='bloom')) {
        sprites = colors.map(color => sprite(type==='flow'?256:96,type==='flow'?256:96,(context,w,h) => {
          const r=w/2, gradient=context.createRadialGradient(r,r,0,r,r,r);
          gradient.addColorStop(0,rgba(color,type==='flow'?.85:style==='bokeh'?.17:1));
          gradient.addColorStop(style==='bokeh'?.8:.28,rgba(color,type==='flow'?.5:style==='bokeh'?.13:.25));
          gradient.addColorStop(1,rgba(color,0));
          context.fillStyle=gradient;context.fillRect(0,0,w,h);
          if(style==='bokeh'){context.strokeStyle=rgba(color,.12);context.lineWidth=1;context.beginPath();context.arc(r,r,r*.83,0,tau);context.stroke();}
        }));
      } else if(type==='orbs') {
        sprites=colors.slice(0,count).map((color,index)=>sprite(style==='ringed-planet'?512:256,style==='ringed-planet'?384:256,(context,w,h)=>{
          const x=w/2,y=h/2,r=64,light=colors[(index+1)%colors.length];
          const halo=context.createRadialGradient(x,y,r*.6,x,y,r*1.95);
          halo.addColorStop(0,rgba(color,.22));halo.addColorStop(1,rgba(color,0));context.fillStyle=halo;context.fillRect(0,0,w,h);
          function ring(front){
            context.save();context.translate(x,y);context.rotate(-.27);
            for(let j=0;j<3;j++){context.beginPath();context.ellipse(0,0,r*(1.95+j*.1),r*(.59+j*.035),0,0,front?Math.PI:tau);context.strokeStyle=rgba(j===1?color:light,j===1?.5:.25);context.lineWidth=r*(j===1?.105:.045);context.stroke();}context.restore();
          }
          if(style==='ringed-planet')ring(false);
          context.save();context.beginPath();context.arc(x,y,r,0,tau);context.clip();
          const body=context.createLinearGradient(x-r,y-r,x+r,y+r);
          body.addColorStop(0,light);body.addColorStop(.48,color);body.addColorStop(1,rgba(color,.25));context.fillStyle=body;context.fillRect(x-r,y-r,r*2,r*2);
          if(style==='planet'||style==='ringed-planet'){
            for(let j=0;j<9;j++){const yy=y-r+j*r*.23;context.strokeStyle=rgba(light,j%2?.15:.07);context.lineWidth=r*(.04+j*.006);context.beginPath();context.moveTo(x-r,yy);context.bezierCurveTo(x-r*.35,yy+r*.16,x+r*.4,yy-r*.05,x+r,yy+r*.12);context.stroke();}
          }else if(style==='moon'){
            for(let j=0;j<9;j++){const a=j*2.4,rr=r*(.15+j*.075);context.beginPath();context.arc(x+Math.cos(a)*rr,y+Math.sin(a)*rr,r*(.04+j%3*.015),0,tau);context.fillStyle=rgba(light,.08);context.fill();}
          }
          const shade=context.createLinearGradient(x-r,y,x+r,y);shade.addColorStop(0,'rgba(0,0,0,0)');shade.addColorStop(1,'rgba(0,0,0,.38)');context.fillStyle=shade;context.fillRect(x-r,y-r,r*2,r*2);context.restore();
          if(style==='ringed-planet')ring(true);
        }));
      } else if(type==='ribbons'&&style==='aurora') {
        sprites=Array.from({length:3},(_,band)=>sprite(Math.ceil(W),Math.ceil(H*.38),(context,w,h)=>{
          for(let i=0;i<count;i++){
            context.beginPath();for(let k=0;k<=30;k++){const x=k*W/30,y=H*(.08+band*.026)+Math.sin(k*.17+band)*H*.038+i*H*.0017;if(k)context.lineTo(x,y);else context.moveTo(x,y);}
            context.strokeStyle=rgba(colors[band%colors.length],(1-i/count)*.035);context.lineWidth=H*.009*weight;context.stroke();
          }
        }));
      } else if (type==='streams') {
        sprites = colors.map(color => sprite(192,32,(context,w,h) => {
          const gradient=context.createLinearGradient(0,0,w,0);
          gradient.addColorStop(0,rgba(color,0));gradient.addColorStop(.7,rgba(color,.35));gradient.addColorStop(1,rgba(color,.9));
          context.fillStyle=gradient;context.fillRect(0,h*.4,w-8,h*.2);
          if(style==='comets'){
            const glow=context.createRadialGradient(w-12,h/2,0,w-12,h/2,12);
            glow.addColorStop(0,rgba(color,1));glow.addColorStop(1,rgba(color,0));
            context.fillStyle=glow;context.fillRect(w-24,0,24,h);
          }
        }));
      } else if (type==='shapes') {
        sprites = colors.map(color => sprite(96,96,(context,w,h) => {
          context.fillStyle=color;context.beginPath();
          if(style==='petals')context.ellipse(w/2,h/2,w*.37,h*.2,-.4,0,tau);
          else if(style==='shards'){context.moveTo(w*.16,h*.85);context.lineTo(w*.47,h*.1);context.lineTo(w*.84,h*.72);context.closePath();}
          else context.rect(w*.18,h*.29,w*.64,h*.42);
          context.fill();
        }));
      }
      const padding=type==='streams'?H*(.2+.46*scale):H*.4+W*(style==='petals'?.2:0);
      const extent=Math.hypot(W,H)+padding+2*Math.hypot(W*offset[0],H*offset[1]);
      const waveLength=H*(spec.wavelength||2)*scale;
      const waveExtent=Math.hypot(W,H)/2+Math.hypot(W*offset[0],H*offset[1])+W*.12*(count-1)+(W*.035+H*.045)*(spec.drift===undefined?1:spec.drift)+H*.1;
      const waveSteps=Math.min(256,Math.max(48,Math.ceil(waveExtent*2/waveLength*32)));
      const waveYs=type==='planes'&&style==='wave'?Array.from({length:waveSteps+1},(_,i)=>-waveExtent+i*waveExtent*2/waveSteps):[];
      function draw(context, travel, mask=false) {
        if(mask&&type!=='planes')return;
        const t=travel*speed;
        context.save();context.globalAlpha=mask?1:opacity;context.globalCompositeOperation=mask?'destination-out':spec.blend||(type==='planes'||type==='orbs'?'source-over':'screen');
        context.translate(W*offset[0],H*offset[1]);
        if(type==='orbs') {
          for(let i=0;i<count;i++){
            const texture=sprites[i%sprites.length],ratio=H*.1*scale/64;
            context.save();context.translate(W*(.5+(i-(count-1)/2)*.28),H*.5);context.rotate(rotation);
            context.drawImage(texture,-texture.width*ratio/2,-texture.height*ratio/2,texture.width*ratio,texture.height*ratio);context.restore();
          }
        } else if(type==='planes') {
          const drift=spec.drift===undefined?1:spec.drift,spin=spec.spin===undefined?.5:spec.spin;
          const reach=2*Math.hypot(W,H)+2*Math.hypot(W*offset[0],H*offset[1]);
          for(let i=0;i<count;i++){
            const n=nodes[i],x=W*(.5+(i-(count-1)/2)*.24+Math.sin(t*.13+n.phase)*.035*drift);
            const y=H*(.5+Math.cos(t*.11+n.phase)*.045*drift);
            context.save();context.translate(x,y);context.rotate(rotation+t*spin*.008);
            context.fillStyle=mask?'#000000':planeGradient||strokes[i%strokes.length];context.beginPath();
            if(style==='wave'){
              const amplitude=(spec.amplitude===undefined?.13:spec.amplitude)*H*scale;
              const phase=t*(spec.waveSpeed===undefined?.09:spec.waveSpeed)+n.phase;
              for(let k=0;k<waveYs.length;k++){
                const yy=waveYs[k],xx=amplitude*Math.sin(yy/waveLength*tau+phase);
                if(k)context.lineTo(xx,yy);else context.moveTo(xx,yy);
              }
              context.lineTo(reach,waveExtent);context.lineTo(reach,-waveExtent);
            } else if(style==='split')context.rect(0,-reach,reach,reach*2);
            else if(style==='band')context.rect(-reach,-H*.17*scale,reach*2,H*.34*scale);
            else {
              const radius=H*.62*scale,span=(spec.span||180)*Math.PI/180;
              if(style==='disc')context.arc(0,0,radius,0,tau);
              else context.arc(0,0,radius,-span/2,span/2);
            }
            context.closePath();context.fill();
            if(!mask&&style==='split'&&spec.edgePattern==='stitches'){
              const spacing=H*.086, size=H*.0065;
              const shift=wrap(t*H*.018,spacing);
              context.globalAlpha=opacity*.72;
              context.strokeStyle=strokes[strokes.length-1];
              context.lineWidth=Math.max(.8,H*.0018);context.lineCap='round';
              context.beginPath();
              for(let mark=-reach+shift;mark<reach;mark+=spacing){
                context.moveTo(-size,mark-size);context.lineTo(size,mark+size);
                context.moveTo(0,mark+spacing*.48);context.lineTo(0,mark+spacing*.48+.4);
              }
              context.stroke();
            }
            context.restore();
          }
        } else if(type==='flow') {
          for(let i=0;i<count;i++){
            const n=nodes[i],x=W*(.15+(count===1?.5:i/(count-1))*.7+Math.sin(t*.34+n.phase)*.12),y=H*(.48+Math.cos(t*.27+n.phase)*.22);
            const ww=W*(.5+Math.sin(t*.18+n.phase)*.1)*scale,hh=H*(.95+Math.cos(t*.23+n.phase)*.18)*scale;
            context.save();context.translate(x,y);context.rotate(rotation+Math.sin(t*.13+n.phase)*.35);context.drawImage(sprites[i%sprites.length],-ww/2,-hh/2,ww,hh);context.restore();
          }
        } else if(type==='particles') {
          context.translate(W/2,H/2);context.rotate(rotation);context.translate(-W/2,-H/2);
          if(style==='constellation'){
            context.strokeStyle=rgba(colors[0],.18);context.lineWidth=.6;context.beginPath();
            for(let i=1;i<count;i++){
              const n=nodes[i],p=nodes[i-1],x=W*(n.x+Math.sin(t*.23+n.phase)*.05),y=H*(n.y+Math.cos(t*.19+n.phase)*.06);
              const px=W*(p.x+Math.sin(t*.23+p.phase)*.05),py=H*(p.y+Math.cos(t*.19+p.phase)*.06);
              if(Math.abs(x-px)<W*.26&&Math.abs(y-py)<H*.35){context.moveTo(px,py);context.lineTo(x,y);}
            }context.stroke();
          }
          for(let i=0;i<count;i++){
            const n=nodes[i],x=W*(n.x+Math.sin(t*.23+n.phase)*.05),y=H*(n.y+Math.cos(t*.19+n.phase)*.06);
            const size=H*(style==='bokeh'?.08+n.r*.13:.004+n.r*.008)*scale;
            context.globalAlpha=opacity*(.55+Math.sin(t*.7+n.phase)*.3);context.drawImage(sprites[i%sprites.length],x-size/2,y-size/2,size,size);
          }
        } else if(type==='ribbons'&&style==='aurora') {
          context.translate(W/2,H*.25);context.rotate(rotation);
          for(let j=0;j<sprites.length;j++){
            context.drawImage(sprites[j],W*(-.57+Math.sin(t*.2+j)*.028),H*(-.2+j*.008+Math.sin(t*.36+j)*.022),W*(1.15+Math.sin(t*.17+j)*.025)*scale,H*.38*scale);
          }
        } else if(type==='ribbons') {
          context.translate(W/2,H/2);context.rotate(rotation);context.translate(-W/2,-H/2);
          for(let i=0;i<count;i++){
            const v=i/Math.max(1,count-1),phase=v*1.25,tone=Math.min(colors.length-1,Math.floor(v*colors.length));
            context.strokeStyle=strokes[tone];context.globalAlpha=opacity*(style==='aurora'?.075:.28);
            context.lineWidth=(style==='aurora'?H*.009:style==='wave'?H*.002:Math.max(.55,H*.0012))*scale*weight;context.beginPath();
            for(let k=0;k<=32;k++){
              const u=k/32,x=W*(u*1.24-.12);
              const y=H*(.49+Math.sin(u*Math.PI*(style==='wave'?1.15:1.8)+t*.42+phase)*.18*scale+Math.sin(u*Math.PI*3.3-t*.24+phase)*(style==='wave'?.015:.04)*scale+(v-.5)*.17);
              if(k)context.lineTo(x,y);else context.moveTo(x,y);
            }context.stroke();
          }
        } else if(type==='geometry'&&style==='pulse-lattice') {
          const columns=Math.max(2,count), rows=Math.max(2,Math.round(columns*.64));
          const spacing=H*.21*scale;
          const left=-(columns-1)*spacing/2, top=-(rows-1)*spacing/2;
          context.translate(W/2,H/2);context.rotate(rotation+t*.055);
          context.strokeStyle=strokes[0];context.lineWidth=Math.max(.55,H*.0011)*weight;
          context.globalAlpha=opacity*.52;context.beginPath();
          for(let column=0;column<columns;column++){
            const x=left+column*spacing;
            context.moveTo(x,top);context.lineTo(x,-top);
          }
          for(let row=0;row<rows;row++){
            const y=top+row*spacing;
            context.moveTo(left,y);context.lineTo(-left,y);
          }
          context.stroke();
          context.fillStyle=strokes[strokes.length-1];
          for(let row=0;row<rows;row++){
            for(let column=0;column<columns;column++){
              const phase=wrap(t*.4-column*.12-row*.16,1);
              if(phase>.34)continue;
              const envelope=Math.sin(Math.PI*phase/.34)**2;
              context.globalAlpha=opacity*envelope;
              context.beginPath();
              context.arc(left+column*spacing,top+row*spacing,Math.max(1.1,H*.005)*weight,0,tau);
              context.fill();
            }
          }
        } else if(type==='geometry') {
          context.translate(W*.5,H*.5);context.rotate(rotation);context.lineWidth=Math.max(.55,H*.0011)*weight;
          for(let i=0;i<count;i++){
            const n=nodes[i],r=H*(.1+i*.027)*scale;
            context.strokeStyle=strokes[i%strokes.length];context.globalAlpha=opacity*.45;context.save();context.rotate(t*(i%2?.11:-.09)+i*.22);context.beginPath();
            if(style==='lattice'){
              const x=(i/Math.max(1,count-1)-.5)*W*1.15;
              context.moveTo(x,-H*.65);context.lineTo(x+Math.sin(t*.3+n.phase)*W*.1,H*.65);
              context.moveTo(-W*.65,x*H/W);context.lineTo(W*.65,x*H/W+Math.cos(t*.26+n.phase)*H*.09);
            } else if(style==='rings')context.arc(0,0,r,t*.15+i*.4,t*.15+i*.4+Math.PI*1.55);
            else context.ellipse(0,0,r*1.65,r*.56,0,0,tau);
            context.stroke();
            if(style!=='lattice'){const angle=t*.6+i*.55;context.fillStyle=n.color;context.beginPath();context.arc(Math.cos(angle)*r*(style==='orbits'?1.65:1),Math.sin(angle)*r*(style==='orbits'?.56:1),Math.max(.8,H*.002),0,tau);context.fill();}
            context.restore();
          }
        } else if(type==='pulses') {
          const period=spec.period||10, spread=spec.spread===undefined?.6:spec.spread;
          const synchrony=spec.synchrony===undefined?0:spec.synchrony;
          context.translate(W/2,H/2);context.rotate(rotation);
          for(let i=0;i<count;i++){
            const n=nodes[i],u=wrap(t/period+n.phase/tau*(1-synchrony),1);
            const envelope=Math.sin(Math.PI*u)**2;
            const radius=H*(.08+.35*u)*scale;
            const x=(n.x-.5)*W*spread,y=(n.y-.5)*H*spread;
            context.globalAlpha=opacity*envelope;context.strokeStyle=strokes[i%strokes.length];context.lineWidth=Math.max(.8,H*.0022)*weight;
            if(style==='bloom')context.drawImage(sprites[i%sprites.length],x-radius,y-radius,radius*2,radius*2);
            else {
              context.beginPath();
              if(style==='rays'){
                for(let k=0;k<12;k++){const a=k*tau/12+n.phase+t*.08;context.moveTo(x+Math.cos(a)*radius*.65,y+Math.sin(a)*radius*.65);context.lineTo(x+Math.cos(a)*radius,y+Math.sin(a)*radius);}
              } else context.arc(x,y,radius,0,tau);
              context.stroke();
            }
          }
        } else if(type==='streams') {
          context.translate(W/2,H/2);context.rotate(rotation);
          for(let i=0;i<count;i++){
            const n=nodes[i],x=wrap(n.x*extent+t*H*(.07+n.r*.055),extent)-extent/2;
            const y=(n.y-.5)*extent+Math.sin(t*.35+n.phase)*H*.018;
            const length=H*(style==='rain'?.035+n.r*.07:.08+n.r*.15)*scale;
            const thickness=H*(style==='comets'?.016:.008)*weight;
            context.globalAlpha=opacity*(.5+n.r*.45);
            context.drawImage(sprites[i%sprites.length],x-length,y-thickness/2,length,thickness);
          }
        } else if(type==='shapes') {
          const spin=spec.spin===undefined?.7:spec.spin;
          context.translate(W/2,H/2);context.rotate(rotation);
          for(let i=0;i<count;i++){
            const n=nodes[i],y=wrap(n.y*extent+t*H*(style==='petals'?.035:.065)*(n.r+.65),extent)-extent/2;
            const x=(n.x-.5)*extent+Math.sin(t*.55+n.phase)*W*(style==='petals'?.1:.035);
            const size=H*(style==='shards'?.035+n.r*.065:style==='petals'?.025+n.r*.045:.016+n.r*.028)*scale;
            const angle=n.phase+t*spin*(.35+n.r)*(i%2?1:-1);
            const flip=.18+.82*Math.abs(Math.cos(n.phase+t*spin*.8));
            context.save();context.translate(x,y);context.rotate(angle);context.globalAlpha=opacity*(style==='shards'?.35:.85);
            context.drawImage(sprites[i%sprites.length],-size*flip/2,-size/2,size*flip,size);context.restore();
          }
        }
        context.restore();
      }
      return {draw,type,count};
    });
    return {draw(context,time){for(const layer of compiled)layer.draw(context,time);},occlude(context,time){for(const layer of compiled)if(layer.type==='planes')layer.draw(context,time,true);},counts:compiled.map(({type,count})=>({type,count}))};
  }
  return {create};
})();
