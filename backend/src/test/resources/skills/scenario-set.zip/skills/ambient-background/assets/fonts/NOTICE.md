SB Sans Display Regular and Semibold 0.2.0, reused from the local html-infographic Skill.
Official source and SHA-256 are recorded in catalog.json and semibold.json. No open-source font
license is asserted; use within the owner’s permitted scope. Embedded in output.
