"""Write one ready-made ambient background and print its sandbox path."""
import argparse
import json
import re
import sys
import unicodedata
import uuid
from pathlib import Path

ASSETS = Path(__file__).resolve().parents[1] / "assets"
CONFIG = '{"ambientPresetConfig":true}'
BACKGROUND = "#010203"
JSON_ESCAPES = str.maketrans({"&": r"\u0026", "<": r"\u003c", ">": r"\u003e",
                             "\u2028": r"\u2028", "\u2029": r"\u2029"})


def apply_accent(scene, color):
    if not isinstance(color, str) or re.fullmatch(r"#[0-9a-fA-F]{6}", color) is None:
        raise ValueError("Use a color in #RRGGBB form")
    rgb = bytes.fromhex(color[1:])

    def mix_gray(gray, amount):
        return "#" + bytes(round(channel + (gray - channel) * amount) for channel in rgb).hex()

    gradient = scene["backgroundGradient"]
    dark, mid = gradient["colors"]
    flow = next(layer for layer in scene["layers"] if layer["type"] == "flow")
    accent, highlight = flow["colors"]
    palette = {
        dark: mix_gray(5, 0.86),
        mid: mix_gray(42, 0.65),
        accent: color.lower(),
        highlight: mix_gray(255, 0.62),
    }
    gradient["colors"] = [palette[dark], palette[mid]]
    for layer in scene["layers"]:
        layer["colors"] = [palette[value] for value in layer["colors"]]
    ticker = scene["ticker"]
    ticker["color"] = palette[ticker["color"]]


def render(preset, phrase, color=None, *, motion=None, brightness=None):
    catalog = json.loads((ASSETS / "ambient-presets.json").read_text(encoding="utf-8"))
    if preset not in catalog["presets"]:
        raise ValueError("Unknown preset")
    if len(phrase.encode("utf-16-le")) > 240 or any(unicodedata.category(char) == "Cc" for char in phrase):
        raise ValueError("Use a phrase of at most 120 UTF-16 code units without control characters")
    scene = catalog["presets"][preset]["scene"]
    if color is not None:
        apply_accent(scene, color)
    for key, value, minimum in (("motion", motion, 0), ("brightness", brightness, 0.25)):
        if value is None:
            continue
        if type(value) not in (int, float) or not minimum <= value <= 1:
            raise ValueError(f"{key} must be a number from {minimum} to 1")
        scene[key] = value
    if phrase:
        scene["ticker"]["text"] = phrase
    else:
        del scene["ticker"]
        if preset == "teal":
            scene["layers"] = [
                layer for layer in scene["layers"]
                if (layer["type"], layer.get("style")) != ("planes", "band")
            ]
    data = json.dumps(scene, ensure_ascii=False, separators=(",", ":")).translate(JSON_ESCAPES)
    template = (ASSETS / "preset-template.html").read_text(encoding="utf-8")
    if template.count(CONFIG) != 1 or template.count(BACKGROUND) != 2:
        raise ValueError("Invalid preset template")
    return template.replace(BACKGROUND, scene["backgroundGradient"]["colors"][0]).replace(CONFIG, data, 1)


def parse_options(raw):
    options = json.loads(raw)
    if not isinstance(options, dict) or options.keys() - {"color", "motion", "brightness"}:
        raise ValueError("Options must be a JSON object with color, motion, or brightness")
    if None in options.values():
        raise ValueError("Omit unused options")
    return options


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("preset")
    parser.add_argument("phrase")
    overrides = parser.add_mutually_exclusive_group()
    overrides.add_argument("--color")
    overrides.add_argument("--options", default="{}")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        options = parse_options(args.options)
        if args.color is not None:
            options["color"] = args.color
        html = render(args.preset, args.phrase, **options)
        output = args.output or (Path("/souz/workspace/ambient-background") / f"{args.preset}-{uuid.uuid4().hex}.html")
        output = output.resolve()
        if output.suffix != ".html" or ASSETS.parent in output.parents:
            raise ValueError("Use an HTML output path outside the skill bundle")
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("x", encoding="utf-8") as stream:
            stream.write(html)
    except (OSError, ValueError) as error:
        parser.exit(2, f"{error}\n")
    sys.stdout.write(str(output))


if __name__ == "__main__":
    main()
