# Secondary landscape library

For abstract backgrounds and free layer composition, use `patterns.md` instead.
These presets apply when the user requests literal scenery.


Recipes are JSON objects. Omitted fields inherit the selected variant, then its
scene. `seed` makes geometry repeatable. `assets/catalog.json` is the maintained
source for scene palettes and variant recipes; do not load its full contents into
context for routine generation. `scripts/compose.py --list` prints the small list
of available IDs and labels.

| Preset | Variants (`id`: mood) |
| --- | --- |
| `sunset` | `golden`: honey sunset · `rose`: pink evening with mist · `twilight`: moonlit afterglow |
| `arctic` | `aurora`: northern lights and snow · `daylight`: polar day · `snow-night`: dark snowy night |
| `jungle` | `fireflies`: tropical dusk · `rain`: tropical rain · `moonlit`: moonlit lagoon |
| `city` | `windows`: warm windows · `neon`: colored lights · `rain`: rainy lake |
| `forest` | `dawn`: misty dawn · `moonlit`: moon and fireflies · `rain`: forest rain |
| `desert` | `golden`: dunes and dust · `oasis`: palms and water · `starlit`: moon and meteors |
| `space` | `nebula`: purple nebula and a planet · `rings`: ringed planet · `meteors`: open starfield with shooting stars |

The first listed variant is the default for its scene. A variant changes geometry,
weather, celestial objects or lighting as appropriate, not necessarily every one
of those dimensions. Mood words guide selection and overrides; they do not need
to match the Russian UI labels literally.

## Inputs

| Key | Accepted value |
| --- | --- |
| `preset` | One of the seven scene IDs above |
| `variant` | One variant ID belonging to the chosen scene |
| `title` | 1–160 characters; metadata and accessible label, not overprinted on the scene |
| `landscape` | `mountains`, `icebergs`, `jungle`, `city`, `forest`, `dunes`, `space` |
| `foreground` | `reeds`, `ice`, `tropical`, `pines`, `cacti`, `none` |
| `atmosphere` | `fireflies`, `snow`, `mist`, `stars`, `rain`, `dust`, `meteors`, `none` |
| `celestial` | `sun`, `moon`, `planet`, `ringed-planet`, `none` |
| `water`, `aurora` | boolean |
| `horizon` | 0.40–0.70, fraction of viewport height |
| `motion` | 0–1; normally 0.50, restrained 0.20, stronger 0.75; omitted inherits the variant |
| `brightness` | 0.25–1; default 1 |
| `quality` | `eco` (default), `balanced` |
| `seed` | integer 1–2147483646 |
| `palette` | Optional partial object described below |

Explicit overrides win over the variant. A variant's name and ID remain its
starting point even after customization. Switching the UI scene or variant keeps
the user's current motion, brightness and quality settings; it does not export
them or use browser storage. `motion: 0` freezes spatial movement while sparkle
fading can continue. Pause freezes the scene completely.

Palette keys are `sky` (four colors, zenith to horizon), `water` (two colors,
horizon to near water), `mountain` (three colors, back to front), and single colors
`disc`, `light`, `ground`, `foliage`, `accent`, `window`. Colors are `#RRGGBB`.
`disc` and `accent` also color planets; `light` colors rings, reflections and glows.
Omitted keys inherit the variant. Inputs cannot contain arbitrary HTML, scripts or
external resource paths.

## Reusable elements

Pine shores combine with any water scene; dunes have an explicit water-aware form
for oases. Cacti and tropical palms are separate foreground choices. Ringed planets
and meteors can be added to another scene for a fantasy landscape. Rain uses three
streaks per atmospheric particle in one batched path. Dust and fireflies reuse
cached glow sprites. Aurora ribbons, clouds and mist are independent cached layers.
Planets, rings, forest silhouettes and nebula backgrounds are baked statically.

Examples:

```json
{"preset":"forest","variant":"moonlit","title":"Лунное озеро","motion":0.45}
```

```json
{"preset":"desert","variant":"oasis","atmosphere":"mist","title":"Тихий оазис"}
```

```json
{"preset":"city","variant":"neon","aurora":true,"foreground":"ice","atmosphere":"snow","title":"Северный город"}
```

```json
{"preset":"space","variant":"rings","atmosphere":"meteors","palette":{"accent":"#ac8ba6","disc":"#ead0b1"},"title":"Кольца далёкой планеты"}
```

## Performance and verification

Do not match raster resolution to the physical panel. `eco` uses at most 960×540
overlay pixels at a target 24 FPS, 190 wavelets, ten cached wave bands and 18
atmospheric particles. Rain produces at most 54 short segments, drawn in a single
stroke. Meteors use at most three cached sprites; only the visible time windows
are drawn. `balanced` uses 1280×720, 300 wavelets and 28 particles. Slow rendering
can fall back to 720×405 at 18 FPS, 110 wavelets and 12 particles. Only one scene
is active, regardless of how many variants are packaged in the file.

The static canvas is at most 1280×720. Clouds, aurora, nebula drift and wave sprites
are cached; gradients are not created each animation frame. Foreground is static
SVG without blur filters. Hidden/paused scenes have no scheduled animation frames.

In authoring preview, press D; in either mode inspect `document.documentElement.dataset.ambientStats` for scene and
variant IDs, budgets, observed cadence, CPU draw-call P50/P95 and static build count.
These timings exclude GPU raster/compositing and thermal behavior; desktop results
do not establish physical TV performance. Keep measurements and screenshots outside
the bundle. The skill does not require Chromium or install a screenshot renderer.

When extending the library, check affected variants' appearance, movement,
authoring controls, hidden/resume and pixel budgets. Pause/resume belongs to
preview; delivered scenes play continuously. Static build count must stay
unchanged during steady animation. Verify the standalone file directly in a
browser, then the TV’s Firefox fork for physical acceptance. An iframe wrapper
is only relevant for a separate client that explicitly embeds HTML. Adding an
entry to the catalogue does not implement a new geometry renderer.
