---
name: ambient-background
version: 2.6.0
description: Create and attach an animated HTML background for TV or chat. Ready-made scenes support an accent color, motion speed, brightness and short text. Compose a custom scene for specific visual requirements or edits.
commands:
  preset:
    inputs: [preset, phrase]
    steps:
      - id: rendered
        runtime: PYTHON
        script: scripts/render_preset.py
        args: ["--", "${inputs.preset}", "${inputs.phrase}"]
      - id: attached
        tool: AttachFileToReply
        arguments:
          path: "${rendered}"
          presentation: document
    returns: "${attached}"
  preset_with_color:
    inputs: [preset, phrase, color]
    steps:
      - id: rendered
        runtime: PYTHON
        script: scripts/render_preset.py
        args: ["--color", "${inputs.color}", "--", "${inputs.preset}", "${inputs.phrase}"]
      - id: attached
        tool: AttachFileToReply
        arguments:
          path: "${rendered}"
          presentation: document
    returns: "${attached}"
  preset_with_options:
    inputs: [preset, phrase, options]
    steps:
      - id: rendered
        runtime: PYTHON
        script: scripts/render_preset.py
        args: ["--options", "${inputs.options}", "--", "${inputs.preset}", "${inputs.phrase}"]
      - id: attached
        tool: AttachFileToReply
        arguments:
          path: "${rendered}"
          presentation: document
    returns: "${attached}"
---

# Ambient background composer

Deliver one UTF-8 HTML file by choosing, coloring and arranging existing layers.
For an ordinary request, aim for request-to-file latency around one minute. This
is a workflow target, not a guarantee about model/tool service latency.

Target playback is a standalone HTML file opened directly in the TV’s Firefox
fork. No iframe or separate Souz viewer is required. Deliver continuous animation
without playback controls. Physical TV behavior remains a device check.

## Invocation

Skill ID: `ambient-background`; user-facing name: «Живые фоны».
Natural requests such as «Создай анимированный фон для телевизора: бархат,
вдохновение» or «Используй ambient-background: первопроходцы вселенной» select
this skill. The brief may specify associations, mood, palette, an approved
reference, and supplied copy or its source. Text and source are optional. Foreground effects can also supply sharper visual events.
Deliver the autonomous HTML as a file; show it on a device only when requested.

## Ready-made backgrounds

Choose a preset when it fulfills the entire request for one new HTML file.
Keep a known explicit preset ID. Otherwise match the scene's shape and motion first.
For a color-only brief, choose the closest stock palette.

| ID | Stock color and scene |
| --- | --- |
| `yellow` | Жёлтый диск с мелкой пылью, солнце или золотой рассвет |
| `green` | Зелёная мягкая волна с рассеянным светом и мелкой пылью, подходит для сияния и бархата любого цвета |
| `teal` | Бирюзовый фон с мягким боке, напоминающий морскую гладь |
| `blue` | Синяя ночь с луной, большим диском и созвездиями |
| `pink` | Розовый закат с боке и тонкой наклонной линией, вдоль которой медленно движутся короткие штрихи и точки |
| `silver` | Серебристая горизонтальная полоса с мелкой пылью и холодным светом |
| `rain` | Сине-серый дождь на стекле, косые струи и мягкие блики |
| `orbit` | Сиреневая кольчатая планета сбоку, звёзды и медленно вращающиеся орбитальные дуги |
| `lattice` | Зеленоватая световая решётка, плавный поворот и импульсы на пересечениях |
| `petals` | Персиково-розовые лепестки, крупные падают ближе, мелкие дрейфуют вдали |

Use the normal workflow below for no match, custom objects or effects,
references, edits to previous backgrounds, or any additional requested action
such as opening the file on a TV. A request for a background *for* TV can use a
preset. Preserve a supplied caption verbatim, invent a short one in the user's
language when requested, and use an empty string when no text is requested.
Use the normal workflow if the caption needs external information, exceeds
120 UTF-16 code units, or contains control characters.

Use `preset` for the stock scene. For visual adjustments, use
`preset_with_options` and include only the requested keys in `options`.

- `color` sets the accent and derives the rest of the palette. Use it for an
  explicit hex or when the requested color differs from the chosen scene's
  stock palette. Expand `#RGB` or convert a named color to a representative
  `#RRGGBB`. For multiple independent colors or a gradient, use the normal
  workflow.
- `motion` sets animation speed from 0 to 1. The stock value is 0.36.
  Use 0 for a still scene, around 0.18 for slower, or 0.55 for faster.
- `brightness` sets overall brightness from 0.25 to 1. The stock value is 1.
  Use around 0.65 for a dimmer scene.

Convert an absolute percentage to a fraction. For a relative request,
apply the change to the stock value, within the supported range.

Pass `options` as a serialized JSON object string. Pass `phrase` as a JSON
string literal inside the input string so text such as `true` stays text.
Example with a dimmer, slower moon scene and a mint accent:

```json
{"skillId":"ambient-background","arguments":{"composite":"preset_with_options","inputs":{"preset":"blue","phrase":"\"Спокойной ночи\"","options":"{\"color\":\"#98FFCC\",\"motion\":0.18,\"brightness\":0.65}"}}}
```

For no text, send `"\"\""` as `phrase`. The `teal` preset shows its band only
with a caption. The command renders and attaches the HTML. Reply after it succeeds.

## Normal request: one build call

1. Choose one visual idea, composition and motion using the variation rules below. Keep soft
   gradient depth and visible layered light. Vary the dominant motif; bokeh,
   waves, planes and planets are available elements, not a compulsory combination.
   Use a continuous background gradient and distinguish light/midtone/shadow.
   A quiet scene still needs a readable light feature or structure. Prefer slower
   motion over simultaneously suppressing brightness and every layer's opacity.
2. Send a concise JSON recipe directly to `scripts/compose.py` via
   `RunSkillCommand(skillId="ambient-background", arguments={"runtime":"PYTHON",
   "scriptPath":"scripts/compose.py", "args":["--output", fresh_absolute_html_path],
   "stdin":recipe_json})`. Use `/souz/workspace/ambient-background/` for outputs,
   outside the installed bundle. `--config` also accepts a JSON file.
3. Attach the returned `path` with `AttachFileToReply(presentation="document")`.
   The same build creates `.recipe.json` and `.checks.json` companions and returns
   their paths. Parents must explicitly select a child's file for delivery.
   Keep the caption brief.

The default build is one selected scene, with optional text chosen by the rules below: no example catalogue,
menus, pause or scene-browsing keys. It runs continuously while visible; F requests fullscreen. It validates
recipe/budgets, offline packaging and JavaScript syntax when Node is available
before publishing the file. Do not hand-edit HTML, strip menus/catalogues, rerun
check.py or write extra generation scripts in the normal path.

Execute ordinary compositions directly. Do not spawn subagents, start a web
server, open a browser, take screenshots, build viewer wrappers, run test suites,
inspect renderer source or repeatedly load all references for every background.
Those are development tasks when changing primitives, diagnosing a demonstrated
failure, or explicitly requested visual QA. On a validation error, correct the
reported field and retry; do not start an open-ended redesign loop.

## Variation for new compositions

Use controlled random choice when the user asks for a new background. First
filter available primitives by the theme, mood, preferences and device budget;
then randomly choose compatible motifs from that pool. Build combinations of
individual elements rather than randomly selecting a fixed finished scene.
Choose a dominant motif and supporting layers with different scales and rhythms,
retaining visible light volume and depth even without text.

Vary these choices independently: structural silhouette (wave, disc, split,
band, segment or a large orb), placement and occupied area,
atmosphere/detail (bokeh, dust, rain, aurora, streams, curves, geometry, pulses),
and motion (drift, flow, rise/fall, rotation, breathing). Color alone is not a new
composition. Not every primitive belongs in every scene; do not choose confetti
unless requested or let randomness override the brief.

When recent recipes are visible in the conversation, exclude the last two
compositions' dominant silhouette + supporting-motif combinations and vary the
layout or motion too. Do not replace the repeated band/rings layout with a new
universal disc/steam layout. Without recent context, make a fresh eligible draw;
do not claim cross-session history or persist a global rotation state.

Preserve an approved reference on a requested replay or targeted edit. Randomize
only the choices the user leaves open; preserve supplied copy and typography.
Record every selected element and parameter in the normal recipe with a fresh
`seed` for a new composition. Changing `seed` alone only changes procedural
placements/phases; it does not select a different layer combination. The saved
HTML repeats the chosen composition rather than rerolling it on every open.
These are recipe-selection rules; keep the normal one-build workflow.

## Compact recipe reference

Top level: optional `title`, `background` (#RRGGBB fallback),
`backgroundGradient` (`colors`: 2–6 hex colors, `angle`: -180–180), `quality`
(`eco` default or `balanced`), `motion` 0–1 (usually 0.55–0.75), `brightness`
0.25–1 (usually 0.9–1), integer `seed` 1–2147483646, and required `layers` for a
free composition. `largeShapeRequired` defaults to true; see the structural rule above. No preset or profile ID is needed.

Each layer: `type`, optional `style`, `colors` (1–6 hex), `count`, `opacity` 0–1,
`speed` 0.05–3, `scale` 0.25–3, `rotation` -180–180, `offset: [x,y]` each -1–1,
`blend: "screen"` or `"source-over"`. Defaults work; omit unnecessary parameters.
There are at most four moving layers plus two static orb layers/objects.

| Type | Styles | Count: default / per-layer max / total max |
| --- | --- | --- |
| flow | soft | 3 / 5 / 6 |
| particles | dust, bokeh, constellation | 24 / 48 / 64 |
| ribbons | silk, wave, aurora | 18 / 28 / 40 |
| geometry | orbits, rings, lattice, pulse-lattice | 10 / 18 / 24 |
| pulses | rings, bloom, rays | 4 / 8 / 10 |
| streams | trails, comets, rain | 28 / 48 / 64 |
| shapes | confetti, petals, shards | 24 / 48 / 64 |
| planes | wave, split, disc, band, segment | 1 / 3 / 3 |
| orbs (static) | sun, moon, planet, ringed-planet | 1 / 2 / 2 |

- `weight` 0.25–4: stroke width for ribbons/geometry/pulses/streams.
- Pulses: `period` 4–30 travel seconds, `spread`/`synchrony` 0–1.
- Shapes/planes: `spin` -3–3. Planes: `drift` 0–2, optional `fill: "gradient"`
  with at least two colors and `gradientAngle` -180–180.
- Wave planes: `amplitude` 0–0.4, `wavelength` 0.5–4, `waveSpeed` -0.5–0.5.
  Segment only: `span` 30–330. Split is vertical before rotation; band horizontal.
- Streams travel right at rotation 0, down at 90. Rain defaults to 78 degrees.
  Orbs stay fixed: center + offset; body radius is 0.1 frame heights × scale.

`flow` gives moving light volume; dust/bokeh/constellation give nearer detail;
curves/geometry/streams give distinct rhythms; planes give large structural forms.
Confetti is not preferred unless requested. Static objects are optional anchors.
Eco caps animation at 960×540 and targets 24 FPS, with cached sprites/gradients;
slow-hardware fallback is 720×405 at 18 FPS. Do not claim measured TV performance
from packaging checks.

## Required large background form

Every new layered abstract composition has a large background form. Choose its
silhouette randomly from theme-compatible gradient planes (wave, disc, split,
band, segment) or a deliberately large shaded orb. Preserve light and fine
atmosphere around it. Flow, rain, grids, curves, stars and text do not replace
this structural form, however many objects they contain.

The normal builder checks this before publishing: a planes layer needs gradient
fill, opacity at least 0.2 and useful size/placement. Wave/split/band offsets stay
within ±0.35; bands need scale at least 0.65. Disc/segment estimates need at least
12% visible bounding area at 16:9; primary segments need span at least 150 degrees.
An orb can fill this role with scale at least 1.4, opacity at least 0.4 and at least
4% visible body bounding area. Distinct tones are also checked. These conservative
recipe checks reject the demonstrated missing/tiny/offscreen cases; they do not
prove aesthetic quality or cover all animation phases and screen ratios.

On `large_background_shape_required`, add or reposition a qualifying form and
retain supporting light/atmosphere, then rebuild. `largeShapeRequired: false` is
only for an explicit no-figure/minimal request or exact approved-reference replay;
do not use it to bypass a failed ordinary composition. Authoring preview catalogues are
not subject to this delivery check; normal abstract preset delivery is checked too. Choose a form compatible with the four-moving-
layer budget; do not replace several missing visual scales with many thin marks.

## Visibility on the actual TV

A bright gradient can erase screen-blended white details. Keep distinct light
spots and shadow depth; use a contrasting tone and source-over where appropriate
rather than making the entire scene darker or filling it with text. Put key shapes
inside the viewport: offsets around ±0.3 usually keep an orb in view, while an
orb offset [0.55,-0.45] places its center offscreen. For an orb intended as a
visible anchor, retain its body and a useful part of its halo in frame.

Use more of the existing budget when atmosphere is sparse: roughly 40–48 small
particles with scale 1.2–1.7, 16–24 curves with weight 1.8–3 and visible opacity,
or a separate 10–16 bokeh layer can add depth. These are alternatives, not a fixed
recipe. Account for shader-free layer blending and particle fades: nominal opacity
is not final pixel contrast. Strengthen contrast, size and placement before raising
hard budgets; keep at most four moving layers, 64 particles total and eco raster/FPS
caps. Do not sacrifice an existing visual role to add text.

## Foreground effect layer

The foreground surface supports interchangeable `text`, `symbols`, `lightning`
and `flash` effects. Choose from the brief: lively/cyber/energetic scenes may use
falling symbols or brief local light events; quiet velvet scenes may use text
or no foreground effect. Do not soften every scene into ambience. Foreground
accents supplement the complete background and its required large form.

Use `effects: [{"type":"symbols","count":9,"opacity":0.55},
{"type":"lightning","count":2,"period":6,"opacity":0.85}]` as an example,
not a compulsory combination. At most three effects and one of each type. They
share one foreground canvas and the same figure-occlusion pipeline as text.
`occlude` defaults true; false puts that effect in front of the large figures.
The four-moving-layer background budget is separate. Effects use the same eco
raster, clock, visibility suspension and adaptive fallback. Cached glyph atlases,
lightning paths and glow sprites avoid per-frame text rasterization or gradients.

Text opacity defaults do not apply to these accents: symbols usually use opacity
0.55–0.85 and short lightning events 0.85–1 for a lively brief.

Non-text effects accept `colors` (1–3 hex), `opacity` 0.05–1, `speed` 0.05–2,
`scale` 0.4–2, `offset: [x,y]` each ±0.5 and boolean `occlude`. Symbols use 1–14
columns (default 8). Lightning and flash use 1–3 event locations (defaults 1 and 2),
with `period` 4–30 travel seconds (defaults 12 and 8). Lightning chooses a new seeded random
angle for each strike, stable throughout that strike: `angleRange: [-35,35]` by
default (bounds each -180–180). An explicit `rotation` fixes one angle instead;
0 is vertical. Do not provide both. Use a range for ordinary varied accents. Prefer one strike
location with period 10–14 for occasional accents (wall time is period divided
by motion and effect speed); avoid frequent strokes that dominate the frame. Flashes are local glow
bursts; lightning uses brief branching strokes. Text uses all ticker fields
below plus `type: "text"`. Use one `effects` array, or the legacy `ticker`
shorthand for text alone; do not provide both. The builder embeds SB Sans only
when a text effect is used. Serialize final choices in the recipe.

## Optional scrolling text

Use supplied text or an explicitly requested text source when present; do not
silently substitute another source. If neither copy nor source is specified and
text would benefit the composition, write short original thematic copy yourself,
without asking the user to supply it. Match the mood: decorative text need not be
motivational. Do not attribute generated copy to an external author. Text remains
optional; respect an explicit no-text request and do not add it to every scene.
Serialize the chosen words in the existing `ticker.text` field.

Compose a complete background before adding text. A ticker is an extra layer and
does not consume the four moving-background-layer slots. Preserve the background’s
light volume, atmosphere and depth when adding it. Do not simplify a rich scene
to a band, rings and text. Choose an occluding figure to suit the scene; a diagonal
band is not the default. Apply the variation rules above while preserving the
background’s visual richness.

For text, use an `effects` entry with `type: "text"`, or legacy `ticker`: required `text` (1–4000
characters), optional `size` (0.05–0.4 frame heights; default 0.18), `y` (0.05–0.95,
line center; default 0.56), signed `speed` (-0.15–0.15 frame widths per travel second;
negative moves left, default -0.027), `opacity` (0.05–0.8; default 0.07), `color`
(#RRGGBB), `gap` (0.1–2 frame widths; default 0.45), `occlude` (default true).
Use `fontWeight: 600` (default, real SB Sans Display Semibold) for decorative
text; `400` selects Regular. For decorative copy, normally omit size/opacity/speed to use the tuned defaults:
size 0.18, opacity 0.07 and speed -0.027. For a specific brief, roughly size
0.17–0.22, opacity 0.05–0.09 and speed -0.024 to -0.03 work as starting points.
Use higher text opacity only for an explicit request for prominent readable copy;
do not turn a thematic greeting into a headline. Select copy by the rules above.
The selected face is embedded only for text scenes, with verified source/checksum
in assets/fonts/catalog.json (Regular) or semibold.json. Shared plane
geometry masks the line at full strength, so it disappears behind all large
planes even when their visual fill is translucent. Other motifs do not occlude.
Text rasterizes once after font loading into 1024-pixel tiles, at most roughly
8M cached pixels; long lines reduce cache resolution. Motion and adaptive quality apply to text too. In authoring preview, pause also
freezes text. A font failure reports data-font-status=fallback and
omits the line rather than baking the wrong face. Test the file on the target TV.

## Conditional detail

- Read `references/patterns.md` only for more exact primitive behavior;
  `references/velvet.md` for a deeper style discussion. This page is sufficient
  for normal existing-pattern compositions.
- For a literal landscape, read `references/scenes.md`; `--list` lists examples.
- `--preview` is an authoring catalogue/UI, not normal delivery.
- Use `references/delivery.md` for cross-channel/Orion delivery.
- Use `references/development.md` when changing/testing the renderer. New visual
  primitives require actual implementation, not invented recipe fields.

On an edit, recover the JSON from its companion or embedded `script#scene-config`,
change the intended parameters, and build a fresh filename. Runtime adjustments
are temporary; they do not save a recipe. Routine output customization does not
implicitly authorize editing the shared installed renderer.
