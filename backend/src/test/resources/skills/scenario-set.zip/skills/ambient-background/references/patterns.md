# Abstract composition primitives

Assemble a new recipe without a preset. `layers` is an ordered array of independent
primitives, not a list of catalogue entries. Decide what moves, how it moves, and
its silhouette before choosing colors. Thin curves are one possibility; the
renderer also supports filled forms, expanding fields and directional travel.
Use a dominant behavior plus complementary layers, rather than adding every type.

## Recipe

`title` is metadata (1–160 characters), `background` is `#RRGGBB`, `quality` is
`eco` or `balanced`, `motion` is 0–1, `brightness` is 0.25–1, and `seed` is an
integer from 1 to 2147483646. Colors use six-digit hex notation. A preset is
optional; free layers use the abstract compositor automatically. If a preset is
supplied with layers, it must belong to Abstracts. Explicit layers replace all
example layers; they are not appended implicitly.

For a continuous abstract base gradient, add
`backgroundGradient: {"colors":["#182029","#34434b","#1d2935"],"angle":-30}`.
It accepts 2–6 colors and an angle from -180 to 180 (default -30); explicit layers
are required. It overrides the base background fill and is baked only on resize.
The plain background color remains a fallback. This does not itself animate;
combine it with moving layers.

## Common layer parameters

Use one to six layers: at most four moving layers, plus up to two static orb
layers. There may be at most two orb objects in total. Each object has a required `type` and optional parameters:

| Parameter | Meaning |
| --- | --- |
| `style` | One of the styles for its type below |
| `colors` | Array of 1–6 `#RRGGBB` colors; omitted uses the palette |
| `count` | Element count, with budgets below |
| `opacity` | 0–1; independent per layer |
| `speed` | 0.05–3; multiplies continuously integrated global motion |
| `scale` | 0.25–3; visual size, not animation speed |
| `rotation` | Layer orientation in degrees, -180 to 180 |
| `offset` | `[x,y]`, each -1 to 1 in viewport widths/heights; default `[0,0]` |
| `blend` | `screen` (luminous) or `source-over` (ordinary transparency); planes/orbs default to source-over, other types to screen |

`motion=0` freezes all spatial and opacity changes. `speed` changes travel, pulse
rate and tumble together within its layer. Runtime speed edits preserve phase.

## Primitives and budgets

| Type | Styles | Default count | Maximum per layer | Combined count budget |
| --- | --- | --- | --- | --- |
| `flow` | `soft` | 3 | 5 | 6 |
| `particles` | `dust`, `bokeh`, `constellation` | 24 | 48 | 64 |
| `ribbons` | `silk`, `wave`, `aurora` | 18 | 28 | 40 |
| `geometry` | `orbits`, `rings`, `lattice`, `pulse-lattice` | 10 | 18 | 24 |
| `pulses` | `rings`, `bloom`, `rays` | 4 | 8 | 10 |
| `streams` | `trails`, `comets`, `rain` | 28 | 48 | 64 |
| `shapes` | `confetti`, `petals`, `shards` | 24 | 48 | 64 |
| `planes` | `wave`, `split`, `disc`, `band`, `segment` | 1 | 3 | 3 |
| `orbs` | `sun`, `moon`, `planet`, `ringed-planet` | 1 | 2 | 2 |

- `flow`: slowly moving soft cached gradient fields. Broad color/atmosphere.
- `particles`: gently drifting small glows, large translucent bokeh, or a sparse
  connected field. These do not provide one-way travel or tumbling solid forms.
- `ribbons`: evolving harmonic curves; fine silk, smooth waves, or broad light
  threads. Aurora uses three cached luminous bands adapted from the landscape
  renderer; count controls baked stroke density, not per-frame full paths.
  `weight` (0.25–4, default 1) controls line width independently of count.
- `geometry`: rotating orbits, open arcs, or a rotating line lattice.
  `pulse-lattice` uses `count` for the number of columns and sweeps light
  across the intersections. `weight` (0.25–4) controls stroke width.
- `pulses`: expanding rings, breathing soft filled blooms, or radial spokes. Each
  expands and smoothly fades out; no hard on/off flash. `period` is 4–30 travel
  seconds (default 10). Effective wall-clock cycle is `period/(motion*speed)`.
  `spread` is 0–1 (default 0.6): 0 puts centers at the layer origin, 1 scatters them
  across the viewport. `synchrony` is 0–1 (default 0): 0 uses independent seeded
  phases; 1 pulses all centers together. `weight` controls ring/spoke width, and is
  ineffective on the soft `bloom` style.
- `streams`: one-way travel with short tails and no accumulated trail buffer.
  `trails` are light streaks, `comets` add brighter heads, `rain` has shorter tails.
  `rotation=0` travels right, 90 down, -90 up, 180 left. Default orientation is 78
  for `rain` and 0 otherwise. `weight` (0.25–4) controls tail thickness. Wrapped
  paths extend outside the visible viewport to avoid a visible reset.
- `shapes`: filled rectangles (`confetti`), rounded elliptical forms (`petals`),
  or triangular facets (`shards`). They drift, turn and flip edge-on independently.
  `spin` is -3–3 (default 0.7); 0 keeps orientation/flip fixed while travel
  continues. `rotation` turns the whole drift direction: 0 is downward. Opacity,
  size, colors and `source-over` can make forms substantial rather than glows.

## Static celestial anchors

`orbs` supports `sun`, `moon`, `planet` and `ringed-planet`. These are independent
static image layers, not whole landscape scenes. Shading, halo, planet bands,
moon detail and rings are baked into small transparent canvases once. At most two
objects are allowed; fallback keeps them while reducing moving effects.

Position is the viewport center plus `offset`; `scale=1` gives a body radius of
0.1 viewport heights. Rotation sets texture/ring orientation. Colors choose the
body and light/shading palette, and opacity blends it into the scene. Motion and
speed do not move orbs: they stay fixed while surrounding light/atmosphere moves.
A layer with count 2 places two bodies horizontally around that center; use two
count-1 layers for independent sizes/positions. Other type-specific fields such
as spin, period and waveSpeed are unsupported for orbs. Legacy top-level
`celestial`/`atmosphere` fields belong to landscapes; with abstract layers use
orbs, streams/rain or ribbons/aurora explicitly.

## Large background geometry

`planes` makes one to three large filled background forms. This is a structural
layer, not scattered small shapes. Usually put it before flow, curves or other
accents. Choose colors close to the background and restrained opacity; a geometry
edge can stay crisp while the color difference stays quiet. Default opacity is
0.45 and default blend is `source-over`, so darker tonal shapes work too.

Planes support `fill: "solid"` (legacy default) or `fill: "gradient"`.
A gradient fill needs at least two colors. `gradientAngle` is -180 to 180 degrees
(default -35) and is valid only with gradient fill. Colors become evenly spaced
stops instead of separate per-element solid colors. The gradient is cached during
layer compilation and reused; fill geometry still moves at the eco raster budget.
For the preferred velvet direction, use gradient fills and neighboring tones.

- `wave` (default): a filled half-plane with a slowly evolving sinusoidal boundary.
  It starts with a roughly vertical edge; rotation inclines the whole boundary.
  `amplitude` is 0–0.4 viewport heights (default 0.13), `wavelength` is 0.5–4
  viewport heights (default 2). Scale multiplies both. `waveSpeed` is -0.5–0.5
  radians per travel second (default 0.09); its sign changes phase direction.
  Set waveSpeed to 0 for a fixed curve; drift/spin can still move the plane.
  Amplitude 0 produces a straight boundary. The curve uses at most 256 segments;
  sample positions are cached. Choose broad, restrained waves for a quiet field.
- `segment`: a circular segment closed by a straight chord, not a pie wedge.
  `span` (30–330 degrees, default 180) determines the arc. At scale 1 its radius is
  0.62 viewport heights; a semicircular segment occupies roughly a third of a
  landscape frame. `rotation` orients it and `offset` places it partly off-screen.
- `disc`: a large filled circle, often clipped by a screen edge. Same radius and
  scale as segment, but no `span` parameter.
- `split`: a filled half-plane; at `offset=[0,0]`, `drift=0` its boundary divides
  the viewport in half. The initial boundary is vertical; `rotation` tilts it.
  `scale` has no effect because the plane extends beyond the frame. Use the
  background as one color, the half-plane as the other. Optional
  `edgePattern: "stitches"` draws slow-moving dashes and dots along the boundary.
- `band`: a wide strip extending across the frame, initially horizontal. Its width
  is 0.34 viewport heights times scale; rotation sets its incline.

Planes have slow continuous rotation: `spin` is -3–3 (default 0.5), in units of
0.008 radians per travel second. `drift` is 0–2 (default 1); it controls bounded
translation, with amplitudes of 3.5% viewport width and 4.5% height per unit. Set
spin and drift to 0 independently to stop either behavior. A wave boundary has
its own waveSpeed; set all three to 0 to hold its geometry fixed. Global motion and
layer speed multiply both. There is no wrap, respawn, opacity flash, blur filter
or per-frame gradient. The oversized half-plane/band remains filled as it turns.
Colors, opacity, placement, scale, orientation and speed remain independent.

For example, a quiet wave boundary is valid with no other layer:

```json
{"background":"#281b2a","layers":[{"type":"planes","style":"wave","colors":["#503447"],"amplitude":0.13,"wavelength":2,"rotation":-24,"opacity":0.35,"spin":0.4,"drift":0.5}]}
```

Type-specific parameters are rejected on incompatible types. Unsupported types,
styles and over-budget recipes fail explicitly. In a light scene, dark ink-like
forms need `source-over`; screen blending only lightens a background. Do not
represent a change of motion by changing only colors. When revising an existing
scene, change the requested parameters while preserving its composition.

## Syntax example

This shows valid independent layers, not a mandatory starting recipe:

```json
{"background":"#111824","motion":0.65,"layers":[{"type":"pulses","style":"bloom","count":2,"colors":["#7e9fb0"],"period":16,"opacity":0.35},{"type":"shapes","style":"shards","count":14,"colors":["#b0b6cd","#769ca7"],"spin":0.5,"scale":1.3,"opacity":0.5}]}
```

The optional catalogue has four abstract example families with twelve
recipes. Use `compose.py --list` for their IDs; it lists examples, not every
primitive. Landscape examples and legacy fields are in `scenes.md`.

## Runtime and diagnostics

`eco` caps the moving canvas at 960×540 and targets 24 FPS. Cached sprites are
built before animation. `balanced` raises raster resolution to 1280×720; explicit
counts stay the same. Slow-hardware fallback reduces resolution to 720×405, rate
to 18 FPS and element counts. Large overlapping translucent fields can still cost
GPU time; use their count/size deliberately. No gradient or blur filter is created
per frame. Particle connections are a sparse linear pass, curves have at most 32
segments, and radial pulses have 12 spokes each. Shape textures are cached small
canvases; streams use short cached tails, not full-frame history.

Pause and hiding cancel frame scheduling. D exposes the optional browser report;
DOM metadata is `document.documentElement.dataset.ambientStats`, including actual
layer counts. Draw timings measure CPU command submission, not GPU/compositing.
Desktop results are not physical-TV acceptance. Keep test outputs outside the
installed bundle.
