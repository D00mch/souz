# Velvet: gradients, light and layered motion

This is the preferred abstract direction for this bundle unless the user asks
otherwise. The accepted early reference combined moving soft light fields,
translucent round bokeh and flowing wave lines. Preserve that visible richness
when adding large background geometry. A gradient and a couple of broad planes
are a foundation, not the whole intended composition.

## Composition and material

- Keep a continuous tonal gradient across the frame and inside large background
  figures. Include one large structural form as required in SKILL.md; leave the moving-layer
  budget for light and atmosphere. Large forms support the composition rather
  than replace its luminous layers.
- Give the frame visible moving light volume: broad softly glowing fields with
  highlights and shadow depth, not a uniform dim wash. `flow` or restrained
  `pulses/bloom` can do this.
- Add a readable flowing structure or atmosphere: a group of silk/wave lines,
  luminous auroral ribbons, or a rain field when it fits the association. These
  should remain visible at TV viewing distance, not vanish as hairline details.
- Round translucent bokeh is welcome: it adds depth and drifting light at another
  scale. It is different from tumbling polygon confetti, which the user disliked.
  Do not remove bokeh/circles under a general ban on small decorative objects.
- Separate tones by role. Light accents need enough value above the background to
  read as illumination. Low contrast means coherent, gentle relationships, not
  making every layer almost invisible. Related hues may still include light,
  midtone and deep colors.
- The palette can be warm, cool, earthy or muted luminous. The material and rhythm
  matter more than wine colors. Associations should change placement, silhouette
  and light rhythm as well as palette. Do not force a rigid keyword/template map.
- Prefer unhurried but observable travel, deformation and changing light over
  static-looking fills. Avoid flashing, abrupt respawns and busy tumbling.

A useful composition has a base, luminous volume, a wave/atmospheric rhythm and
nearer translucent detail. These are visual roles, not a mandatory fixed recipe:
a layer may serve more than one role. Choose an intentional hierarchy and keep
quiet areas, while retaining clearly visible activity in more than one depth.

## Reusing the landscape library's visual vocabulary

Abstract backgrounds can reuse these elements without a horizon or scenery:

- `ribbons`, `style: "aurora"`: cached luminous bands adapted from the landscape
  aurora, gently drifting and deforming. Layer colors set their light palette.
- `streams`, `style: "rain"`: a directional rain field. Rotation controls its
  direction; choose moderate count, opacity and thickness.
- `orbs`: static sun, moon, planet or ringed planet, with cached shading/glow.
  Use a deliberate position and size as an anchor when the associations call for
  it. A static object complements moving light/atmosphere; it does not replace it.
- `particles`, `style: "bokeh"`: large transparent light circles, as in the
  accepted rich reference. These remain useful alongside large background forms.

There are at most four moving layers. Up to two extra layers may be static orbs,
with at most two orb objects total. Use that separation to preserve richness
without increasing the moving-layer budget. Not every composition needs every
element, and a planet/sun need not appear by default.

## Concrete renderer controls

Set `backgroundGradient` with 2–6 related colors and an angle. For tonal planes,
use `fill: "gradient"` with at least two colors. These gradients are compiled on
resize and reused. Plain fallback background color can remain in the recipe.

Use independent colors, opacity, scale, placement and motion per layer. For curves,
`weight` changes thickness without multiplying count. For broad wave planes,
avoid tight repeated scallops. Let major structure move gently while light and
nearer elements have an observable complementary rhythm. Read `patterns.md` for
supported fields and exact limits. Do not invent a `profile` configuration key.

## Decorative text and successive compositions

The text is added to the complete scene. Preserve the luminous and atmospheric
roles that make the background work without it. A large plane helps depth but
must leave room for distinct light spots and nearer details. Avoid repeatedly
using a diagonal band plus orbit/ring geometry when only the theme changes;
use the controlled random selection rules in [SKILL.md](../SKILL.md#variation-for-new-compositions).
Keep this material preference while varying silhouettes, spatial hierarchies and
movement. The approved furnace combination is another available composition,
not a required template for future scenes.

## TV hierarchy

Decorative text normally uses opacity around 0.07; the background’s light and
atmosphere carry the frame. On a bright background, make curves and particles
larger or more contrasting rather than whitening them with screen blend. Keep
anchors inside the viewport and distribute detail through the frame. Use the
available element counts before increasing renderer budgets. Nominal layer
opacity is reduced again by baked sprite gradients and animation fades.

## Visual review

Compare against the accepted richness: can you see light spots/volume, flowing or
atmospheric motion, and distinct depth/detail in addition to the large base shapes?
If the scene is only attractive empty backing, revise the composition. This is
an aesthetic check, not a physical-TV performance result. Keep the eco raster and
scheduling limits and report actual checks only.
