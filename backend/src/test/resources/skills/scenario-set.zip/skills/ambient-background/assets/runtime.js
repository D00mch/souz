(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const base = $('still'), moving = $('motion');
  const b = base.getContext('2d', {alpha: false}), c = moving.getContext('2d');
  if (!b || !c) { $('notice').textContent = 'Для этого пейзажа нужен браузер с Canvas 2D'; $('notice').classList.add('visible'); return; }
  const catalog=JSON.parse($('scene-library').textContent);
  const presets=catalog.presets,variants=catalog.variants,defaultPreset=catalog.defaultPreset||'flow';
  const profiles = {
    eco:{width:960,height:540,fps:24,ripples:190,particles:18},
    balanced:{width:1280,height:720,fps:24,ripples:300,particles:28},
    minimal:{width:720,height:405,fps:18,ripples:110,particles:12}
  };
  const source = JSON.parse($('scene-config').textContent);
  const remembered={abstract:defaultPreset,landscape:'sunset'};
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  let abstractEngine=null,tickerEngine=null,foregroundEngine=null;
  let tickerFontReady=false;
  let cfg, palette, profile, quality, random, BW=0, BH=0, W=0, H=0, hy=0;
  let waves=[],ripples=[],particles=[],twinkles=[],haze=null,cloud=null,spark=null,meteor=null,nebula=null,aurora=null;
  let raf=0, nextDue=0, previous=0, clock=0, travel=0, frames=0, staticBuilds=0;
  let paused=document.documentElement.dataset.mode==='scene'?false:reduced.matches, uiTimer=0, noticeTimer=0, lastPointer=0;
  let samples=[], intervals=[], lastReport=0, lastPaint=0, overloaded=0, adaptive=false;
  let stats={};
  const clone = value => JSON.parse(JSON.stringify(value));
  function rng(seed) { let value=seed; return () => {value=value*16807%2147483647; return (value-1)/2147483646;}; }
  function rgba(hex, alpha) {return `rgba(${parseInt(hex.slice(1,3),16)},${parseInt(hex.slice(3,5),16)},${parseInt(hex.slice(5,7),16)},${alpha})`;}
  function gradient(context,x0,y0,x1,y1,stops) {const g=context.createLinearGradient(x0,y0,x1,y1);for (const [offset,color] of stops) g.addColorStop(offset,color);return g;}
  function radial(context,x,y,r,color,alpha) {const g=context.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,rgba(color,alpha));g.addColorStop(.4,rgba(color,alpha*.28));g.addColorStop(1,rgba(color,0));context.fillStyle=g;context.fillRect(x-r,y-r,r*2,r*2);}
  function layer(width,height) {const canvas=document.createElement('canvas');canvas.width=Math.ceil(width);canvas.height=Math.ceil(height);return canvas;}
  function polygon(context,points,color) {context.beginPath();points.forEach(([x,y],i)=>i?context.lineTo(x,y):context.moveTo(x,y));context.closePath();context.fillStyle=color;context.fill();}
  const escapeLabel=value=>String(value).replace(/[&<>"]/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[ch]));
  function sceneKeys(category){return Object.keys(presets).filter(key=>presets[key].category===category);}
  function optionsFor(preset){return source.layers&&preset===(source.preset||defaultPreset)?[{id:'custom',label:'Авторская сборка',recipe:{}},...variants[preset]]:variants[preset];}
  function configure(preset,initial) {
    const input=initial||{},options=optionsFor(preset),wanted=input.layers?'custom':input.variant,variant=options.find(v=>v.id===wanted)||options.find(v=>v.id===input.variant)||options[0];
    const defaults=clone(presets[preset]),recipe=variant.recipe;
    cfg=Object.assign(defaults,{preset,seed:29,motion:.5,brightness:1,quality:'eco'},recipe,input);
    cfg.variant=variant.id;
    cfg.palette=Object.assign({},presets[preset].palette,recipe.palette||{},input.palette||{});
    if(!input.title)cfg.title=presets[preset].title+' · '+variant.label;
    palette=cfg.palette;quality=cfg.quality;profile=profiles[quality];adaptive=false;overloaded=0;
    const category=presets[preset].category;remembered[category]=preset;$('category').value=category;
    $('scene').innerHTML=sceneKeys(category).map(key=>'<option value="'+key+'">'+escapeLabel(presets[key].label)+'</option>').join('');
    $('scene').value=preset;
    $('variant').innerHTML=options.map(v=>'<option value="'+v.id+'">'+escapeLabel(v.label)+'</option>').join('');
    $('variant').value=variant.id;
    $('strength').value=Math.round(cfg.motion*100);$('brightness').value=Math.round(cfg.brightness*100);$('quality').value=quality;
    $('dim').style.opacity=1-cfg.brightness;moving.setAttribute('aria-label',cfg.title);
    document.title=cfg.title;document.documentElement.dataset.preset=preset;document.documentElement.dataset.variant=variant.id;
    samples=[];intervals=[];lastReport=0;lastPaint=0;clock=0;travel=0;resize();
  }
  function mountains(context,y,amplitude,color,phase) {
    const points=[[-2,y+8]];
    for(let i=0;i<=90;i++) {const u=i/90,edge=.25+Math.pow(Math.abs(u-.58)*1.7,1.1);const a=.7+Math.sin(u*10+phase)*.31+Math.sin(u*23+phase)*.14+(cfg.landscape==='jungle'?Math.sin(u*137+phase)*.045:0);points.push([u*BW,y-a*amplitude*edge]);}
    points.push([BW+2,y+12]);polygon(context,points,color);
  }
  function city(context,y) {
    // Windows are baked once; no independent DOM nodes or per-frame building draw.
    for(let i=0;i<45;i++) {
      const x=i*BW/44-BW*.02,width=BW*(.012+random()*.018),height=BH*(.018+random()*.11);
      context.fillStyle=palette.mountain[i%3];context.fillRect(x,y-height,width,height+2);
      if(i%7===0){context.fillRect(x+width*.48,y-height-BH*.017,1,BH*.025);}
      const cell=Math.max(3,BW/260);
      for(let wx=x+3;wx<x+width-2;wx+=cell*1.7) for(let wy=y-height+5;wy<y-3;wy+=cell*2.1) {
        if(random()<.43){context.fillStyle=rgba(i%4===0?palette.accent:palette.window,.3+random()*.5);context.fillRect(wx,wy,Math.max(1,cell*.55),Math.max(1,cell*.65));}
      }
      if(cfg.water) {
        for(let row=0;row<18;row++) {
          const z=row/18,yy=y+z*z*(BH-y),ww=width*(.25+random()*.45+z*.6);
          context.fillStyle=rgba(i%4===0?palette.accent:palette.window,.11*Math.pow(1-z,1.8));
          context.fillRect(x+width*.5-ww*.5+(random()-.5)*width*.3,yy,ww,Math.max(.5,BH*.001));
        }
      }
    }
  }
  function icebergs(context,y) {
    mountains(context,y,BH*.12,palette.mountain[0],1.7);
    for(const [x,scale] of [[.04,1.05],[.17,.62],[.79,.55],[.9,.95]]) {
      const X=x*BW,ww=BW*.11*scale,hh=BH*.16*scale;
      polygon(context,[[X-ww*.6,y],[X-ww*.3,y-hh*.6],[X,y-hh],[X+ww*.29,y-hh*.82],[X+ww*.7,y]],palette.mountain[1]);
      polygon(context,[[X,y-hh],[X+ww*.29,y-hh*.82],[X+ww*.7,y],[X+ww*.08,y-hh*.12]],palette.mountain[2]);
      polygon(context,[[X-ww*.3,y-hh*.6],[X,y-hh],[X-ww*.08,y-hh*.07],[X-ww*.6,y]],palette.mountain[0]);
    }
    if(cfg.water) for(let i=0;i<16;i++) {
      const z=random(),x=random()*BW,yy=y+(BH-y)*(.18+z*.72),ww=(4+z*30)*BW/1280;
      polygon(context,[[x-ww,yy],[x-ww*.4,yy-ww*.17],[x+ww*.6,yy-ww*.1],[x+ww,yy+2]],rgba(palette.disc,.15+z*.18));
    }
  }
  function forest(context,y) {
    mountains(context,y,BH*.105,palette.mountain[0],1.2);
    mountains(context,y+2,BH*.1,palette.mountain[1],3.6);
    for(let row=0;row<2;row++)for(let i=0;i<44;i++) {
      const x=(i+random()*.7)*BW/43,height=BH*(.025+random()*.05)*(1+row*.35),width=height*.36;
      const yy=y-2+row*3;
      context.fillStyle=palette.mountain[row+1];context.fillRect(x-width*.05,yy-height*.4,width*.1,height*.45);
      for(let tier=0;tier<4;tier++) {const t=tier/4,ww=width*(.4+t*.6),top=yy-height+height*t*.7;polygon(context,[[x,top],[x-ww,top+height*.38],[x+ww,top+height*.38]],palette.mountain[row+1]);}
    }
  }
  function dunes(context,y) {
    for(let i=0;i<(cfg.water?1:3);i++) {
      const yy=y+i*BH*.15;
      context.beginPath();context.moveTo(-BW*.05,yy+BH*.02);
      context.bezierCurveTo(BW*.16,yy-BH*.15,BW*.32,yy-BH*.12,BW*.54,yy-BH*.01);
      context.bezierCurveTo(BW*.7,yy+BH*.045,BW*.85,yy-BH*.13,BW*1.05,yy-BH*.12);
      context.lineTo(BW*1.05,cfg.water?y+5:BH);context.lineTo(-BW*.05,cfg.water?y+5:BH);context.closePath();context.fillStyle=palette.mountain[i];context.fill();
      context.beginPath();context.moveTo(-BW*.05,yy+BH*.02);context.bezierCurveTo(BW*.16,yy-BH*.15,BW*.32,yy-BH*.12,BW*.54,yy-BH*.01);context.bezierCurveTo(BW*.7,yy+BH*.045,BW*.85,yy-BH*.13,BW*1.05,yy-BH*.12);context.strokeStyle=rgba(palette.light,.15);context.lineWidth=Math.max(.7,BH/800);context.stroke();
    }
  }
  function planet(context) {
    const x=BW*.66,y=BH*.43,r=Math.min(BW,BH)*.145;
    radial(context,x,y,r*2,palette.accent,.13);
    function ring(front) {
      context.save();context.translate(x,y);context.rotate(-.27);
      for(let j=0;j<3;j++){context.beginPath();context.ellipse(0,0,r*(1.95+j*.1),r*(.59+j*.035),0,0,front?Math.PI:Math.PI*2);context.strokeStyle=rgba(j===1?palette.disc:palette.light,j===1?.42:.2);context.lineWidth=r*(j===1?.105:.045);context.stroke();}
      context.restore();
    }
    if(cfg.celestial==='ringed-planet')ring(false);
    context.save();context.beginPath();context.arc(x,y,r,0,Math.PI*2);context.clip();
    context.fillStyle=gradient(context,x-r,y-r,x+r,y+r,[[0,palette.disc],[.5,palette.accent],[1,palette.sky[0]]]);context.fillRect(x-r,y-r,r*2,r*2);
    for(let j=0;j<9;j++){const yy=y-r+j*r*.23;context.strokeStyle=rgba(palette.light,j%2?.12:.055);context.lineWidth=r*(.04+j*.006);context.beginPath();context.moveTo(x-r,yy);context.bezierCurveTo(x-r*.35,yy+r*.16,x+r*.4,yy-r*.05,x+r,yy+r*.12);context.stroke();}
    context.restore();
    if(cfg.celestial==='ringed-planet')ring(true);
    context.fillStyle=rgba(palette.disc,.7);context.beginPath();context.arc(BW*.22,BH*.24,Math.min(BW,BH)*.017,0,Math.PI*2);context.fill();
  }
  function bakeBackground() {
    staticBuilds++;
    const y=BH*cfg.horizon,skyEnd=cfg.landscape==='space'?BH:y,sx=BW*.585,sy=BH*.423,sr=Math.min(BW,BH)*(cfg.celestial==='moon'?.039:.067);
    b.fillStyle=gradient(b,0,0,0,skyEnd,[[0,palette.sky[0]],[.4,palette.sky[1]],[.78,palette.sky[2]],[1,palette.sky[3]]]);b.fillRect(0,0,BW,BH);
    if(cfg.landscape==='space'){radial(b,BW*.23,BH*.45,BH*.5,palette.accent,.27);radial(b,BW*.65,BH*.68,BH*.5,palette.sky[2],.3);}
    if(cfg.celestial==='planet'||cfg.celestial==='ringed-planet')planet(b);
    else if(cfg.celestial!=='none') {
      radial(b,sx,sy,BH*.31,palette.light,.21);radial(b,sx,sy,BH*.15,palette.light,.17);
      b.fillStyle=palette.disc;b.beginPath();b.arc(sx,sy,sr,0,Math.PI*2);b.fill();
      if(cfg.celestial==='sun'){b.fillStyle=gradient(b,0,sy-sr,0,sy+sr,[[0,rgba(palette.sky[3],0)],[1,rgba(palette.sky[3],.5)]]);b.fill();}
    }
    if(cfg.celestial==='moon'||cfg.atmosphere==='stars'||cfg.atmosphere==='meteors'||cfg.landscape==='space') for(let i=0;i<(cfg.landscape==='space'?180:80);i++) {b.fillStyle=rgba(palette.disc,.12+random()*.35);b.fillRect(random()*BW,random()*BH*(cfg.landscape==='space'?.95:.36),random()<.15?1.5:.8,.8);}
    // Atmospheric streaks are static; tiny sprites carry the moving haze.
    b.lineCap='round';
    for(let i=0;i<16;i++) {const x=random()*BW,yy=BH*(.1+random()*.36),len=BW*(.08+random()*.25);b.strokeStyle=rgba(palette.sky[3],.025);b.lineWidth=BH*(.003+random()*.008);b.beginPath();b.moveTo(x,yy);b.bezierCurveTo(x+len*.3,yy-3,x+len*.7,yy+4,x+len,yy+1);b.stroke();}
    if(cfg.water) {
      b.fillStyle=gradient(b,0,y,0,BH,[[0,palette.water[0]],[1,palette.water[1]]]);b.fillRect(0,y,BW,BH-y);
      for(let row=0;row<85;row++) {const z=row/85,width=BW*(.025+z*.2),yy=y+z*(BH-y),alpha=.22*Math.pow(1-z,1.5);b.fillStyle=gradient(b,sx-width,yy,sx+width,yy,[[0,rgba(palette.light,0)],[.5,rgba(palette.light,alpha)],[1,rgba(palette.light,0)]]);b.fillRect(sx-width,yy,width*2,(BH-y)/85+.5);}
    } else if(cfg.landscape!=='space') {b.fillStyle=palette.water[1];b.fillRect(0,y,BW,BH-y);}
    if(cfg.landscape==='space'){}
    else if(cfg.landscape==='forest')forest(b,y);
    else if(cfg.landscape==='dunes')dunes(b,y);
    else if(cfg.landscape==='icebergs') icebergs(b,y);
    else if(cfg.landscape==='city') {mountains(b,y,BH*.035,palette.mountain[0],2);city(b,y);}
    else {for(let i=0;i<3;i++)mountains(b,y+i*2,BH*(cfg.landscape==='jungle'?.15:.095)*(1+i*.23),palette.mountain[i],1+i*1.9);}
    // Small gradient vignette, baked only on resize or scene change.
    const v=b.createRadialGradient(BW*.55,BH*.43,BH*.2,BW*.5,BH*.5,Math.max(BW,BH)*.72);v.addColorStop(0,'rgba(8,16,31,0)');v.addColorStop(1,'rgba(8,16,31,.3)');b.fillStyle=v;b.fillRect(0,0,BW,BH);
  }
  function makeForeground() {
    const parts=[];const path=(d,color)=>parts.push(`<path d="${d}" fill="${color}"/>`);
    if(cfg.foreground==='reeds') {
      path(`M0 ${BH}V${BH*.89}Q${BW*.04} ${BH*.93} ${BW*.18} ${BH}Z`,palette.ground);
      path(`M${BW} ${BH}V${BH*.92}Q${BW*.95} ${BH*.96} ${BW*.88} ${BH}Z`,palette.ground);
      for(let i=0;i<55;i++){const side=i%2===0,x=side?random()*BW*.11:BW-random()*BW*.08,len=BH*(.012+random()*.06),tip=x+(random()-.5)*len*.6;parts.push(`<path d="M${x.toFixed(1)} ${BH}Q${x.toFixed(1)} ${(BH-len*.55).toFixed(1)} ${tip.toFixed(1)} ${(BH-len).toFixed(1)}" fill="none" stroke="${palette.foliage}" stroke-width="${Math.max(.7,BH/700)}"/>`);}
    } else if(cfg.foreground==='ice') {
      path(`M0 ${BH}V${BH*.9}L${BW*.05} ${BH*.925}L${BW*.1} ${BH*.97}L${BW*.24} ${BH}Z`,palette.ground);
      path(`M0 ${BH*.9}L${BW*.05} ${BH*.925}L${BW*.1} ${BH*.97}L${BW*.07} ${BH*.96}Z`,palette.foliage);
      path(`M${BW} ${BH}V${BH*.93}L${BW*.96} ${BH*.94}L${BW*.83} ${BH}Z`,palette.ground);
    } else if(cfg.foreground==='pines') {
      path(`M0 ${BH}V${BH*.9}Q${BW*.1} ${BH*.95} ${BW*.23} ${BH}Z`,palette.ground);
      path(`M${BW} ${BH}V${BH*.92}Q${BW*.92} ${BH*.97} ${BW*.8} ${BH}Z`,palette.ground);
      for(let i=0;i<10;i++) {
        const side=i%2===0,x=side?BW*(.012+random()*.085):BW*(.925+random()*.07),height=BH*(.23+random()*.34),width=height*(.15+random()*.04),yy=BH+height*.07;
        path(`M${x-width*.055} ${BH}V${yy-height}H${x+width*.055}V${BH}Z`,palette.ground);
        for(let tier=0;tier<6;tier++){const t=tier/6,ww=width*(.32+t*.68),top=yy-height+height*t*.71;path(`M${x} ${top}L${x-ww} ${top+height*.3}Q${x} ${top+height*.24} ${x+ww} ${top+height*.3}Z`,i<4?palette.foliage:palette.ground);}
      }
    } else if(cfg.foreground==='cacti') {
      path(`M0 ${BH}V${BH*.95}Q${BW*.22} ${BH*.9} ${BW*.37} ${BH}Z`,palette.ground);
      for(const [u,height]of [[.09,.21],[.92,.16],[.965,.11]]) {
        const x=BW*u,y=BH*.985,hh=BH*height,ww=hh*.16,stroke=hh*.105;
        parts.push(`<path d="M${x} ${y}V${y-hh}M${x} ${y-hh*.45}H${x-ww}Q${x-ww*1.3} ${y-hh*.45} ${x-ww*1.3} ${y-hh*.57}V${y-hh*.75}M${x} ${y-hh*.6}H${x+ww}Q${x+ww*1.3} ${y-hh*.6} ${x+ww*1.3} ${y-hh*.72}V${y-hh*.85}" fill="none" stroke="${palette.foliage}" stroke-width="${stroke}" stroke-linecap="round" stroke-linejoin="round"/>`);
      }
    } else if(cfg.foreground==='tropical') {
      path(`M0 ${BH}V${BH*.82}Q${BW*.05} ${BH*.91} ${BW*.22} ${BH}Z`,palette.ground);
      path(`M${BW} ${BH}V${BH*.86}Q${BW*.92} ${BH*.94} ${BW*.8} ${BH}Z`,palette.ground);
      for(const [side,scale] of [[0,1],[1,.85]]) {
        const x=side?BW*.94:BW*.055,y=BH*.43,tip=x+(side?-1:1)*BW*.018;
        path(`M${x-BW*.008} ${BH}Q${x-BW*.028} ${BH*.65} ${tip} ${y}L${tip+BW*.004} ${y}Q${x-BW*.008} ${BH*.7} ${x+BW*.013} ${BH}Z`,palette.ground);
        for(let leaf=0;leaf<9;leaf++) {
          const angle=-2.9+leaf*.38,reach=BH*.23*scale,ex=tip+Math.cos(angle)*reach,ey=y+Math.sin(angle)*reach*.33+BH*.027;
          path(`M${tip} ${y}Q${tip+(ex-tip)*.55} ${y-BH*.05} ${ex} ${ey}Q${tip+(ex-tip)*.48} ${y+BH*.025} ${tip} ${y}Z`,palette.foliage);
        }
      }
      // Hanging foliage and bank plants are baked vector shapes, with no frame cost.
      for(let i=0;i<20;i++) {
        const side=i%2===0,edge=side?0:BW,dir=side?1:-1;
        const y=BH*(i<10?random()*.19:.73+random()*.27),reach=BW*(.025+random()*.07),ex=edge+dir*reach,ey=y+BH*(.025+random()*.045);
        path(`M${edge} ${y}Q${ex} ${y-BH*.016} ${ex} ${ey}Q${edge+dir*reach*.25} ${ey+BH*.016} ${edge} ${y}Z`,i%3?palette.ground:palette.foliage);
      }
      for(let i=0;i<12;i++) {const side=i%2===0,x=side?BW*.025:BW*.98,y=BH*(.72+random()*.32),ex=x+(side?1:-1)*BW*(.025+random()*.065),ey=y-BH*(.015+random()*.07);path(`M${x} ${y}Q${ex} ${y} ${ex} ${ey}Q${x} ${ey} ${x} ${y}Z`,palette.foliage);}
    }
    $('foreground').setAttribute('viewBox',`0 0 ${BW} ${BH}`);$('foreground').innerHTML=parts.join('');
  }
  function bakeSprites() {
    spark=layer(24,24);radial(spark.getContext('2d'),12,12,12,palette.light,.85);
    haze=layer(256,64);const hc=haze.getContext('2d');hc.scale(4,1);radial(hc,32,32,32,palette.sky[3],.2);
    cloud=layer(384,80);const cc=cloud.getContext('2d');cc.scale(4,1);
    radial(cc,24,40,24,palette.sky[3],.20);radial(cc,47,35,27,palette.sky[3],.22);radial(cc,71,43,23,palette.sky[3],.18);
    meteor=layer(128,16);const mc=meteor.getContext('2d');
    mc.fillStyle=gradient(mc,0,0,128,0,[[0,rgba(palette.light,0)],[.85,rgba(palette.light,.25)],[1,rgba(palette.light,.85)]]);mc.fillRect(0,7,126,1.2);radial(mc,123,8,5,palette.light,.65);
    nebula=null;
    if(cfg.landscape==='space'){nebula=layer(W,H);const nc=nebula.getContext('2d');nc.save();nc.translate(W*.45,H*.5);nc.rotate(-.32);nc.scale(2.1,.6);radial(nc,0,0,H*.4,palette.accent,.25);radial(nc,H*.16,H*.13,H*.28,palette.light,.12);nc.restore();}
    waves=[];
    for(let j=0;j<3;j++) {
      const strip=layer(W*2,24),context=strip.getContext('2d'),points=[];
      for(let k=0;k<=100;k++){const x=k*strip.width/100,yy=6+Math.sin(k/100*Math.PI*8+j)*2+Math.sin(k/100*Math.PI*18+j)*.6;points.push([x,yy]);}
      context.beginPath();points.forEach(([x,y],i)=>i?context.lineTo(x,y):context.moveTo(x,y));context.lineTo(strip.width,24);context.lineTo(0,24);context.closePath();context.fillStyle=gradient(context,0,3,0,24,[[0,rgba(palette.water[1],.3)],[1,rgba(palette.water[1],0)]]);context.fill();
      context.beginPath();points.forEach(([x,y],i)=>i?context.lineTo(x,y):context.moveTo(x,y));context.strokeStyle=rgba(palette.light,.18);context.lineWidth=.8;context.stroke();waves.push(strip);
    }
    aurora=null;
    if(cfg.aurora) {
      aurora=[];
      for(let band=0;band<3;band++) {
        const ribbon=layer(W,Math.ceil(H*.38)),ac=ribbon.getContext('2d');
        for(let i=0;i<22;i++) {ac.beginPath();for(let k=0;k<=30;k++){const x=k*W/30,y=H*(.08+band*.026)+Math.sin(k*.17+band)*H*.038+i*H*.0017;if(k)ac.lineTo(x,y);else ac.moveTo(x,y);}ac.strokeStyle=rgba(band===1?palette.light:palette.accent,(1-i/22)*.025);ac.lineWidth=H*.009;ac.stroke();}
        aurora.push(ribbon);
      }
    }
  }

  function resize() {
    const vw=Math.max(1,innerWidth),vh=Math.max(1,innerHeight);
    // Pixel budgets are independent of physical screen resolution and devicePixelRatio.
    const s=Math.min(1,1280/vw,720/vh),m=Math.min(1,profile.width/vw,profile.height/vh);
    BW=base.width=Math.max(1,Math.round(vw*s));BH=base.height=Math.max(1,Math.round(vh*s));
    W=moving.width=Math.max(1,Math.round(vw*m));H=moving.height=Math.max(1,Math.round(vh*m));hy=H*cfg.horizon;
    abstractEngine=null;tickerEngine=null;foregroundEngine=null;
    if(cfg.layers&&cfg.layers.length){
      staticBuilds++;b.fillStyle=cfg.background||palette.sky[0];
      if(cfg.backgroundGradient){
        const g=cfg.backgroundGradient,a=(g.angle===undefined?-30:g.angle)*Math.PI/180;
        const length=Math.abs(BW*Math.cos(a))+Math.abs(BH*Math.sin(a));
        const gradient=b.createLinearGradient(BW/2-Math.cos(a)*length/2,BH/2-Math.sin(a)*length/2,BW/2+Math.cos(a)*length/2,BH/2+Math.sin(a)*length/2);
        g.colors.forEach((color,i)=>gradient.addColorStop(i/(g.colors.length-1),color));b.fillStyle=gradient;
      }
      b.fillRect(0,0,BW,BH);$('foreground').innerHTML='';
      abstractEngine=AmbientPatterns.create({width:W,height:H,context:c,palette,seed:cfg.seed,layers:cfg.layers,density:profile.particles/18});
      const effects=cfg.effects||(cfg.ticker?[{type:'text',...cfg.ticker}]:[]);
      if(effects.length)foregroundEngine=AmbientForeground.create({width:W,height:H,seed:cfg.seed,palette,effects,density:profile.particles/18,makeText:spec=>{
        if(!tickerFontReady)return null;
        return tickerEngine=makeTicker(spec);
      }});
      samples=[];intervals=[];lastPaint=0;paint();report();return;
    }
    random=rng(cfg.seed);bakeBackground();makeForeground();bakeSprites();
    ripples=Array.from({length:profile.ripples},()=>({x:random(),z:random(),phase:random()*Math.PI*2,len:.4+random(),light:random(),shade:random()<.5}));
    particles=Array.from({length:profile.particles},()=>({x:random(),y:random(),phase:random()*Math.PI*2,speed:.5+random(),size:.5+random()}));
    twinkles=Array.from({length:12},()=>({x:random(),y:random()*.34,phase:random()*Math.PI*2}));
    samples=[];intervals=[];lastPaint=0;paint();report();
  }
  // Cache a static line in bounded tiles. Only visible tiles move each frame.
  function makeTicker(spec) {
    const fontSize=H*(spec.size===undefined?.18:spec.size);
    const text=spec.text.replace(/\s+/g,' ').trim(),measure=layer(1,1).getContext('2d');
    const fontWeight=spec.fontWeight||600;
    measure.font=fontWeight+' '+fontSize+'px SouzAmbientDisplay';
    const textWidth=Math.ceil(measure.measureText(text).width),lineHeight=Math.ceil(fontSize*1.6);
    // Keep long copy bounded to 8M cached pixels, with resolution reduced first.
    let ratio=Math.min(1,Math.sqrt(8000000/(Math.max(1,textWidth)*lineHeight)));
    while(Math.ceil(textWidth*ratio)*Math.ceil(lineHeight*ratio)>8000000)ratio*=.99;
    const rasterWidth=Math.ceil(textWidth*ratio),rasterHeight=Math.ceil(lineHeight*ratio);
    const tiles=[];
    for(let x=0;x<rasterWidth;x+=1024){
      const width=Math.min(1024,rasterWidth-x);
      const tile=layer(width,rasterHeight),ctx=tile.getContext('2d');
      ctx.font=fontWeight+' '+(fontSize*ratio)+'px SouzAmbientDisplay';ctx.textBaseline='middle';
      ctx.fillStyle=spec.color||'#F1D6C3';ctx.fillText(text,-x,rasterHeight/2);
      tiles.push({canvas:tile,x:x/ratio,width:width/ratio});
    }
    const period=textWidth+W*(spec.gap===undefined?.45:spec.gap);
    const speed=spec.speed===undefined?-.027:spec.speed,opacity=spec.opacity===undefined?.07:spec.opacity;
    const y=H*(spec.y===undefined?.56:spec.y)-lineHeight/2;
    return {info:{tiles:tiles.length,cachePixels:tiles.reduce((n,t)=>n+t.canvas.width*t.canvas.height,0),font:'SB Sans Display',fontWeight,size:fontSize,opacity,speed},draw(ctx,time){
      ctx.save();ctx.globalCompositeOperation='source-over';ctx.globalAlpha=opacity;
      const shift=((time*W*speed)%period+period)%period;
      for(let start=shift-period;start<W;start+=period)for(const tile of tiles){
        const x=start+tile.x;if(x+tile.width<=0||x>=W)continue;
        ctx.drawImage(tile.canvas,x,y,tile.width,rasterHeight/ratio);
      }
      ctx.restore();
    }};
  }
  function paint() {
    const started=performance.now(),t=clock,mt=travel,motion=cfg.motion,water=H-hy;
    c.clearRect(0,0,W,H);
    if(abstractEngine){abstractEngine.draw(c,mt);if(foregroundEngine)foregroundEngine.draw(c,mt,(ctx,time)=>abstractEngine.occlude(ctx,time));c.globalAlpha=1;frames++;samples.push(performance.now()-started);if(samples.length>120)samples.shift();return;}
    if(nebula){c.globalAlpha=.45;c.drawImage(nebula,W*(-.08+Math.sin(mt*.09)*.045),H*(-.07+Math.cos(mt*.08)*.03),W*1.2,H*1.16);}
    else if(aurora) {
      for(let j=0;j<aurora.length;j++) {
        c.globalAlpha=.6+Math.sin(t*.32+j)*.16;
        c.drawImage(aurora[j],W*(-.07+Math.sin(mt*.2+j)*.028),H*(.018+j*.008+Math.sin(mt*.36+j)*.022),W*(1.15+Math.sin(mt*.17+j)*.025),H*.38);
      }
    } else {
      // Cached clouds cross the sky; wrapping happens entirely outside the frame.
      for(let j=0;j<3;j++) {
        const width=W*(.43+j*.055),phase=(.13+j*.31+mt*.009)%1;
        c.globalAlpha=cfg.celestial==='moon'?.24:.4;
        c.drawImage(cloud,phase*(W+width)-width,H*(.13+j*.065+Math.sin(mt*.13+j)*.008),width,H*(.05+j*.006));
      }
    }
    if(cfg.water) {
      c.save();c.beginPath();c.rect(0,hy,W,water);c.clip();
      for(let j=0;j<10;j++) {
        const z=((j+mt*.36)%10)/10,depth=z*z,fade=Math.min(1,z*22,(1-z)*10);
        const yy=hy+depth*water+Math.sin(mt*.6+j)*depth*H*.004;
        const offset=W*(.24+Math.sin(mt*.3+j)*.12);
        c.globalAlpha=(.14+depth*.27)*fade*(.55+motion*.55);
        c.drawImage(waves[j%3],offset,0,W,24,0,yy,W,(2+depth*16)*H/540);
      }
      c.fillStyle=rgba(palette.water[1],.13);
      for(const r of ripples) {
        if(!r.shade)continue;
        const phase=(r.z+mt*.021)%1,z=phase*phase,fade=Math.min(1,phase*24,(1-phase)*12);
        const x=r.x*W+Math.sin(mt*.55+r.phase)*W*.009,yy=hy+2+z*water+Math.sin(mt*.7+r.phase)*z*1.8;
        c.globalAlpha=fade;c.fillRect(x,yy,(1+z*20)*r.len*W/960,Math.max(.5,H/650));
      }
      c.fillStyle=palette.light;
      for(const r of ripples) {
        const phase=(r.z+mt*.021)%1,z=phase*phase,x=r.x*W+Math.sin(mt*.55+r.phase)*W*.009;
        const center=W*(.585+Math.sin(z*11-mt*.7)*.012),distance=Math.abs(x-center)/(W*(.018+z*.19));
        if(distance<1) {
          const fade=Math.min(1,phase*24,(1-phase)*12),yy=hy+2+z*water+Math.sin(mt*.7+r.phase)*z*1.8;
          c.globalAlpha=fade*(1-distance*distance)*(.1+r.light*.42)*(.7+Math.sin(t*.7+r.phase)*.3)*(1-z*.4);
          c.fillRect(x,yy,(1.5+z*29)*r.len*W/960,Math.max(.6,H/600));
        }
      }
      c.restore();
    }
    c.globalAlpha=1;
    if(cfg.atmosphere==='rain') {
      c.strokeStyle=palette.light;c.lineWidth=Math.max(.5,H/900);c.globalAlpha=.23;c.beginPath();
      for(const p of particles)for(let j=0;j<3;j++){const phase=(p.y+mt*.47*p.speed+j/3)%1,x=((p.x+phase*.065+mt*.008)%1)*W,y=phase*H;c.moveTo(x,y);c.lineTo(x-H*.004,y+H*.022);}
      c.stroke();
    } else if(cfg.atmosphere==='dust') {
      for(const p of particles){const x=((p.x+mt*.013+Math.sin(mt*.2+p.phase)*.025)%1)*W,y=H*(.57+p.y*.37+Math.sin(mt*.4+p.phase)*.025),size=(3+p.size*2)*H/540;c.globalAlpha=.13+Math.sin(t*.4+p.phase)*.08;c.drawImage(spark,x-size/2,y-size/2,size,size);}
    } else if(cfg.atmosphere==='meteors') {
      for(let j=0;j<3;j++){const phase=(mt*.05+j*.31)%1;if(phase<.18){const u=phase/.18,x=W*(.02+j*.2+u*.35),y=H*(.07+j*.09+u*.23),width=W*.145;c.save();c.globalAlpha=Math.sin(u*Math.PI)*.75;c.translate(x,y);c.rotate(.56);c.drawImage(meteor,-width,0,width,H*.022);c.restore();}}
    } else if(cfg.atmosphere==='snow') {
      c.fillStyle=palette.disc;
      for(const p of particles) {const x=((p.x+Math.sin(mt*.5+p.phase)*.02+mt*.01)%1)*W,yy=((p.y+mt*.045*p.speed)%1)*H;c.globalAlpha=.2+p.size*.19;c.fillRect(x,yy,p.size*W/1000+1,p.size*W/1000+1);}
    } else if(cfg.atmosphere==='fireflies') {
      for(const p of particles) {const alpha=Math.pow(Math.max(0,Math.sin(t*.52+p.phase)),3)*.65,x=(p.x+Math.sin(mt*.52+p.phase)*.055)*W,yy=H*(.68+p.y*.29)+Math.sin(mt*.75+p.phase)*H*.045,size=(3+p.size*3)*H/540;c.globalAlpha=alpha;c.drawImage(spark,x-size/2,yy-size/2,size,size);}
    }
    if(cfg.atmosphere==='mist'||cfg.landscape==='jungle'||cfg.landscape==='forest') {
      for(let j=0;j<3;j++) {c.globalAlpha=.28;c.drawImage(haze,W*(.07+j*.3+Math.sin(mt*.22+j)*.065),H*(cfg.horizon-.11+j*.03+Math.sin(mt*.16+j)*.012),W*.5,H*.11);}
    }
    if(cfg.atmosphere==='stars'||cfg.atmosphere==='meteors'||cfg.celestial==='moon'||cfg.landscape==='space') {
      c.fillStyle=palette.disc;
      for(const star of twinkles) {c.globalAlpha=.12+Math.sin(t*.24+star.phase)*.1;c.fillRect(star.x*W,star.y*H,1,1);}
    }
    if(cfg.landscape==='city') {
      for(let j=0;j<3;j++){const x=((j*.31+mt*.018)%1)*W,size=H*.009;c.globalAlpha=.45;c.drawImage(spark,x-size/2,hy-H*.009,size,size);}
    }
    if(cfg.landscape==='mountains'&&cfg.celestial==='sun') {
      c.globalAlpha=.35;c.strokeStyle=palette.mountain[2];c.lineWidth=.7;
      for(let j=0;j<2;j++){const x=W*(.27+j*.018+Math.sin(mt*.1)*.2),y=H*(.43+j*.01+Math.sin(mt*.18+j)*.008),size=Math.max(1,W*.0018),wing=Math.sin(mt*3.2+j)*size*.5;c.beginPath();c.moveTo(x-size*2,y-wing);c.quadraticCurveTo(x-size,y-size*.4,x,y);c.quadraticCurveTo(x+size,y-size*.4,x+size*2,y-wing);c.stroke();}
    }
    c.globalAlpha=1;frames++;samples.push(performance.now()-started);if(samples.length>120)samples.shift();
  }
  function percentile(values,fraction) {if(!values.length)return 0;const sorted=values.slice().sort((a,b)=>a-b);return sorted[Math.floor((sorted.length-1)*fraction)];}
  function report() {
    const p95=percentile(samples,.95),root=document.documentElement;
    stats={preset:cfg.preset,variant:cfg.variant,category:presets[cfg.preset].category,layers:abstractEngine?abstractEngine.counts:null,ticker:tickerEngine?tickerEngine.info:null,effects:foregroundEngine?foregroundEngine.info:null,profile:adaptive?'adaptive-minimal':quality,overlay:[W,H],background:[BW,BH],targetFps:profile.fps,observedFps:intervals.length?Math.round(1000/(intervals.reduce((a,v)=>a+v,0)/intervals.length)*10)/10:0,drawP50Ms:+percentile(samples,.5).toFixed(2),drawP95Ms:+p95.toFixed(2),frames,staticBuilds,paused,hidden:document.hidden};
    root.dataset.ambientStats=JSON.stringify(stats);
    if(!$('diagnostics').hidden)$('diagnostics').textContent=JSON.stringify(stats,null,2);
    // Slow hardware reduces both the raster budget and effect counts once.
    if(samples.length>=30&&!paused) {overloaded=p95>12||stats.observedFps>0&&stats.observedFps<14?overloaded+1:0;if(overloaded>=3&&!adaptive){adaptive=true;profile=profiles.minimal;resize();}}
  }
  function tick(stamp) {
    raf=0;if(paused||document.hidden)return;
    raf=requestAnimationFrame(tick);
    if(stamp+.1<nextDue)return;
    const interval=1000/profile.fps;nextDue+=interval;if(stamp-nextDue>interval*2)nextDue=stamp+interval;
    if(previous){const dt=Math.min((stamp-previous)/1000,.2);clock+=dt;travel+=dt*cfg.motion;}previous=stamp;
    if(lastPaint){intervals.push(stamp-lastPaint);if(intervals.length>120)intervals.shift();}lastPaint=stamp;
    paint();if(stamp-lastReport>2000){lastReport=stamp;report();}
  }
  function schedule() {if(raf)cancelAnimationFrame(raf);raf=0;previous=0;lastPaint=0;nextDue=0;if(!paused&&!document.hidden)raf=requestAnimationFrame(tick);report();}
  const singleScene=document.documentElement.dataset.mode==='scene';
  function show() {if(singleScene)return;document.body.classList.remove('quiet');clearTimeout(uiTimer);uiTimer=setTimeout(hide,4500);}
  function hide() {if($('controls').contains(document.activeElement))document.activeElement.blur();document.body.classList.add('quiet');clearTimeout(uiTimer);}
  function notify(text) {$('notice').textContent=text;$('notice').classList.add('visible');clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>$('notice').classList.remove('visible'),4000);}
  function pause() {paused=!paused;$('pause').textContent=paused?'Продолжить':'Пауза';$('pause').setAttribute('aria-label',paused?'Продолжить анимацию':'Приостановить анимацию');schedule();show();}
  function change(preset,variant) {
    if(singleScene)return;
    const sourcePreset=source.preset||defaultPreset,sourceVariant=source.layers?'custom':(source.variant||variants[sourcePreset][0].id);
    const selected=variant||optionsFor(preset)[0].id;
    const initial=preset===sourcePreset&&selected===sourceVariant?Object.assign({},source):{variant:selected};
    initial.motion=cfg.motion;initial.brightness=cfg.brightness;initial.quality=quality;
    configure(preset,initial);schedule();show();
  }
  async function fullscreen() {try {if(document.fullscreenElement)await document.exitFullscreen();else if(document.documentElement.requestFullscreen)await document.documentElement.requestFullscreen();else notify('Откройте полноэкранный режим через меню браузера');}catch(error){notify('В этом просмотрщике полный экран включает само приложение');}show();}
  $('category').addEventListener('change',event=>change(remembered[event.target.value]));
  $('scene').addEventListener('change',event=>change(event.target.value));
  $('variant').addEventListener('change',event=>change(cfg.preset,event.target.value));
  $('strength').addEventListener('input',event=>{cfg.motion=Number(event.target.value)/100;paint();show();});
  $('brightness').addEventListener('input',event=>{cfg.brightness=Number(event.target.value)/100;$('dim').style.opacity=1-cfg.brightness;show();});
  $('quality').addEventListener('change',event=>{quality=cfg.quality=event.target.value;profile=profiles[quality];adaptive=false;overloaded=0;resize();schedule();show();});
  if(!singleScene)$('pause').addEventListener('click',pause);$('fullscreen').addEventListener('click',fullscreen);
  document.addEventListener('pointermove',()=>{const now=performance.now();if(now-lastPointer>180){lastPointer=now;show();}},{passive:true});
  document.addEventListener('pointerdown',show,{passive:true});
  document.addEventListener('focusin',()=>{document.body.classList.remove('quiet');clearTimeout(uiTimer);});
  document.addEventListener('focusout',show);
  document.addEventListener('keydown',event=>{
    if(singleScene&&['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','KeyH','KeyD','Space'].includes(event.code)){event.preventDefault();return;}
    if(event.ctrlKey||event.metaKey||event.altKey)return;
    const control=/^(INPUT|SELECT|BUTTON)$/.test(event.target.tagName);
    if(event.code==='KeyH'){document.body.classList.contains('quiet')?show():hide();return;}
    if(event.code==='KeyF'){fullscreen();return;}
    if(event.code==='KeyD'){$('diagnostics').hidden=!$('diagnostics').hidden;report();return;}
    if(event.code==='Space'&&!control){event.preventDefault();pause();return;}
    if(!control&&(event.code==='ArrowLeft'||event.code==='ArrowRight')){event.preventDefault();const keys=sceneKeys(presets[cfg.preset].category),index=keys.indexOf(cfg.preset);change(keys[(index+(event.code==='ArrowRight'?1:keys.length-1))%keys.length]);return;}
    if(!control&&(event.code==='ArrowUp'||event.code==='ArrowDown')){event.preventDefault();const options=optionsFor(cfg.preset),index=options.findIndex(v=>v.id===cfg.variant);change(cfg.preset,options[(index+(event.code==='ArrowDown'?1:options.length-1))%options.length].id);return;}
    show();
  });
  document.addEventListener('visibilitychange',schedule);
  reduced.addEventListener('change',event=>{if(!singleScene&&event.matches&&!paused)pause();});
  let resizeTimer=0;window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{resize();schedule();},160);});
  const sourceText=source.ticker||(source.effects||[]).find(e=>e.type==='text');
  if(sourceText&&document.fonts){
    document.documentElement.dataset.fontStatus='loading';
    document.fonts.load((sourceText.fontWeight||600)+' 48px SouzAmbientDisplay','Понтий Пилат').then(faces=>{
      tickerFontReady=faces.length>0;document.documentElement.dataset.fontStatus=tickerFontReady?'loaded':'fallback';
      if(tickerFontReady){resize();report();}
    }).catch(()=>{document.documentElement.dataset.fontStatus='fallback';});
  }
  configure(source.preset||defaultPreset,source);$('pause').textContent=paused?'Продолжить':'Пауза';$('pause').setAttribute('aria-label',paused?'Продолжить анимацию':'Приостановить анимацию');schedule();show();
})();
