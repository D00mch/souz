"""Static offline HTML checks; never executes the page or accesses the network."""
import json
import re
import shutil
import subprocess
import sys
from contextlib import nullcontext
from html.parser import HTMLParser
from pathlib import Path


class Document(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.elements = []
        self.scripts = []
        self.current = None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        self.elements.append((tag, attrs))
        if tag == 'script':
            self.current = {'type': attrs.get('type', ''), 'source': ''}
            self.scripts.append(self.current)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)

    def handle_endtag(self, tag):
        if tag == 'script':
            self.current = None

    def handle_data(self, data):
        if self.current is not None:
            self.current['source'] += data


def check_source(source, label='<memory>', phase=nullcontext):
    raw = source.encode('utf-8') if isinstance(source, str) else source
    if not 0 < len(raw) <= 5_000_000:
        raise ValueError('Expected a complete HTML file of at most 5 MB')
    source = raw.decode('utf-8', errors='strict')
    if not re.match(r'\s*<!doctype html>', source, re.I):
        raise ValueError('HTML5 doctype is required')
    doc = Document()
    doc.feed(source)
    for required in ('html', 'head', 'body', 'title'):
        if sum(tag == required for tag, _ in doc.elements) != 1:
            raise ValueError('Expected one ' + required)
    ids = [attrs['id'] for _, attrs in doc.elements if 'id' in attrs]
    if len(set(ids)) != len(ids):
        raise ValueError('Duplicate element IDs')
    for tag, attrs in doc.elements:
        if tag in ('iframe', 'link', 'object', 'embed', 'form', 'base'):
            raise ValueError('Unsupported external/navigation element: ' + tag)
        if tag == 'script' and ('src' in attrs or attrs.get('type') == 'module'):
            raise ValueError('Scripts must be inline, non-module JavaScript')
        for key in ('src', 'href', 'poster', 'srcset'):
            if key in attrs and not attrs[key].startswith(('#', 'data:')):
                raise ValueError('External resource: ' + tag + '.' + key)
    if re.search(r'@import\b|url\(\s*[\'"]?(?!#|data:)', source, re.I):
        raise ValueError('CSS cannot load external resources')
    count = 0
    for script in doc.scripts:
        if script['type'] == 'application/json':
            json.loads(script['source'])
            continue
        code = script['source']
        if re.search(r'\b(?:fetch\s*\(|XMLHttpRequest|WebSocket|localStorage|sessionStorage|import\s*\()', code):
            raise ValueError('Unsupported network/storage dependency')
        if shutil.which('node'):
            with phase("node_syntax"):
                result = subprocess.run(['node', '--check'], input=code, text=True, capture_output=True, timeout=10)
            if result.returncode:
                raise ValueError('Inline JavaScript syntax error: ' + result.stderr[:300])
            count += 1
    return {'path': str(label), 'bytes': len(raw), 'offlinePackaging': 'passed', 'javascriptSyntaxChecks': count, 'visualCheck': 'not-performed', 'devicePerformance': 'not-measured'}


def check(path):
    return check_source(Path(path).read_bytes(), path)


if __name__ == '__main__':
    try:
        print(json.dumps(check(sys.argv[1]), ensure_ascii=False))
    except (ValueError, OSError, IndexError, subprocess.TimeoutExpired) as error:
        print(str(error), file=sys.stderr)
        sys.exit(2)
