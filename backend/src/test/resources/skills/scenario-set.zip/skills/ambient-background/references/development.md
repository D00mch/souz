# Renderer development and verification

The normal request path is recipe → one compose.py call → attachment. Benchmark
request-to-checked-file latency including model decisions and tool time; report
builder milliseconds separately. Never present builder timing as end-to-end speed.

When changing source, use the meaningful packaging/runtime tests, inspect actual
output, and test relevant combinations, pause/resume, hidden/resume, zero motion,
resize, phase continuity and count/raster budgets. Verify the standalone file directly in a browser. The playback target is the
TV’s Firefox fork, without an iframe. A browser on the development Mac is a
visual smoke check; local timing is not physical TV acceptance.
Independent skill forward tests belong to development, not every user's render.

Use `--preview` when testing the complete example catalogue and authoring controls.
The default scene must contain only its selected composition, hide text controls
and prevent browsing keys, while retaining fullscreen. Delivered scenes run continuously; pause/reduced-motion
controls belong to authoring preview. Visibility suspension conserves resources. Maintain compatibility
for both scene and preview modes. Scene output still has embedded recipe metadata.

Keep generated experiments outside the bundle. Avoid network, WebGL, external
fonts/libraries, expensive per-frame filters and per-frame sprite/gradient rebuilds.
New primitives need implementations and relevant checks; unsupported names fail.
The builder's static checks do not prove aesthetic fit or physical-device FPS.

The normal write_checked/CLI delivery gate checks for a large background form in
abstract delivery recipes, including presets. Low-level assemble and preview still support
isolated primitive tests; they do not certify a deliverable composition. Regress
missing/tiny/offscreen anchors and approved references as well as syntax/budgets.

Foreground effects share one raster surface and the large-figure mask. Test legacy
ticker and new text/symbols/lightning/flash, mask opt-out and mixed ordering, cached
glyphs/sprites, motion=0, visibility and adaptive density. New effects do not replace
background layers. Their recipe preflight is not visual or physical-TV acceptance.
