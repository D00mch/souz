/* One foreground surface for text, symbols and cached local light events. */
const AmbientForeground=(()=>{
  const wrap=(x,n)=>((x%n)+n)%n;
  const rgba=(hex,a)=>`rgba(${parseInt(hex.slice(1,3),16)},${parseInt(hex.slice(3,5),16)},${parseInt(hex.slice(5,7),16)},${a})`;
  function canvas(w,h){const c=document.createElement('canvas');c.width=Math.ceil(w);c.height=Math.ceil(h);return c;}
  function create({width:W,height:H,seed,effects,palette,makeText,density=1}){
    let state=(seed+7919)%2147483647||1;
    const random=()=>{state=state*16807%2147483647;return(state-1)/2147483646;};
    const surface=canvas(W,H),ctx=surface.getContext('2d');
    const compiled=effects.map(spec=>{
      if(spec.type==='text'){
        const text=makeText(spec);return text?{...text,type:'text',occlude:spec.occlude!==false}:null;
      }
      const type=spec.type,colors=spec.colors||[palette.light,palette.accent];
      const count=Math.max(1,Math.round((spec.count||(type==='symbols'?8:type==='lightning'?1:2))*Math.min(1,density))),speed=spec.speed===undefined?1:spec.speed;
      const opacity=spec.opacity===undefined?(type==='symbols'?.65:type==='flash'?.3:.85):spec.opacity;
      const scale=spec.scale||1,offset=spec.offset||[0,0],angleRange=spec.angleRange||[-35,35],period=spec.period||(type==='flash'?8:12);
      const nodes=Array.from({length:count},(_,i)=>({x:(i+.25+random()*.5)/count,y:random(),phase:random(),r:random()}));
      const glyphs='01<>/{}+=λΔ',cell=Math.max(12,H*.038*scale),tile=Math.ceil(cell*1.2);
      const atlases=type==='symbols'?colors.map(color=>{
        const image=canvas(tile*glyphs.length,tile*1.3),g=image.getContext('2d');g.fillStyle=color;g.font='600 '+cell+'px monospace';g.textBaseline='middle';
        for(let i=0;i<glyphs.length;i++)g.fillText(glyphs[i],i*tile,image.height/2);
        return image;
      }):[];
      const bolts=type==='lightning'?Array.from({length:4},(_,index)=>{
        const image=canvas(160,540),g=image.getContext('2d'),points=[];
        for(let i=0;i<=18;i++)points.push([80+(random()-.5)*65,i*30]);
        function path(){g.beginPath();points.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));
          for(let i=5;i<16;i+=5){g.moveTo(...points[i]);g.lineTo(points[i][0]+(i%2?42:-42),points[i][1]+45);g.lineTo(points[i][0]+(i%2?52:-52),points[i][1]+78);}}
        g.lineJoin='round';g.lineCap='round';
        for(const [width,alpha]of[[15,.04],[8,.13],[3,.75],[1.2,1]]){path();g.lineWidth=width;g.strokeStyle=rgba(colors[index%colors.length],alpha);g.stroke();}
        return image;
      }):[];
      let glow=null;
      if(type==='flash'||type==='lightning'){
        glow=canvas(192,192);const g=glow.getContext('2d'),gradient=g.createRadialGradient(96,96,0,96,96,96);
        gradient.addColorStop(0,rgba(colors[0],.9));gradient.addColorStop(.25,rgba(colors[0],.4));gradient.addColorStop(1,rgba(colors[0],0));g.fillStyle=gradient;g.fillRect(0,0,192,192);
      }
      function draw(context,time){
        const t=time*speed;context.save();context.translate(W*offset[0],H*offset[1]);context.globalCompositeOperation='screen';
        for(let i=0;i<count;i++){
          const n=nodes[i];
          if(type==='symbols'){
            const length=4+Math.floor(n.r*4),height=H+cell*(length+3),head=wrap(n.y*height+t*H*(.11+n.r*.06),height)-cell;
            const atlas=atlases[i%atlases.length],step=Math.floor((n.y*height+t*H*(.11+n.r*.06))/cell);
            for(let j=0;j<length;j++){
              const y=head-j*cell*1.15;if(y+tile<0||y>H)continue;
              const glyph=wrap(step+i*7-j*3,glyphs.length);context.globalAlpha=opacity*(j===0?1:(1-j/length)*.6);
              context.drawImage(atlas,glyph*tile,0,tile,atlas.height,W*n.x,y,tile,atlas.height);
            }
          }else{
            const phase=wrap(t+i*period/count,period),cycle=Math.floor((t+i*period/count)/period);
            const duration=type==='lightning'?.62:.95;if(phase>duration)continue;
            const u=phase/duration,attack=Math.min(1,u/.06),envelope=attack*(1-u)**2;
            const x=W*(.12+wrap(n.x+cycle*.173,.76)),y=H*(.2+n.y*.55);
            context.globalAlpha=opacity*envelope*(type==='lightning'?.22:1);
            const size=H*(type==='lightning'?.55:.6)*scale;context.drawImage(glow,x-size*.6,y-size*.45,size*1.2,size*.9);
            if(type==='lightning'){
              context.globalAlpha=opacity*envelope*(u>.2&&u<.3?.4:1);
              const hash=(((seed+Math.floor(n.phase*2147483646)+(cycle+1)*104729)%2147483647)*16807)%2147483647;
              const angle=spec.rotation===undefined?angleRange[0]+(angleRange[1]-angleRange[0])*hash/2147483647:spec.rotation;
              context.save();context.translate(x,H*.42);context.rotate(angle*Math.PI/180);
              context.drawImage(bolts[wrap(cycle+i,bolts.length)],-H*.13*scale,-H*.5*scale,H*.26*scale,H*.92*scale);context.restore();
            }
          }
        }
        context.restore();
      }
      return {draw,type,occlude:spec.occlude!==false,info:{type,count,...(type==='symbols'?{}:{period}),...(type==='lightning'?{rotation:spec.rotation===undefined?null:spec.rotation,angleRange:spec.rotation===undefined?angleRange:null}:{})}};
    }).filter(Boolean);
    return {
      info:compiled.map(e=>e.type==='text'?{type:'text',...e.info}:e.info),
      draw(context,time,mask){
        ctx.clearRect(0,0,W,H);
        for(const e of compiled)if(e.occlude)e.draw(ctx,time);
        if(compiled.some(e=>e.occlude))mask(ctx,time);
        for(const e of compiled)if(!e.occlude)e.draw(ctx,time);
        context.save();context.globalAlpha=1;context.globalCompositeOperation='source-over';context.drawImage(surface,0,0);context.restore();
      }
    };
  }
  return {create};
})();
